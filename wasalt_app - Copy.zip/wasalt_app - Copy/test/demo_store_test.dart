import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:wasalt_app/services/demo_accounts.dart';
import 'package:wasalt_app/services/demo_store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('all five demo roles authenticate only with their matching credentials', () {
    expect(DemoAccounts.accounts.length, 5);
    for (final account in DemoAccounts.accounts) {
      expect(DemoAccounts.authenticate(account.role, account.id, account.password), account);
      expect(DemoAccounts.authenticate(account.role, account.id, 'wrong'), isNull);
    }
  });

  test('mock records, status updates and notifications persist locally', () async {
    SharedPreferences.setMockInitialValues({});
    final store = DemoStore.instance;
    await store.initialize();
    final before = store.rows('children').length;
    store.add('children', {'id': 'PAS-TEST', 'name': 'اختبار', 'school': 'Amman Academy', 'route': 'Amman 04', 'pickupAddress': 'عبدون، عمّان', 'dropoffAddress': 'Amman Academy، عمّان', 'status': 'Active', 'attendance': 'Waiting'}, notice: 'تمت إضافة راكب تجريبي');
    expect(store.rows('children').length, before + 1);
    store.edit('children', 'PAS-TEST', {'attendance': 'Boarded'});
    expect(store.rows('children').last['attendance'], 'Boarded');
    expect(store.rows('notices').first['text'], 'تمت إضافة راكب تجريبي');
    store.add('drivers', {'id': 'DRV-TEST', 'name': 'Demo Driver', 'plate': 'AM TEST', 'route': 'Amman 04', 'capacity': 12, 'used': 0, 'phone': '+962790000000', 'status': 'Pending'});
    store.add('campaigns', {'id': 'AD-TEST', 'name': 'Demo Ad', 'slot': 'Arrival banner', 'district': 'Amman', 'dailyRate': 12.5, 'days': 2, 'budget': 25.0, 'status': 'Draft', 'start': '2026-09-21', 'end': '2026-09-22', 'asset': 'Generic', 'imageUrl': ''});
    store.edit('campaigns', 'AD-TEST', {'status': 'Pending review'});
    expect(store.rows('campaigns').last['status'], 'Pending review');
    expect(store.provisionToken(), matches(RegExp(r'^TG-[A-Z2-9]{4}-[A-Z2-9]{4}$')));
    await Future<void>.delayed(const Duration(milliseconds: 10));
    final prefs = await SharedPreferences.getInstance();
    expect(store.number('dailyAdRate'), greaterThan(0));
    expect(store.rows('tenants').first['contactPerson'], isNotEmpty);
    expect(store.rows('tenants').first['companyRegistration'] ?? store.rows('tenants').first['registration'], isNotEmpty);
    expect(prefs.getString('wasult_five_role_demo_v3'), contains('PAS-TEST'));
  });
}
