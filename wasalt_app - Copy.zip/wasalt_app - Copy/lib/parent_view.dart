﻿// lib/parent_view.dart
import 'package:flutter/material.dart';

class ParentWorkspaceView extends StatefulWidget {
  final VoidCallback onBack;
  final Function(String) onEmitAction;

  const ParentWorkspaceView({super.key, required this.onBack, required this.onEmitAction});

  @override
  State<ParentWorkspaceView> createState() => _ParentWorkspaceViewState();
}

class _ParentWorkspaceViewState extends State<ParentWorkspaceView> {
  bool _isWhatsAppEnabled = true;
  bool _isPushEnabled = true;
  
  // Custom Ad-Hoc Form Variables
  final TextEditingController _customAddressController = TextEditingController();
  final TextEditingController _driverIdController = TextEditingController();
  String _customTripStatus = "Idle"; // Idle, Awaiting Driver Approval, Accepted

  void _submitAdHocTripRequest() {
    if (_customAddressController.text.trim().isEmpty) return;
    setState(() {
      _customTripStatus = "Awaiting Driver Approval";
    });
    widget.onEmitAction("AD_HOC_SUBMIT: ${_customAddressController.text}");
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("🚀 تم إرسال طلب الرحلة المؤقتة بنجاح وجاري المراجعة من قبل السائق")),
    );
  }

  void _linkDriverViaCode() {
    final code = _driverIdController.text.trim().toUpperCase();
    if (code.length < 3) return;
    widget.onEmitAction("LINK_DRIVER_CODE: $code");
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("🔗 تم إرسال طلب الربط مع الحافلة بالرمز: $code")),
    );
    _driverIdController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("بوابة المتابعة الذكية لأولياء الأمور"),
        backgroundColor: Colors.teal,
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: widget.onBack),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // 1. QR CODE & 6-CHARACTER MANUAL ID LINK HANDSHAKE
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("🔗 ربط سريع مع حافلة جديدة (QR / Driver ID)", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.teal)),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _driverIdController,
                          maxLength: 6,
                          textCapitalization: TextCapitalization.characters,
                          decoration: const InputDecoration(
                            hintText: "أدخل رمز السائق المكون من 6 خانات (e.g. DRV99X)",
                            border: OutlineInputBorder(),
                            counterText: "",
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      ElevatedButton(
                        onPressed: _linkDriverViaCode,
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white, minimumSize: const Size(120, 54)),
                        child: const Text("ربط الحساب"),
                      )
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),

          // 2. "BOOK A CUSTOM TRIP" AD-HOC FORM ELEMENT
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("📅 حجز رحلة مؤقتة / تعديل موقع (Book Custom Trip)", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.blueGrey)),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _customAddressController,
                    decoration: const InputDecoration(
                      labelText: "العنوان المؤقت البديل أو الإحداثيات",
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.map_outlined),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("حالة الطلب: ${_customTripStatus.toUpperCase()}", style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.orange)),
                      ElevatedButton(
                        onPressed: _submitAdHocTripRequest,
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.blueGrey.shade900, foregroundColor: Colors.white),
                        child: const Text("إرسال طلب التعديل اللحظي"),
                      )
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),

          // 3. UC-5 CONTROL NOTIFICATION CONFIGURATION PANEL
          Card(
            color: Colors.teal.shade50,
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("⚙️ تخصيص قنوات الإشعارات والتحكم الذاتي (UC-5)", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.teal.shade900)),
                  SwitchListTile(
                    title: const Text("تفعيل رسائل الواتساب التفاعلية"),
                    value: _isWhatsAppEnabled,
                    activeColor: Colors.teal,
                    onChanged: (val) => setState(() => _isWhatsAppEnabled = val),
                  ),
                  SwitchListTile(
                    title: const Text("إشعارات الهاتف المباشرة (Push)"),
                    value: _isPushEnabled,
                    activeColor: Colors.teal,
                    onChanged: (val) => setState(() => _isPushEnabled = val),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),

          // 4. HIGH-FREQUENCY TRIP TRACKER INTERFACE COUNTDOWN WIDGET AREA
          const Text("تتبع مسار الأبناء التفاعلي الحي ( countdown tracking ):", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          _buildChildTrackingCard("سامي - خط عمان", "جاري الاقتراب - بانتظارك خلال 3 دقائق", "باص رقم 4 - السائق أحمد (سرعة: 42 كم/س)"),
          _buildChildTrackingCard("نور - خط الجيزة", "في الانتظار بموقف الانطلاق الرئيسي", "مركبة رقم 12 - السائق محمود"),
        ],
      ),
    );
  }

  Widget _buildChildTrackingCard(String name, String status, String driver) {
    return Card(
      elevation: 3,
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: ListTile(
        leading: const CircleAvatar(backgroundColor: Colors.teal, child: Icon(Icons.directions_bus, color: Colors.white)),
        title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        subtitle: Text("$driver\n$status"),
        trailing: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(color: Colors.teal.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
          child: const Text("⏱️ 3 د", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.teal)),
        ),
        isThreeLine: true,
      ),
    );
  }
}
