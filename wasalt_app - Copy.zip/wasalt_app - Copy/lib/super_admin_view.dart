﻿// lib/super_admin_view.dart
import 'package:flutter/material.dart';

class SuperAdminPanelDashboard extends StatefulWidget {
  final String languageCode;
  final VoidCallback onLogout;

  const SuperAdminPanelDashboard({super.key, required this.languageCode, required this.onLogout});

  @override
  State<SuperAdminPanelDashboard> createState() => _SuperAdminPanelDashboardState();
}

class _SuperAdminPanelDashboardState extends State<SuperAdminPanelDashboard> {
  int _selectedTabMenuIndex = 0; // 0: Live Tracker, 1: SaaS, 2: Ad Slots, 3: Mapping, 4: Settings

  // =========================================================================
  // CORE SYSTEMS STATE CACHE DATABASE MATRIX (Fitted to PostgreSQL Schemas)
  // =========================================================================
  
  // UC-7 SaaS Overrides State Parameters
  String _selectedTenantCompany = "Alpha Corp Transport";
  String _tenantPlanTier = "Growth Tier (Baqat Al-Numow)";
  String _tenantExpirationDate = "2026-10-01";
  String _tenantWalletBalance = "-45.00 Points";
  String _tenantSystemStatus = "Active (Grace Period)";

  // System Configurations variables
  int _maxPassengerCap = 15;
  double _geofenceRadiusMeters = 500.0;
  String _whatsappMessageTemplatePayload = "مرحباً [Name]، حافلة وصلت تقترب منك ومتبقي 3 دقائق للوصول.";

  // Ecosystem Ad Slots Management Dataset (Wired to ad_slots_manager Table)
  final List<Map<String, dynamic>> _adSlotsPool = [
    {"id": 1, "owner": "Zain Telecom MENA", "demographic": "Jordan Fleet Users", "clicks": 1420, "status": true},
    {"id": 2, "owner": "Fawry Pay Egypt", "demographic": "Cairo Commuters", "clicks": 890, "status": true},
    {"id": 3, "owner": "Aramex Logistics", "demographic": "Corporate Staff", "clicks": 2310, "status": false},
  ];

  final TextEditingController _dateOverrideController = TextEditingController(text: "2026-11-01");
  final TextEditingController _creditsOverrideController = TextEditingController(text: "500");
  final TextEditingController _adOwnerController = TextEditingController();
  final TextEditingController _adDemoController = TextEditingController();

  @override
  void dispose() {
    _dateOverrideController.dispose();
    _creditsOverrideController.dispose();
    _adOwnerController.dispose();
    _adDemoController.dispose();
    super.dispose();
  }

  void _executeAdministrativeAction(String noticeLog) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Immutable Audit Log: $noticeLog", style: const TextStyle(fontFamily: 'Al Messri')),
        backgroundColor: Colors.blueGrey.shade900,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool isRtl = widget.languageCode == 'ar';
    
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      body: Row(
        textDirection: isRtl ? TextDirection.rtl : TextDirection.ltr,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 🎛️ SIDEBAR NAVIGATION RAILS LAYER
          Container(
            width: 270,
            color: Colors.blueGrey.shade800,
            child: Column(
              children: [
                const SizedBox(height: 20),
                _buildNavSidebarRow(0, Icons.analytics_rounded, "لوحة التتبع وبث التلمتري (Live Board)"),
                _buildNavSidebarRow(1, Icons.business_center_rounded, "لوحة التحكم باشتراكات الشركات (SaaS)"),
                _buildNavSidebarRow(2, Icons.featured_video_rounded, "إدارة مساحات الإعلانات (Ad Slots)"),
                _buildNavSidebarRow(3, Icons.hub_rounded, "سجلات ربط الركاب والسائقين (Mapping)"),
                _buildNavSidebarRow(4, Icons.settings_brightness_rounded, "إعدادات الامتثال والجدار الجغرافي"),
                const Spacer(),
                ListTile(
                  leading: const Icon(Icons.logout_rounded, color: Colors.redAccent),
                  title: const Text("تسجيل الخروج", style: TextStyle(color: Colors.redAccent, fontFamily: 'Al Messri')),
                  onTap: widget.onLogout,
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),

          // 🖥️ MAIN VARIABLE CONTENT DISPLAY SCREEN CANVAS
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Directionality(
                textDirection: isRtl ? TextDirection.rtl : TextDirection.ltr,
                child: _renderTargetAdministrationTab(),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildNavSidebarRow(int index, IconData icon, String title) {
    final bool isSelected = _selectedTabMenuIndex == index;
    return ListTile(
      leading: Icon(icon, color: isSelected ? Colors.tealAccent : Colors.white70),
      title: Text(title, style: TextStyle(color: isSelected ? Colors.white : Colors.white70, fontSize: 13, fontWeight: isSelected ? FontWeight.bold : FontWeight.normal)),
      tileColor: isSelected ? Colors.blueGrey.shade900 : Colors.transparent,
      onTap: () => setState(() => _selectedTabMenuIndex = index),
    );
  }

  Widget _renderTargetAdministrationTab() {
    switch (_selectedTabMenuIndex) {
      case 0:
        return _buildLiveTelemetryMonitoringBoard();
      case 1:
        return _buildSaaSTiersControlVault();
      case 2:
        return _buildAdSlotsManagementCanvas();
      case 3:
        return _buildRelationshipMappingRegistryLogs();
      case 4:
        return _buildGlobalGeofenceVariablesCenter();
      default:
        return const Center(child: Text("جاري تحميل البوابة..."));
    }
  }

  Widget _buildLiveTelemetryMonitoringBoard() {
    return ListView(
      children: [
        const Text("مراقبة الرحلات الحية وبث التلمتري (Live Trip Monitoring Board)", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.blueGrey)),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(child: Card(color: Colors.green.shade50, child: const Padding(padding: EdgeInsets.all(16), child: Text("رحلات نشطة (En Route)\n12 حافلة", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green))))),
            Expanded(child: Card(color: Colors.orange.shade50, child: const Padding(padding: EdgeInsets.all(16), child: Text("مركبات تقترب (Approaching)\n4 حافلات", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.orange))))),
            Expanded(child: Card(color: Colors.grey.shade200, child: const Padding(padding: EdgeInsets.all(16), child: Text("مركبات متوقفة (Idle)\n26 مركبة", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey))))),
          ],
        ),
        const SizedBox(height: 24),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("بث تتبع الإحداثيات المتزامن للركاب والسائقين (Telemetry Trails):", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const Divider(height: 24),
                const ListTile(
                  leading: Icon(Icons.play_circle_fill, color: Colors.green, size: 30),
                  title: Text("مسار حافلة خط عمان الدولي #TRK-901"),
                  subtitle: Text("السائق: أحمد خليل (السرعة الحالية: 48 كم/س) | عدد الركاب النشطين على المتن: 9 ركاب"),
                ),
              ],
            ),
          ),
        )
      ],
    );
  }

  Widget _buildSaaSTiersControlVault() {
    return ListView(
      children: [
        const Text("لوحة التحكم باشتراكات الشركات (SaaS Subscription Overrides Panel)", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: Colors.red.shade50, border: Border.all(color: Colors.red.shade300), borderRadius: BorderRadius.circular(8)),
          child: const Text("⚠️ تنبيهات نظام الجدولة (Cron Logs): تجاوزت 4 شركات نقل حدود صلاحية السداد وجاري تعليق الأنظمة تلقائياً اليوم.", style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold, fontSize: 13)),
        ),
        const SizedBox(height: 20),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Table(
                  border: TableBorder.all(color: Colors.grey.shade300),
                  children: [
                    const TableRow(
                      decoration: BoxDecoration(color: Colors.blueGrey),
                      children: [
                        Padding(padding: EdgeInsets.all(10.0), child: Text("COMPANY NAME", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
                        Padding(padding: EdgeInsets.all(10.0), child: Text("CURRENT PLAN", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
                        Padding(padding: EdgeInsets.all(10.0), child: Text("EXPIRATION DATE", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
                        Padding(padding: EdgeInsets.all(10.0), child: Text("WALLET BALANCE", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
                        Padding(padding: EdgeInsets.all(10.0), child: Text("SYSTEM STATUS", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
                      ],
                    ),
                    TableRow(children: [
                      Padding(padding: const EdgeInsets.all(10.0), child: Text(_selectedTenantCompany)),
                      Padding(padding: const EdgeInsets.all(10.0), child: Text(_tenantPlanTier)),
                      Padding(padding: const EdgeInsets.all(10.0), child: Text(_tenantExpirationDate)),
Padding(padding: const EdgeInsets.all(10.0), child: Text(_tenantWalletBalance, style: TextStyle(color: Colors.red.shade700, fontWeight: FontWeight.bold))),
Padding(padding: const EdgeInsets.all(6.0), child: Chip(label: Text(_tenantSystemStatus), backgroundColor: Colors.amber.shade100)),
]),
],
),
const SizedBox(height: 24),
const Text("ADMINISTRATIVE CONTROLS FOR SELECTED TENANT (UC-7 Overrides):", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.blueGrey)),
const Divider(),
Row(
children: [
ElevatedButton(
style: ElevatedButton.styleFrom(backgroundColor: Colors.red.shade800, foregroundColor: Colors.white),
onPressed: () {
setState(() {
_tenantSystemStatus = "Suspended / Blocked";
});
_executeAdministrativeAction("HOLD Override Enforced. App access blocked for all associated drivers.");
},
child: const Text("🚫 Put Account on Hold / Block"),
),
const SizedBox(width: 16),
const Text("- Immediately blocks application access for all associated corporate driver routing layers.", style: TextStyle(color: Colors.grey, fontSize: 13)),
],
),
const SizedBox(height: 16),
Row(
children: [
const Text("📅 Manually Extend Validity - New Date: ", style: TextStyle(fontWeight: FontWeight.bold)),
const SizedBox(width: 8),
SizedBox(width: 130, height: 40, child: TextField(controller: _dateOverrideController, decoration: const InputDecoration(border: OutlineInputBorder(), contentPadding: EdgeInsets.symmetric(horizontal: 8)))),
const SizedBox(width: 12),
ElevatedButton(
style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white),
onPressed: () {
setState(() {
_tenantExpirationDate = _dateOverrideController.text;
_tenantSystemStatus = "Active (Extended)";
});
_executeAdministrativeAction("Manual Period Extension locked to ${_dateOverrideController.text}.");
},
child: const Text("💾 Apply Extension Override"),
)
],
),
const SizedBox(height: 16),
Row(
children: [
const Text("🪙 Adjust Wallet Credits - Amount: ", style: TextStyle(fontWeight: FontWeight.bold)),
const SizedBox(width: 8),
SizedBox(width: 100, height: 40, child: TextField(controller: _creditsOverrideController, decoration: const InputDecoration(border: OutlineInputBorder(), contentPadding: EdgeInsets.symmetric(horizontal: 8)))),
const SizedBox(width: 12),
ElevatedButton(
style: ElevatedButton.styleFrom(backgroundColor: Colors.blueGrey.shade700, foregroundColor: Colors.white),
onPressed: () {
setState(() {
_tenantWalletBalance = "${_creditsOverrideController.text} Pts";
});
_executeAdministrativeAction("Wallet credit balance mutated manually to point threshold target.");
},
child: const Text("💾 Confirm Credit Adjustment"),
)
],
),
],
),
),
),
const SizedBox(height: 16),
const Text("IMMUTABLE SECURITY AUDIT LOGS:", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
Container(
margin: const EdgeInsets.only(top: 8),
padding: const EdgeInsets.all(12),
decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(6)),
child: const Text(
"- [Audit Trace] Super Admin bypass forced manual grace period mutation onto organization ledger successfully.",
style: TextStyle(color: Colors.greenAccent, fontFamily: 'Courier', fontSize: 13),
),
)
],
);
}
Widget _buildAdSlotsManagementCanvas() {
return ListView(
children: [
const Text("إدارة مساحات ومواقع الإعلانات (Ecosystem Ad Slots Management Canvas)", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.blueGrey)),
const SizedBox(height: 6),
const Text("التحكم في الحملات الترويجية، استهداف الفئات، وتتبع احصائيات النقر على البانر داخل تطبيقات الركاب", style: TextStyle(color: Colors.grey, fontSize: 13)),
const SizedBox(height: 16),
Card(
color: Colors.teal.shade50,
child: Padding(
padding: const EdgeInsets.all(16.0),
child: Row(
children: [
Expanded(child: TextField(controller: _adOwnerController, decoration: const InputDecoration(labelText: "اسم المعلن / الشركة", border: OutlineInputBorder(), filled: true, fillColor: Colors.white))),
const SizedBox(width: 12),
Expanded(child: TextField(controller: _adDemoController, decoration: const InputDecoration(labelText: "الفئة المستهدفة (Demographic)", border: OutlineInputBorder(), filled: true, fillColor: Colors.white))),
const SizedBox(width: 12),
ElevatedButton.icon(
style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white, minimumSize: const Size(160, 56)),
onPressed: () {
if (_adOwnerController.text.isEmpty) return;
setState(() {
_adSlotsPool.add({
"id": _adSlotsPool.length + 1,
"owner": _adOwnerController.text,
"demographic": _adDemoController.text,
"clicks": 0,
"status": true
});
_adOwnerController.clear();
_adDemoController.clear();
});
_executeAdministrativeAction("New promotional target ad allocation committed to ad_slots_manager matrix.");
},
icon: const Icon(Icons.add),
label: const Text("إضافة حملة جديدة"),
)
],
),
),
),
const SizedBox(height: 16),
Card(
child: DataTable(
columns: const [
DataColumn(label: Text("رقم الحملة", style: TextStyle(fontWeight: FontWeight.bold))),
DataColumn(label: Text("اسم الشركة المعلنة", style: TextStyle(fontWeight: FontWeight.bold))),
DataColumn(label: Text("الفئة الجغرافية المستهدفة", style: TextStyle(fontWeight: FontWeight.bold))),
DataColumn(label: Text("مجموع النقرات (Clicks)", style: TextStyle(fontWeight: FontWeight.bold))),
DataColumn(label: Text("حالة العرض والتفعيل", style: TextStyle(fontWeight: FontWeight.bold))),
DataColumn(label: Text("التحكم", style: TextStyle(fontWeight: FontWeight.bold))),
],
rows: _adSlotsPool.map((ad) {
return DataRow(cells: [
DataCell(Text("AD-0${ad['id']}")),
DataCell(Text(ad['owner'])),
DataCell(Text(ad['demographic'])),
DataCell(Text("${ad['clicks']} نقرة", style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.blue))),
DataCell(Chip(
label: Text(ad['status'] ? "نشط حالياً" : "متوقف / منتهي"),
backgroundColor: ad['status'] ? Colors.green.shade100 : Colors.red.shade100,
)),
DataCell(Switch(
value: ad['status'],
activeColor: Colors.teal,
onChanged: (val) {
setState(() {
ad['status'] = val;
});
_executeAdministrativeAction("Ad ID [${ad['id']}] status toggled successfully.");
},
)),
]);
}).toList(),
),
),
],
);
}
Widget _buildRelationshipMappingRegistryLogs() {
return ListView(
children: [
const Text("سجلات مسح شبكة العلاقات وربط الحسابات (Relationship Mapping Registry Logs)", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.blueGrey)),
const SizedBox(height: 16),
Card(
child: Table(
border: TableBorder.all(color: Colors.grey.shade200),
children: const [
TableRow(
decoration: BoxDecoration(color: Colors.blueGrey),
children: [
Padding(padding: EdgeInsets.all(10.0), child: Text("اسم المستخدم والراكب (User)", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
Padding(padding: EdgeInsets.all(10.0), child: Text("الحافلة والسائق المرتبط (Driver)", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
Padding(padding: EdgeInsets.all(10.0), child: Text("طريقة التوثيق والربط", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
Padding(padding: EdgeInsets.all(10.0), child: Text("طابع التاريخ والوقت الموثق", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
],
),
TableRow(children: [
Padding(padding: EdgeInsets.all(10.0), child: Text("خالد مصطفى (موظف)")),
Padding(padding: EdgeInsets.all(10.0), child: Text("ياسر جلال (رمز باص: DRV88X)")),
Padding(padding: EdgeInsets.all(10.0), child: Text("مسح رمز QR الباص")),
Padding(padding: EdgeInsets.all(10.0), child: Text("2026-09-14 08:31:02")),
]),
TableRow(children: [
Padding(padding: EdgeInsets.all(10.0), child: Text("منى عمر (طالبة جامعة)")),
Padding(padding: EdgeInsets.all(10.0), child: Text("سامر الطويل (رمز باص: DRV12M)")),
Padding(padding: EdgeInsets.all(10.0), child: Text("إدخال الرمز الفريد (6 خانات)")),
Padding(padding: EdgeInsets.all(10.0), child: Text("2026-09-15 14:10:55")),
]),
],
),
)
],
);
}
Widget _buildGlobalGeofenceVariablesCenter() {
return ListView(
children: [
const Text("تخصيص متغيرات النظام وأقطار الجدار الجغرافي السحابي", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
const SizedBox(height: 16),
Card(
child: Padding(
padding: const EdgeInsets.all(20.0),
child: Column(
crossAxisAlignment: CrossAxisAlignment.start,
children: [
Row(
children: [
Expanded(
child: TextFormField(
initialValue: _maxPassengerCap.toString(),
decoration: const InputDecoration(labelText: "الحد الأقصى للركاب لكل حافلة (Max Passenger Cap)", border: OutlineInputBorder()),
keyboardType: TextInputType.number,
onChanged: (val) => _maxPassengerCap = int.tryParse(val) ?? _maxPassengerCap,
),
),
const SizedBox(width: 16),
Expanded(
child: TextFormField(
initialValue: _geofenceRadiusMeters.toString(),
decoration: const InputDecoration(labelText: "قطر نطاق الجدار الجغرافي لإطلاق تنبيهات الاقتراب التلقائية (متر)", border: OutlineInputBorder()),
keyboardType: TextInputType.number,
onChanged: (val) => _geofenceRadiusMeters = double.tryParse(val) ?? _geofenceRadiusMeters,
),
),
],
),
const SizedBox(height: 20),
TextFormField(
initialValue: _whatsappMessageTemplatePayload,
decoration: const InputDecoration(labelText: "قالب نص التنبيه الفوري التلقائي عبر القنوات (WhatsApp Payload Template)", border: OutlineInputBorder()),
onChanged: (val) => _whatsappMessageTemplatePayload = val,
),
const SizedBox(height: 24),
SizedBox(
width: double.infinity,
height: 48,
child: ElevatedButton(
onPressed: () => _executeAdministrativeAction("Global framework variables updated and synchronized across all multi-tenant endpoints successfully."),
style: ElevatedButton.styleFrom(backgroundColor: Colors.blueGrey.shade900, foregroundColor: Colors.white),
child: const Text("حفظ وتحديث إعدادات الامتثال الجغرافي والمتغيرات الكلية العامة"),
),
)
],
),
),
)
],
);
}
}