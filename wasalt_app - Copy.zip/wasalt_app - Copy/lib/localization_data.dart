﻿// lib/localization_data.dart
class WasultLocalization {
  static final Map<String, Map<String, String>> localizedValues = {
    'ar': {
      'splash_title': 'أنظمة وصلت الذكية',
      'splash_sub': 'نظام إدارة الاشتراكات المؤسسية والامتثال الحركي',
      'login_title': 'تسجيل الدخول الموحد',
      'user_id': 'معرف المستخدم (أكثر من 3 خانات)',
      'remember_me': 'تذكر بياناتي على هذا الجهاز',
      'btn_driver': 'بوابة السائق المحترفة',
      'btn_user': 'بوابة الركاب (User App)',
      'btn_corporate': 'إدارة الشركاء (Corporate Admin)',
      'btn_admin': 'لوحة تحكم المشرف العام (Super Admin)',
      'admin_title': 'لوحة تحكم المشرف العام - وصلت SaaS',
    },
    'en': {
      'splash_title': 'Wasult Smart Systems',
      'splash_sub': 'Corporate Subscriptions & Compliance Management',
      'login_title': 'Unified System Access',
      'user_id': 'User Alphanumeric ID (Min 3 Chars)',
      'remember_me': 'Remember my credentials on this node',
      'btn_driver': 'Professional Driver Workspace',
      'btn_user': 'User Application Client',
      'btn_corporate': 'Corporate User Admin Board',
      'btn_admin': 'Super Admin Enterprise Console',
      'admin_title': 'Super Admin Portal - Wasult SaaS Engine',
    }
  };

  static String getText(String languageCode, String key) {
    return localizedValues[languageCode]?[key] ?? localizedValues['en']?[key] ?? '';
  }
}
