﻿// lib/services.dart
import 'package:flutter/material.dart';

class WasultServices {
  static void showToast(BuildContext context, String action) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("تم تنفيذ الإجراء بنجاح: $action", style: const TextStyle(fontFamily: 'Al Messri', fontSize: 16)),
        backgroundColor: Colors.teal.shade900,
        duration: const Duration(seconds: 1),
      ),
    );
  }
}
