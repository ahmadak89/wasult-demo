﻿// lib/admin_view.dart
import 'package:flutter/material.dart';
import 'services.dart';

class AdminWorkspaceView extends StatelessWidget {
  final VoidCallback onBack;
  const AdminWorkspaceView({super.key, required this.onBack});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("لوحة تحكم المشرف العام - Wasult Override"),
        backgroundColor: Colors.blueGrey.shade900,
        foregroundColor: Colors.white,
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: onBack),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.red.shade50, border: Border.all(color: Colors.red), borderRadius: BorderRadius.circular(8)),
              child: const Text("⚠️ تنبيهات النظام التلقائية: انتهت فترة صلاحية اشتراك 4 شركات نقل اليوم وجاري تعليق الوصول.", style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 20),
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("الشركة المحددة: Alpha Corp Transport", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    Divider(),
                    Text("نوع الخطة: Growth Tier"),
                    Text("حالة المحفظة الحالية: -45.00 نقطة"),
                    Text("تاريخ الانتهاء الحالي: 01 أكتوبر 2026"),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red, minimumSize: const Size(double.infinity, 45)),
              onPressed: () => WasultServices.showToast(context, "HOLD Overrides Applied"),
              child: const Text("🚫 وضع الحساب قيد التعليق الفوري / Block Tenant", style: TextStyle(color: Colors.white)),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, minimumSize: const Size(double.infinity, 45)),
              onPressed: () => WasultServices.showToast(context, "Extension Granted"),
              child: const Text("📅 تمديد الصلاحية يدوياً (منح فترة سماح 5 أيام)", style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }
}
