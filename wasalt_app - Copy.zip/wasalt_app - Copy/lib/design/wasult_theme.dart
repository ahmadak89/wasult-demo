import 'package:flutter/material.dart';

abstract final class WasultColors {
  static const teal = Color(0xFF005B60);
  static const tealDark = Color(0xFF003F43);
  static const tealSoft = Color(0xFFE7F4F3);
  static const orange = Color(0xFFFFA500);
  static const amber = Color(0xFFFFC857);
  static const ink = Color(0xFF122B2D);
  static const muted = Color(0xFF617779);
  static const canvas = Color(0xFFF4F8F7);
  static const danger = Color(0xFFE45252);
  static const success = Color(0xFF1FA971);
}

abstract final class WasultTheme {
  static ThemeData get light {
    final scheme = ColorScheme.fromSeed(
      seedColor: WasultColors.teal,
      brightness: Brightness.light,
      primary: WasultColors.teal,
      secondary: WasultColors.orange,
      surface: Colors.white,
      error: WasultColors.danger,
    );
    final base = ThemeData(useMaterial3: true, colorScheme: scheme);
    return base.copyWith(
      scaffoldBackgroundColor: WasultColors.canvas,
      textTheme: base.textTheme.apply(
        fontFamily: 'Cairo',
        bodyColor: WasultColors.ink,
        displayColor: WasultColors.ink,
      ),
      appBarTheme: const AppBarTheme(
        centerTitle: false,
        elevation: 0,
        scrolledUnderElevation: 0,
        backgroundColor: Colors.transparent,
        foregroundColor: WasultColors.ink,
      ),
      cardTheme: CardThemeData(
        color: Colors.white,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 17),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: const BorderSide(color: Color(0xFFDDE8E7)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: const BorderSide(color: WasultColors.teal, width: 1.6),
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        height: 72,
        backgroundColor: Colors.white,
        indicatorColor: WasultColors.tealSoft,
        labelTextStyle: WidgetStateProperty.resolveWith((states) => TextStyle(
              fontWeight: states.contains(WidgetState.selected) ? FontWeight.w800 : FontWeight.w600,
              color: states.contains(WidgetState.selected) ? WasultColors.teal : WasultColors.muted,
            )),
      ),
    );
  }
}
