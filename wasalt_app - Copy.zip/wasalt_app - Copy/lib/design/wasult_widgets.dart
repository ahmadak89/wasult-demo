import 'package:flutter/material.dart';
import 'package:vector_math/vector_math_64.dart' show Matrix4;
import 'wasult_theme.dart';

class WasultPressButton extends StatefulWidget {
  const WasultPressButton({
    super.key,
    required this.label,
    required this.icon,
    required this.onPressed,
    this.color = WasultColors.teal,
    this.expanded = true,
  });

  final String label;
  final IconData icon;
  final VoidCallback? onPressed;
  final Color color;
  final bool expanded;

  @override
  State<WasultPressButton> createState() => _WasultPressButtonState();
}

class _WasultPressButtonState extends State<WasultPressButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onPressed != null;
    final button = Semantics(
      button: true,
      enabled: enabled,
      label: widget.label,
      child: GestureDetector(
        onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
        onTapCancel: enabled ? () => setState(() => _pressed = false) : null,
        onTapUp: enabled
            ? (_) {
                setState(() => _pressed = false);
                widget.onPressed?.call();
              }
            : null,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 90),
          transform: Matrix4.translationValues(0, _pressed ? 4 : 0, 0),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          decoration: BoxDecoration(
            color: enabled ? widget.color : const Color(0xFFB8C4C4),
            borderRadius: BorderRadius.circular(18),
            boxShadow: _pressed || !enabled
                ? const []
                : [BoxShadow(color: Color.lerp(widget.color, Colors.black, .32)!, offset: const Offset(0, 5))],
          ),
          child: Row(
            mainAxisSize: widget.expanded ? MainAxisSize.max : MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(widget.icon, color: Colors.white),
              const SizedBox(width: 10),
              Flexible(child: Text(widget.label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16))),
            ],
          ),
        ),
      ),
    );
    return widget.expanded ? SizedBox(width: double.infinity, child: button) : button;
  }
}

class WasultPanel extends StatelessWidget {
  const WasultPanel({super.key, required this.child, this.padding = const EdgeInsets.all(18), this.color});
  final Widget child;
  final EdgeInsets padding;
  final Color? color;

  @override
  Widget build(BuildContext context) => Container(
        padding: padding,
        decoration: BoxDecoration(
          color: color ?? Colors.white,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: const Color(0xFFE2EBEA)),
          boxShadow: const [BoxShadow(color: Color(0x10002022), blurRadius: 22, offset: Offset(0, 10))],
        ),
        child: child,
      );
}

class WasultStatusPill extends StatelessWidget {
  const WasultStatusPill({super.key, required this.label, required this.color, this.icon = Icons.circle});
  final String label;
  final Color color;
  final IconData icon;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
        decoration: BoxDecoration(color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(999)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 6),
          Text(label, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w800)),
        ]),
      );
}
