import 'dart:convert';

import 'package:http/http.dart' as http;

import '../core/config/app_config.dart';
import 'session_store.dart';

class AdPlacementDecision {
  const AdPlacementDecision({required this.eligible, required this.reason});

  final bool eligible;
  final String reason;

  static const deny = AdPlacementDecision(
      eligible: false, reason: 'CLIENT_FAIL_CLOSED');
}

/// A render contract, not an image URL. The app must obtain any asset through
/// an authenticated media proxy and must discard this object if the eligibility
/// decision changes before rendering.
class AdCreativePlacement {
  const AdCreativePlacement({
    required this.campaignId,
    required this.inventoryId,
    required this.surface,
    required this.assetKey,
    required this.mimeType,
    required this.isFallback,
    required this.destinationUrl,
    required this.maxSessionImpressions,
  });

  final int? campaignId;
  final int inventoryId;
  final String surface;
  final String assetKey;
  final String mimeType;
  final bool isFallback;
  final String? destinationUrl;
  final int maxSessionImpressions;
}

/// Client-side integration point for the server-authoritative safety gate.
/// The caller must render no creative unless [eligible] is true.
class AdPlacementEligibilityClient {
  const AdPlacementEligibilityClient();
  static final Map<String, List<DateTime>> _sessionRenders = {};

  static bool _withinSessionCap(String surface, int cap) {
    final cutoff = DateTime.now().subtract(const Duration(minutes: 30));
    final renders = (_sessionRenders[surface] ?? []).where((at) => at.isAfter(cutoff)).toList();
    _sessionRenders[surface] = renders;
    return renders.length < cap;
  }

  /// Call only after a placement is actually visible. This is an in-memory
  /// session cap; it intentionally does not create a user/device ad profile.
  static void markRendered(AdCreativePlacement placement) {
    final renders = _sessionRenders.putIfAbsent(placement.surface, () => []);
    renders.add(DateTime.now());
  }

  Future<AdPlacementDecision> check(String surface) async {
    if (AppConfig.mockMode) {
      return const AdPlacementDecision(
          eligible: false, reason: 'MOCK_AD_SERVING_DISABLED');
    }
    try {
      final token = await SessionStore.token();
      if (token == null || token.isEmpty) return AdPlacementDecision.deny;
      final uri = AppConfig.api('/api/v1/advertiser/placement-eligibility')
          .replace(queryParameters: {'surface': surface});
      final response = await http
          .get(uri, headers: {'Authorization': 'Bearer $token'})
          .timeout(const Duration(seconds: 5));
      final body = jsonDecode(response.body) as Map<String, dynamic>;
      if (response.statusCode != 200 || body['success'] != true) {
        return AdPlacementDecision.deny;
      }
      return AdPlacementDecision(
        eligible: body['eligible'] == true,
        reason: '${body['reason'] ?? 'UNKNOWN'}',
      );
    } catch (_) {
      return AdPlacementDecision.deny;
    }
  }

  /// Loads a single server-selected creative only after server approval. Mock
  /// mode deliberately returns null, ensuring demonstration screens never
  /// accidentally appear to target real users.
  Future<AdCreativePlacement?> fetchPlacement({
    required String surface,
    required String coarseDistrict,
  }) async {
    if (AppConfig.mockMode) return null;
    try {
      final token = await SessionStore.token();
      if (token == null || token.isEmpty) return null;
      final uri = AppConfig.api('/api/v1/advertiser/placements').replace(
          queryParameters: {'surface': surface, 'district': coarseDistrict});
      final response = await http
          .get(uri, headers: {'Authorization': 'Bearer $token'})
          .timeout(const Duration(seconds: 5));
      final body = jsonDecode(response.body) as Map<String, dynamic>;
      if (response.statusCode != 200 || body['success'] != true) {
        return null;
      }
      final placement = body['placement'];
      final fallback = body['fallback'];
      if (placement is! Map && fallback is! Map) return null;
      final contract = placement is Map ? placement : fallback as Map;
      final asset = contract['asset'];
      if (asset is! Map || contract['inventoryId'] is! num
          || (placement is Map && contract['campaignId'] is! num)) {
        return null;
      }
      final cap = contract['maxSessionImpressions'] is num
          ? (contract['maxSessionImpressions'] as num).toInt()
          : 3;
      if (cap < 1 || !_withinSessionCap('${contract['surface']}', cap)) return null;
      return AdCreativePlacement(
        campaignId: placement is Map ? (contract['campaignId'] as num).toInt() : null,
        inventoryId: (contract['inventoryId'] as num).toInt(),
        surface: '${contract['surface']}',
        assetKey: '${asset['objectKey']}',
        mimeType: '${asset['mimeType']}',
        isFallback: placement is! Map,
        destinationUrl: placement is Map && contract['destinationUrl'] is String
            ? '${contract['destinationUrl']}'
            : null,
        maxSessionImpressions: cap,
      );
    } catch (_) {
      return null;
    }
  }

  Future<bool> recordEvent({
    required AdCreativePlacement placement,
    required String eventType,
    required String idempotencyKey,
    required String coarseDistrict,
  }) async {
    if (AppConfig.mockMode || placement.isFallback || placement.campaignId == null || !{'IMPRESSION', 'CLICK'}.contains(eventType)) return false;
    try {
      final token = await SessionStore.token();
      if (token == null || token.isEmpty) return false;
      final response = await http
          .post(AppConfig.api('/api/v1/advertiser/delivery-events'),
              headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
              body: jsonEncode({
                'campaignId': placement.campaignId,
                'inventoryId': placement.inventoryId,
                'eventType': eventType,
                'idempotencyKey': idempotencyKey,
                'district': coarseDistrict,
              }))
          .timeout(const Duration(seconds: 5));
      final body = jsonDecode(response.body) as Map<String, dynamic>;
      return response.statusCode < 300 && body['success'] == true;
    } catch (_) {
      return false;
    }
  }
}
