import 'package:audioplayers/audioplayers.dart';

/// Keeps audible route notifications consistent across each Wasult role.
/// The files are bundled locally, so an alert can play without a network call.
class AlertAudioService {
  AlertAudioService() {
    _player.setReleaseMode(ReleaseMode.stop);
  }

  final AudioPlayer _player = AudioPlayer();

  static const _sources = <String, String>{
    'alert': 'audio/alert.mpeg',
    'emergency': 'audio/emergency.mpeg',
    'critical': 'audio/critical_emergency.mpeg',
    'arrived': 'audio/arrived.aac',
  };

  Future<void> play(String severity) async {
    final source = _sources[severity] ?? _sources['alert']!;
    await _player.stop();
    await _player.play(AssetSource(source));
  }

  Future<void> dispose() => _player.dispose();
}
