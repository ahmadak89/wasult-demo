import 'dart:convert';
import 'package:http/http.dart' as http;
import '../core/config/app_config.dart';
import 'session_store.dart';

class EmergencyAlertClient {
  const EmergencyAlertClient();
  Future<bool> dispatch(
      {required String templateKey, String? customText}) async {
    if (AppConfig.mockMode) return false;
    try {
      final token = await SessionStore.token();
      if (token == null || token.isEmpty) return false;
      final response = await http
          .post(AppConfig.api('/api/v1/notifications/emergency'),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer $token'
              },
              body: jsonEncode({
                'templateKey': templateKey,
                if (customText != null) 'customText': customText
              }))
          .timeout(const Duration(seconds: 5));
      final body = jsonDecode(response.body);
      return response.statusCode == 202 &&
          body is Map &&
          body['success'] == true;
    } catch (_) {
      return false;
    }
  }
}
