import 'dart:convert';

import 'package:http/http.dart' as http;

import '../core/config/app_config.dart';
import 'session_store.dart';

class CorporateComplianceWarning {
  const CorporateComplianceWarning({
    required this.driverId,
    required this.driverName,
    required this.driverStatus,
    required this.documentStatus,
    required this.warningCode,
    this.expiryDate,
  });

  final String driverId;
  final String driverName;
  final String driverStatus;
  final String documentStatus;
  final String warningCode;
  final DateTime? expiryDate;

  factory CorporateComplianceWarning.fromJson(Map<String, dynamic> json) =>
      CorporateComplianceWarning(
        driverId: '${json['driver_id'] ?? ''}',
        driverName: '${json['full_name'] ?? ''}',
        driverStatus: '${json['status'] ?? ''}',
        documentStatus: '${json['document_status'] ?? ''}',
        warningCode: '${json['warning_code'] ?? ''}',
        expiryDate: json['document_expiry_date'] == null
            ? null
            : DateTime.tryParse('${json['document_expiry_date']}'),
      );
}

/// Accesses only the authenticated Corporate tenant's compliance warnings.
/// Super Admin tenant selection is intentionally not implemented here: it must
/// be made explicitly by the governed Super Admin workspace, not inferred by a
/// reusable client component.
class CorporateComplianceClient {
  const CorporateComplianceClient();

  Future<List<CorporateComplianceWarning>> warnings() async {
    if (AppConfig.mockMode) return const [];
    try {
      final token = await SessionStore.token();
      if (token == null || token.isEmpty) return const [];
      final response = await http
          .get(AppConfig.api('/api/v1/corporate/compliance-warnings'),
              headers: {'Authorization': 'Bearer $token'})
          .timeout(const Duration(seconds: 5));
      final body = jsonDecode(response.body);
      if (response.statusCode != 200 ||
          body is! Map ||
          body['success'] != true ||
          body['warnings'] is! List) return const [];
      return (body['warnings'] as List)
          .whereType<Map>()
          .map((row) => CorporateComplianceWarning.fromJson(
              Map<String, dynamic>.from(row)))
          .toList(growable: false);
    } catch (_) {
      return const [];
    }
  }
}
