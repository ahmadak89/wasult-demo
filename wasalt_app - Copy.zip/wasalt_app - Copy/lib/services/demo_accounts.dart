import 'package:flutter/foundation.dart';

@immutable
class DemoAccount {
  const DemoAccount(this.role, this.id, this.password, this.destination);
  final String role;
  final String id;
  final String password;
  final String destination;
}

abstract final class DemoAccounts {
  static const accounts = [
    DemoAccount('GUARDIAN', 'DEMO_PARENT', 'P26a1', '/map-multiplex'),
    DemoAccount('DRIVER', 'DEMO_DRIVER', 'DriverDemo2026!', '/driver-trip'),
    DemoAccount('CORPORATE_ADMIN', 'DEMO_CORP', 'CorpDemo2026!', '/corporate-admin'),
    DemoAccount('SUPER_ADMIN', 'DEMO_SUPER', 'SuperDemo2026!', '/super-admin'),
    DemoAccount('ADVERTISER', 'DEMO_ADVERT', 'AdvertDemo2026!', '/advertiser'),
  ];

  static DemoAccount? authenticate(String role, String id, String password) {
    for (final account in accounts) {
      if (account.role == role && account.id == id && account.password == password) return account;
    }
    return null;
  }
}
