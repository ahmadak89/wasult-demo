import 'dart:convert';

import 'package:http/http.dart' as http;

import '../core/config/app_config.dart';
import 'session_store.dart';

/// Authenticated private-trip actions. The backend owns state transitions,
/// Driver assignment checks, timestamps, and audit evidence.
class PrivateTripClient {
  const PrivateTripClient();

  Future<bool> advanceExecution(
      {required String requestId, required String executionStatus}) async {
    if (AppConfig.mockMode ||
        requestId.trim().isEmpty ||
        !{'EnRoute', 'Boarded', 'Completed'}.contains(executionStatus))
      return false;
    try {
      final token = await SessionStore.token();
      if (token == null || token.isEmpty) return false;
      final response = await http
          .put(
              AppConfig.api(
                  '/api/v1/guardian/trip-requests/${Uri.encodeComponent(requestId)}/execution'),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer $token'
              },
              body: jsonEncode({'executionStatus': executionStatus}))
          .timeout(const Duration(seconds: 5));
      final body = jsonDecode(response.body);
      return response.statusCode == 200 &&
          body is Map &&
          body['success'] == true;
    } catch (_) {
      return false;
    }
  }

  Future<bool> decide(
      {required String requestId,
      required bool accepted,
      String? proposedPickupAt,
      String? driverNote}) async {
    if (AppConfig.mockMode || requestId.trim().isEmpty) return false;
    try {
      final token = await SessionStore.token();
      if (token == null || token.isEmpty) return false;
      final response = await http
          .put(
              AppConfig.api(
                  '/api/v1/guardian/trip-requests/${Uri.encodeComponent(requestId)}/decision'),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer $token'
              },
              body: jsonEncode({
                'status': accepted ? 'Confirmed' : 'Declined',
                if (proposedPickupAt != null)
                  'proposedPickupAt': proposedPickupAt,
                if (driverNote != null) 'driverNote': driverNote
              }))
          .timeout(const Duration(seconds: 5));
      final body = jsonDecode(response.body);
      return response.statusCode == 200 &&
          body is Map &&
          body['success'] == true;
    } catch (_) {
      return false;
    }
  }
}
