import 'dart:convert';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Local demo state only. This is deliberately separate from production APIs.
class DemoStore extends ChangeNotifier {
  DemoStore._();
  static final DemoStore instance = DemoStore._();
  // New key seeds the expanded passenger, tenant and advertiser demo records.
  static const _key = 'wasult_five_role_demo_v3';
  SharedPreferences? _prefs;
  Map<String, dynamic> data = _seed();
  int revision = 0;

  Future<void> initialize() async {
    _prefs ??= await SharedPreferences.getInstance();
    await refresh();
  }

  Future<void> refresh() async {
    final prefs = _prefs;
    if (prefs == null) return;
    await prefs.reload();
    final raw = prefs.getString(_key);
    if (raw == null) {
      await _save();
      return;
    }
    try {
      final incoming = jsonDecode(raw) as Map<String, dynamic>;
      final nextRevision = incoming['revision'] as int? ?? 0;
      if (nextRevision > revision) {
        // Preserve a user's existing mock edits while introducing newly added
        // collections required by later role-workspace releases.
        for (final entry in _seed().entries) {
          incoming.putIfAbsent(entry.key, () => entry.value);
        }
        data = incoming;
        revision = nextRevision;
        notifyListeners();
      }
    } catch (_) {
      /* Ignore corrupt local demo state; keep the seeded preview. */
    }
  }

  List<Map<String, dynamic>> rows(String key) =>
      (data[key] as List).cast<Map<String, dynamic>>();
  String text(String key) => '${data[key] ?? ''}';
  double number(String key) => (data[key] as num?)?.toDouble() ?? 0;

  void update(void Function(Map<String, dynamic>) edit) {
    edit(data);
    revision = DateTime.now().microsecondsSinceEpoch;
    data['revision'] = revision;
    notifyListeners();
    _save();
  }

  Future<void> _save() async {
    final prefs = _prefs;
    if (prefs != null) await prefs.setString(_key, jsonEncode(data));
  }

  void add(String key, Map<String, dynamic> value, {String? notice}) =>
      update((state) {
        (state[key] as List).add(value);
        if (notice != null) _notice(state, notice);
      });

  void edit(String key, String id, Map<String, dynamic> fields,
          {String? notice}) =>
      update((state) {
        final row = (state[key] as List)
            .cast<Map<String, dynamic>>()
            .firstWhere((item) => item['id'] == id);
        row.addAll(fields);
        if (notice != null) _notice(state, notice);
      });

  void setValue(String key, dynamic value, {String? notice}) => update((state) {
        state[key] = value;
        if (notice != null) _notice(state, notice);
      });

  void announce(String text,
          {String audience = 'SYSTEM', String severity = 'alert'}) =>
      update((state) =>
          _notice(state, text, audience: audience, severity: severity));
  void _notice(Map<String, dynamic> state, String text,
      {String audience = 'SYSTEM', String severity = 'alert'}) {
    (state['notices'] as List).insert(0, {
      'id': 'N${DateTime.now().microsecondsSinceEpoch}',
      'text': text,
      'audience': audience,
      'severity': severity,
      'at': DateTime.now().toIso8601String(),
      'read': false,
    });
  }

  void markRead(String id) => edit('notices', id, {'read': true});
  String provisionToken() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final random = Random.secure();
    final code =
        List.generate(8, (_) => chars[random.nextInt(chars.length)]).join();
    return 'TG-${code.substring(0, 4)}-${code.substring(4)}';
  }

  static Map<String, dynamic> _seed() => {
        'revision': 0,
        'tripState': 'On the way',
        'walletJod': 32.50,
        'walletEgp': 0.0,
        'hardwareToken': '',
        'routeFrom': '',
        'routeTo': '',
        'brandColor': '#005B60',
        'corporateBrand': <String, dynamic>{
          'tenantId': 'TEN-01',
          'name': 'شركة عمّان للنقل',
          'mark': 'ع',
          'accentColor': '#005B60',
          'invoiceFooter': 'خدمات النقل المدرسي والمؤسسي',
          'logoData': '',
          'logoFileName': ''
        },
        'dailyAdRate': 12.50,
        'adSlots': <String>[
          'Splash screen',
          'Arrival banner',
          'Safe-arrival banner',
          'In-app map card',
          'Driver pre-route card',
          'Driver post-route card'
        ],
        'adSlotCatalog': <Map<String, dynamic>>[
          {
            'id': 'SLOT-01',
            'name': 'Splash screen',
            'dimensions': '1080 × 1920 px',
            'location': 'Launch screen',
            'safety': 'Approved contextual',
            'capacity': '1',
            'categoryExclusive': 'No'
          },
          {
            'id': 'SLOT-02',
            'name': 'Arrival banner',
            'dimensions': '1200 × 628 px',
            'location': 'Guardian post-trip summary only',
            'safety': 'After authoritative safety content',
            'capacity': '1',
            'categoryExclusive': 'Yes'
          },
          {
            'id': 'SLOT-03',
            'name': 'Driver pre-route card',
            'dimensions': '1200 × 628 px',
            'location': 'Driver inspection screen',
            'safety': 'Stationary only < 5 km/h',
            'capacity': '1',
            'categoryExclusive': 'No'
          },
          {
            'id': 'SLOT-04',
            'name': 'Driver post-route card',
            'dimensions': '1200 × 628 px',
            'location': 'Driver completion screen',
            'safety': 'Stationary only < 5 km/h',
            'capacity': '1',
            'categoryExclusive': 'No'
          },
        ],
        'adCities': <String>[
          'Amman',
          'Irbid',
          'Zarqa',
          'Aqaba',
          'Salt',
          'Madaba'
        ],
        'subscriptionPlans': <Map<String, dynamic>>[
          {
            'id': 'PLAN-STARTER',
            'name': 'Starter',
            'monthly': 49.0,
            'licenses': 10,
            'status': 'Active'
          },
          {
            'id': 'PLAN-BUSINESS',
            'name': 'Business Plus',
            'monthly': 149.0,
            'licenses': 25,
            'status': 'Active'
          },
        ],
        'corporateUsers': <Map<String, dynamic>>[
          {
            'id': 'USR-CORP-01',
            'name': 'رنا حداد',
            'tenant': 'TEN-01',
            'role': 'CORPORATE_ADMIN',
            'status': 'Active'
          },
        ],
        'systemIntegrations': <Map<String, dynamic>>[
          {
            'id': 'INT-GA4',
            'name': 'Google Analytics 4',
            'category': 'Analytics',
            'publicConfig': 'measurementId: G-XXXXXXXXXX',
            'secretRef': 'Not required',
            'status': 'Disabled'
          },
          {
            'id': 'INT-MAPS',
            'name': 'OpenStreetMap / geocoding',
            'category': 'Maps',
            'publicConfig': 'provider: OpenStreetMap',
            'secretRef': 'VAULT:maps/geocoder',
            'status': 'Active'
          },
          {
            'id': 'INT-FIREBASE',
            'name': 'Firebase notifications',
            'category': 'Messaging',
            'publicConfig': 'projectId: wasult-prod',
            'secretRef': 'VAULT:firebase/server-key',
            'status': 'Pending'
          },
          {
            'id': 'INT-WA',
            'name': 'WhatsApp Business',
            'category': 'Messaging',
            'publicConfig': 'sender: +962…',
            'secretRef': 'VAULT:whatsapp/access-token',
            'status': 'Pending'
          },
          {
            'id': 'INT-CLIQ',
            'name': 'CliQ Jordan',
            'category': 'Payments',
            'publicConfig': 'apiUrl: https://sandbox.example',
            'secretRef': 'VAULT:payments/cliq',
            'status': 'Pending'
          },
          {
            'id': 'INT-ZAIN',
            'name': 'Zain Cash',
            'category': 'Payments',
            'publicConfig': 'apiUrl: https://sandbox.example',
            'secretRef': 'VAULT:payments/zain-cash',
            'status': 'Pending'
          },
          {
            'id': 'INT-FAWRY',
            'name': 'Fawry',
            'category': 'Payments',
            'publicConfig': 'apiUrl: https://sandbox.example',
            'secretRef': 'VAULT:payments/fawry',
            'status': 'Pending'
          },
        ],
        'paymentGateways': <Map<String, dynamic>>[
          {
            'id': 'PAY-CLIQ',
            'name': 'CliQ Jordan',
            'logo': '🏦',
            'apiUrl': 'https://sandbox.example/cliq',
            'status': 'Pending'
          },
          {
            'id': 'PAY-ZAIN',
            'name': 'Zain Cash',
            'logo': '📱',
            'apiUrl': 'https://sandbox.example/zain',
            'status': 'Pending'
          },
          {
            'id': 'PAY-FAWRY',
            'name': 'Fawry',
            'logo': '💳',
            'apiUrl': 'https://sandbox.example/fawry',
            'status': 'Pending'
          },
        ],
        'featureFlags': <Map<String, dynamic>>[
          {
            'id': 'FLAG-01',
            'key': 'new_reports',
            'name': 'التقارير المحسنة',
            'enabled': true,
            'rollout': 25,
            'tenants': 'TEN-01',
            'reason': 'تشغيل تجريبي مع فريق العمليات'
          },
          {
            'id': 'FLAG-02',
            'key': 'wallet_v2',
            'name': 'محفظة متعددة العملات',
            'enabled': false,
            'rollout': 0,
            'tenants': '—',
            'reason': 'بانتظار اعتماد المالية'
          },
        ],
        'tripRequests': <Map<String, dynamic>>[
          {
            'id': 'TRIP-1001',
            'passengerId': 'PAS-101',
            'passengerName': 'سامي',
            'driverId': 'DRV-101',
            'startAddress': 'عبدون، عمّان',
            'endAddress': 'Amman Academy، عمّان',
            'date': '2026-09-23',
            'time': '07:20',
            'status': 'Confirmed'
          },
        ],
        'drivers': <Map<String, dynamic>>[
          {
            'id': 'DRV-101',
            'name': 'أحمد الخطيب',
            'plate': 'AM 55421',
            'status': 'Active',
            'route': 'Amman 04',
            'capacity': 18,
            'used': 9,
            'phone': '+962790001101',
            'shareCode': 'WASULT-DRV-101',
            'documentStatus': 'Approved',
            'documentExpiry': '2027-06-30'
          },
          {
            'id': 'DRV-102',
            'name': 'ليث منصور',
            'plate': 'AM 99212',
            'status': 'Pending',
            'route': 'Amman 12',
            'capacity': 16,
            'used': 7,
            'phone': '+962790001102',
            'shareCode': 'WASULT-DRV-102',
            'documentStatus': 'Pending',
            'documentExpiry': '—'
          },
        ],
        'children': <Map<String, dynamic>>[
          {
            'id': 'PAS-101',
            'name': 'سامي',
            'school': 'Amman Academy',
            'route': 'Amman 04',
            'status': 'Active',
            'attendance': 'Waiting',
            'pickupAddress': 'عبدون، عمّان',
            'dropoffAddress': 'Amman Academy، عمّان',
            'pickupFromDate': '2026-09-01',
            'pickupToDate': '2027-06-30',
            'pickupTime': '07:20',
            'pickupDays': 'Sunday-Thursday',
            'assignedDriver': 'DRV-101'
          },
          {
            'id': 'PAS-102',
            'name': 'يارا',
            'school': 'International Academy Amman',
            'route': 'Amman 12',
            'status': 'Active',
            'attendance': 'Waiting',
            'pickupAddress': 'دابوق، عمّان',
            'dropoffAddress': 'International Academy Amman، عمّان'
          },
        ],
        'attendanceEvents': <Map<String, dynamic>>[
          {
            'id': 'ATT-001',
            'childId': 'PAS-101',
            'eventType': 'BOARDED',
            'verificationMethod': 'QR',
            'at': '2026-09-23 07:21'
          }
        ],
        'absenceReports': <Map<String, dynamic>>[],
        'serviceAssignments': <Map<String, dynamic>>[
          {
            'id': 'SAS-101',
            'passengerId': 'PAS-101',
            'driverId': 'DRV-101',
            'segment': 'MORNING',
            'role': 'PRIMARY',
            'effectiveFrom': '2026-09-01',
            'effectiveTo': '2027-06-30',
            'status': 'Active',
            'linkedVia': 'Corporate binding'
          },
          {
            'id': 'SAS-102',
            'passengerId': 'PAS-102',
            'driverId': 'DRV-101',
            'segment': 'MORNING',
            'role': 'SUBSTITUTE',
            'effectiveFrom': '2026-09-01',
            'effectiveTo': '2027-06-30',
            'status': 'Active',
            'linkedVia': 'Corporate binding'
          }
        ],
        'substituteActivations': <Map<String, dynamic>>[],
        'tenants': <Map<String, dynamic>>[
          {
            'id': 'TEN-01',
            'name': 'شركة عمّان للنقل',
            'tier': 'Business Plus',
            'status': 'Active',
            'licenses': 25,
            'contactPerson': 'رنا حداد',
            'mobile': '+962790001200',
            'whatsapp': '+962790001200',
            'registration': 'JOR-TRN-2024-1042',
            'city': 'Amman',
            'country': 'Jordan',
            'addressLine1': 'شارع زهران، عبدون',
            'description': 'مشغل نقل مدرسي وموظفين',
            'dateRegistered': '2024-01-15'
          },
          {
            'id': 'TEN-02',
            'name': 'مدارس العاصمة',
            'tier': 'Education',
            'status': 'Pending',
            'licenses': 12,
            'contactPerson': 'خالد سمير',
            'mobile': '+962790001201',
            'whatsapp': '+962790001201',
            'registration': 'JOR-EDU-2025-224',
            'city': 'Amman',
            'country': 'Jordan',
            'addressLine1': 'الشميساني، عمّان',
            'description': 'إدارة نقل المدارس',
            'dateRegistered': '2025-09-02'
          },
        ],
        'devices': <Map<String, dynamic>>[
          {
            'id': 'GPS-01',
            'imei': '860432014992715',
            'name': 'Amman Tracker 01',
            'route': 'Amman 12',
            'status': 'Online',
            'token': 'TG-AMMN-2626',
            'ignition': 'On'
          },
        ],
        'campaigns': <Map<String, dynamic>>[
          {
            'id': 'AD-01',
            'name': 'Back to School',
            'slot': 'Arrival banner',
            'district': 'Amman',
            'budget': 387.5,
            'dailyRate': 12.5,
            'days': 31,
            'status': 'Draft',
            'start': '2026-09-21',
            'end': '2026-10-21',
            'asset': 'Generic Wasult banner',
            'imageUrl': '',
            'targetApp': 'Guardian App',
            'daypart': 'All approved hours',
            'pricingModel': 'CPD',
            'advertiserCategory': 'Education',
            'dailyBudgetJod': '12.50',
            'deliverySpend': 0,
          },
        ],
        'adComplianceReports': <Map<String, dynamic>>[
          {
            'id': 'ACR-01',
            'campaignId': 'AD-01',
            'campaign': 'Back to School',
            'reason': 'WRONG_PLACEMENT',
            'details': 'تمت ملاحظة الإعلان خارج موضع الملخص بعد الرحلة.',
            'status': 'Open',
            'at': '2026-09-25 09:15'
          },
        ],
        'adBudgetAlerts': <Map<String, dynamic>>[
          {
            'id': 'ABA-01',
            'campaign': 'Back to School',
            'threshold': '80%',
            'spend': '10.00 JOD',
            'budget': '12.50 JOD',
            'status': 'New'
          }
        ],
        'adRateCards': <Map<String, dynamic>>[
          {
            'id': 'RATE-01',
            'surface': 'HOME_CONTEXTUAL',
            'model': 'CPD',
            'city': 'All cities',
            'rate': '12.50 JOD/day',
            'status': 'Active'
          },
          {
            'id': 'RATE-02',
            'surface': 'PRE_ROUTE',
            'model': 'CPD',
            'city': 'All cities',
            'rate': '8.00 JOD/day',
            'status': 'Active'
          }
        ],
        'rules': <Map<String, dynamic>>[
          {
            'id': 'GR-01',
            'name': 'Late cancellation',
            'amount': 2.50,
            'status': 'Active'
          },
          {
            'id': 'GR-02',
            'name': 'No-show',
            'amount': 5.00,
            'status': 'Active'
          },
        ],
        'notices': <Map<String, dynamic>>[
          {
            'id': 'N1',
            'text': 'Amman 04 is approaching the first stop.',
            'audience': 'ALL',
            'at': '2026-09-21T08:00:00',
            'read': false
          },
          {
            'id': 'N2',
            'text': 'Driver DRV-102 awaits document approval.',
            'audience': 'CORPORATE_ADMIN',
            'at': '2026-09-21T07:45:00',
            'read': false
          },
        ],
        'ledger': <Map<String, dynamic>>[
          {
            'id': 'L1',
            'text': 'Opening demo balance',
            'amount': 32.50,
            'currency': 'JOD',
            'at': '2026-09-21'
          },
        ],
        'adminAccounts': <Map<String, dynamic>>[
          {
            'id': 'ADM-01',
            'name': 'ليان العبدالله',
            'role': 'SUPER_ADMIN',
            'mfa': 'Required',
            'status': 'Active'
          },
          {
            'id': 'ADM-02',
            'name': 'فريق مالية عمّان',
            'role': 'BILLING_REVIEWER',
            'mfa': 'Required',
            'status': 'Active'
          },
        ],
        'settlements': <Map<String, dynamic>>[
          {
            'id': 'SET-01',
            'tenant': 'TEN-01',
            'amount': 240.00,
            'currency': 'JOD',
            'status': 'Pending review'
          },
          {
            'id': 'SET-02',
            'tenant': 'TEN-02',
            'amount': 75.00,
            'currency': 'JOD',
            'status': 'Approved'
          },
        ],
        'licenseRequests': <Map<String, dynamic>>[
          {
            'id': 'LIC-01',
            'tenant': 'TEN-01',
            'licenses': 8,
            'reason': 'New school routes for the coming term',
            'status': 'Pending'
          },
        ],
        'incidents': <Map<String, dynamic>>[
          {
            'id': 'INC-01',
            'title': 'Tracker signal interruption — Amman 12',
            'severity': 'Medium',
            'owner': 'Operations',
            'status': 'Investigating'
          },
          {
            'id': 'INC-02',
            'title': 'Payment webhook retry',
            'severity': 'Low',
            'owner': 'Finance',
            'status': 'Open'
          },
        ],
        'fleetAlerts': <Map<String, dynamic>>[
          {
            'id': 'FAL-01',
            'title': 'Vehicle heartbeat overdue',
            'type': 'OFFLINE_OUTSIDE_TOLERANCE',
            'vehicle': 'AM 55421',
            'at': '2026-09-24T08:43:00',
            'status': 'New'
          },
          {
            'id': 'FAL-02',
            'title': 'Authorized adult verification pending',
            'type': 'CUSTODY_PENDING',
            'vehicle': 'AM 55421',
            'at': '2026-09-24T08:39:00',
            'status': 'New'
          },
          {
            'id': 'FAL-03',
            'title': 'Route deviation requires review',
            'type': 'OFF_ROUTE',
            'vehicle': 'AM 33218',
            'at': '2026-09-24T08:31:00',
            'status': 'Acknowledged'
          },
          {
            'id': 'FAL-04',
            'title': 'Harsh braking confidence threshold met',
            'type': 'DRIVING_RISK',
            'vehicle': 'AM 33218',
            'at': '2026-09-24T08:24:00',
            'status': 'New'
          },
        ],
        'serviceModeMetrics': <Map<String, dynamic>>[
          {
            'name': 'K–12 transport',
            'detail': 'Custody workflows and school manifests',
            'utilization': 82,
            'status': 'Healthy',
            'report': 'الحضانة والحضور'
          },
          {
            'name': 'Corporate shuttle',
            'detail': 'Seat bookings and waitlist capacity',
            'utilization': 68,
            'status': 'Watch',
            'report': 'أنماط الخدمة والاستخدام'
          },
          {
            'name': 'Protected on-demand rides',
            'detail': 'Driver approval and journey milestones',
            'utilization': 44,
            'status': 'Healthy',
            'report': 'أنماط الخدمة والاستخدام'
          },
        ],
        'driverEntities': <Map<String, dynamic>>[
          {
            'id': 'ENT-DRV-101',
            'name': 'أحمد الخطيب',
            'type': 'Human driver / Mobile app',
            'tenant': 'TEN-01',
            'vehicle': 'AM 55421',
            'detail': 'License verified • Arabic • Motion lock enabled',
            'status': 'Active'
          },
          {
            'id': 'ENT-GPS-8841',
            'name': 'GPS Tracker 8841',
            'type': 'Hardware tracker',
            'tenant': 'TEN-01',
            'vehicle': 'AM 33218',
            'detail': 'IMEI verified • firmware 3.2 • heartbeat online',
            'status': 'Active'
          },
          {
            'id': 'ENT-GPS-9902',
            'name': 'GPS Tracker 9902',
            'type': 'Hardware tracker',
            'tenant': 'TEN-02',
            'vehicle': 'AM 77403',
            'detail': 'SIM renewal pending • last heartbeat 14 min ago',
            'status': 'Hold'
          },
        ],
        'corporateInvoices': <Map<String, dynamic>>[
          {
            'id': 'INV-COR-2026-041',
            'tenant': 'TEN-01',
            'description': 'Business Plus licenses and telemetry maintenance',
            'amount': 322.00,
            'currency': 'JOD',
            'dueDate': '2026-10-01',
            'status': 'Due'
          },
          {
            'id': 'INV-COR-2026-042',
            'tenant': 'TEN-02',
            'description': 'Starter plan renewal',
            'amount': 49.00,
            'currency': 'JOD',
            'dueDate': '2026-09-20',
            'status': 'Paid'
          },
        ],
        'advertisers': <Map<String, dynamic>>[
          {
            'id': 'ADV-01',
            'name': 'Jordan Learning Books',
            'category': 'Education retail',
            'credit': 850.00,
            'currency': 'JOD',
            'campaigns': 2,
            'status': 'Active'
          },
          {
            'id': 'ADV-02',
            'name': 'Amman Family Market',
            'category': 'Retail',
            'credit': 0.00,
            'currency': 'JOD',
            'campaigns': 1,
            'status': 'Credit hold'
          },
        ],
        'retentionPolicies': <Map<String, dynamic>>[
          {
            'id': 'RET-01',
            'name': 'Telemetry history',
            'period': '180 days',
            'status': 'Active'
          },
          {
            'id': 'RET-02',
            'name': 'Audit events',
            'period': '7 years',
            'status': 'Active'
          },
        ],
        'audit': <Map<String, dynamic>>[],
      };
}
