// C:\src\wasalt_app\lib\services\passenger_qr_encoder.dart
import 'dart:convert';
import 'package:crypto/crypto.dart';

class PassengerQrEncoder {
  // Shared secure system salt matching backend infrastructure verification blocks
  final String verificationSalt = "wasult_qatar_mena_secure_secret_2026";

  /// Computes a rolling, time-locked authorization string valid for exactly 90 seconds
  String buildDynamicPayloadFrame(String passengerId) {
    final int dynamicTimestampWindow = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    
    // Construct sequential structural message sequence
    final String compoundMessage = "$passengerId:$dynamicTimestampWindow";
    
    // Calculate precise SHA-256 HMAC signature array hash
    final List<int> structuralKeys = utf8.encode(verificationSalt);
    final List<int> telemetryMessageBytes = utf8.encode(compoundMessage);
    final Hmac hmacEngine = Hmac(sha256, structuralKeys);
    final Digest digitalSignature = hmacEngine.convert(telemetryMessageBytes);

    // Formats production-ready dispatch capsule parameter pattern matches
    return "wasult_payload_struct:$passengerId:$dynamicTimestampWindow:${digitalSignature.toString()}";
  }
}
