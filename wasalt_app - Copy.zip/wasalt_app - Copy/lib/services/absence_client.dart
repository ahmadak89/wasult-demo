import 'dart:convert';

import 'package:http/http.dart' as http;

import '../core/config/app_config.dart';
import 'session_store.dart';

class AbsenceRecord {
  const AbsenceRecord({
    required this.id,
    required this.passengerId,
    required this.serviceDate,
    required this.tripSegment,
    required this.status,
    this.passengerName,
  });

  final int id;
  final String passengerId;
  final DateTime serviceDate;
  final String tripSegment;
  final String status;
  final String? passengerName;

  factory AbsenceRecord.fromJson(Map<String, dynamic> json) => AbsenceRecord(
        id: (json['absence_id'] as num?)?.toInt() ?? 0,
        passengerId: '${json['child_id'] ?? ''}',
        passengerName: json['passenger_name']?.toString(),
        serviceDate: DateTime.tryParse('${json['service_date'] ?? ''}') ??
            DateTime.fromMillisecondsSinceEpoch(0),
        tripSegment: '${json['trip_segment'] ?? ''}',
        status: '${json['status'] ?? ''}',
      );
}

/// Guardian-owned absence API. Requests are not queued offline because a stale
/// absence could make the Driver manifest unsafe; the caller must show a retry
/// state instead of treating a local action as confirmed.
class AbsenceClient {
  const AbsenceClient();

  Future<bool> submit({
    required String passengerId,
    required DateTime serviceDate,
    required String tripSegment,
    String? reason,
  }) async {
    if (AppConfig.mockMode || !{'MORNING', 'AFTERNOON', 'BOTH'}.contains(tripSegment)) return false;
    try {
      final token = await SessionStore.token();
      if (token == null || token.isEmpty) return false;
      final response = await http
          .post(AppConfig.api('/api/v1/guardian/absences'),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer $token',
              },
              body: jsonEncode({
                'childId': passengerId,
                'serviceDate': serviceDate.toIso8601String().substring(0, 10),
                'tripSegment': tripSegment,
                if (reason != null && reason.trim().isNotEmpty) 'reason': reason.trim(),
              }))
          .timeout(const Duration(seconds: 5));
      final body = jsonDecode(response.body);
      return response.statusCode < 300 && body is Map && body['success'] == true;
    } catch (_) {
      return false;
    }
  }

  Future<List<AbsenceRecord>> list() async {
    if (AppConfig.mockMode) return const [];
    try {
      final token = await SessionStore.token();
      if (token == null || token.isEmpty) return const [];
      final response = await http
          .get(AppConfig.api('/api/v1/guardian/absences'),
              headers: {'Authorization': 'Bearer $token'})
          .timeout(const Duration(seconds: 5));
      final body = jsonDecode(response.body);
      if (response.statusCode != 200 || body is! Map || body['success'] != true || body['absences'] is! List) return const [];
      return (body['absences'] as List).whereType<Map>().map(
          (row) => AbsenceRecord.fromJson(Map<String, dynamic>.from(row))).toList(growable: false);
    } catch (_) {
      return const [];
    }
  }

  Future<bool> cancel(int absenceId) async {
    if (AppConfig.mockMode || absenceId < 1) return false;
    try {
      final token = await SessionStore.token();
      if (token == null || token.isEmpty) return false;
      final response = await http
          .put(AppConfig.api('/api/v1/guardian/absences/$absenceId/cancel'),
              headers: {'Authorization': 'Bearer $token'})
          .timeout(const Duration(seconds: 5));
      final body = jsonDecode(response.body);
      return response.statusCode < 300 && body is Map && body['success'] == true;
    } catch (_) {
      return false;
    }
  }
}
