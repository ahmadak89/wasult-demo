import 'dart:convert';
import 'package:http/http.dart' as http;
import '../core/config/app_config.dart';
import 'session_store.dart';

class JourneyCompletionClient {
  const JourneyCompletionClient();
  Future<Map<String, String>> _headers() async => {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ${await SessionStore.token() ?? ''}'
      };
  Future<bool> submitFeedback(
      {required String passengerId,
      required String category,
      int? rating,
      String? comment}) async {
    if (AppConfig.mockMode) return false;
    try {
      final r = await http
          .post(AppConfig.api('/api/v1/guardian/journey-feedback'),
              headers: await _headers(),
              body: jsonEncode({
                'childId': passengerId,
                'category': category,
                if (rating != null) 'rating': rating,
                if (comment != null) 'comment': comment
              }))
          .timeout(const Duration(seconds: 5));
      final b = jsonDecode(r.body);
      return r.statusCode == 201 && b is Map && b['success'] == true;
    } catch (_) {
      return false;
    }
  }

  Future<bool> submitShiftReport(
      {required DateTime serviceDate,
      required String segment,
      required String summary,
      int incidentCount = 0}) async {
    if (AppConfig.mockMode) return false;
    try {
      final r = await http
          .post(AppConfig.api('/api/v1/driver/shift-reports'),
              headers: await _headers(),
              body: jsonEncode({
                'serviceDate': serviceDate.toIso8601String().substring(0, 10),
                'serviceSegment': segment,
                'summary': summary,
                'incidentCount': incidentCount
              }))
          .timeout(const Duration(seconds: 5));
      final b = jsonDecode(r.body);
      return r.statusCode == 201 && b is Map && b['success'] == true;
    } catch (_) {
      return false;
    }
  }
}
