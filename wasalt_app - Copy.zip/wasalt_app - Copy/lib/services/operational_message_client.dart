import 'dart:convert';

import 'package:http/http.dart' as http;

import '../core/config/app_config.dart';
import 'session_store.dart';

class OperationalMessage {
  const OperationalMessage(
      {required this.id,
      required this.senderId,
      required this.senderRole,
      required this.body,
      required this.createdAt,
      this.readAt});
  final int id;
  final String senderId, senderRole, body;
  final DateTime createdAt;
  final DateTime? readAt;
  factory OperationalMessage.fromJson(Map<String, dynamic> row) =>
      OperationalMessage(
        id: (row['message_id'] as num?)?.toInt() ?? 0,
        senderId: '${row['sender_id'] ?? ''}',
        senderRole: '${row['sender_role'] ?? ''}',
        body: '${row['body'] ?? ''}',
        createdAt: DateTime.tryParse('${row['created_at'] ?? ''}') ??
            DateTime.fromMillisecondsSinceEpoch(0),
        readAt: DateTime.tryParse('${row['read_at'] ?? ''}'),
      );
}

/// Private operational messaging. The server, not the UI, verifies Guardian-
/// Driver relationships and Corporate tenant membership before delivery.
class OperationalMessageClient {
  const OperationalMessageClient();
  dynamic _json(http.Response response) {
    final type = response.headers['content-type'] ?? '';
    if (!type.toLowerCase().contains('application/json')) return null;
    try { return jsonDecode(response.body); } catch (_) { return null; }
  }
  Future<Map<String, String>> _headers() async {
    final token = await SessionStore.token();
    return {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ${token ?? ''}'
    };
  }

  Future<List<OperationalMessage>> inbox() async {
    if (AppConfig.mockMode) return const [];
    try {
      final response = await http
          .get(AppConfig.api('/api/v1/notifications/messages/inbox'),
              headers: await _headers())
          .timeout(const Duration(seconds: 5));
      final body = _json(response);
      if (response.statusCode != 200 ||
          body is! Map ||
          body['messages'] is! List) return const [];
      return (body['messages'] as List)
          .whereType<Map>()
          .map((e) => OperationalMessage.fromJson(Map<String, dynamic>.from(e)))
          .toList(growable: false);
    } catch (_) {
      return const [];
    }
  }

  Future<bool> send(
      {required String recipientId,
      required String recipientRole,
      required String body}) async {
    if (AppConfig.mockMode || recipientId.trim().isEmpty || body.trim().isEmpty)
      return false;
    try {
      final response = await http
          .post(AppConfig.api('/api/v1/notifications/messages'),
              headers: await _headers(),
              body: jsonEncode({
                'recipientId': recipientId.trim(),
                'recipientRole': recipientRole,
                'body': body.trim()
              }))
          .timeout(const Duration(seconds: 5));
      final result = _json(response);
      return response.statusCode == 201 &&
          result is Map &&
          result['success'] == true;
    } catch (_) {
      return false;
    }
  }

  Future<bool> confirmRead(int messageId) async {
    if (AppConfig.mockMode || messageId < 1) return false;
    try {
      final response = await http
          .put(AppConfig.api('/api/v1/notifications/messages/$messageId/read'),
              headers: await _headers())
          .timeout(const Duration(seconds: 5));
      final result = _json(response);
      return response.statusCode == 200 &&
          result is Map &&
          result['success'] == true;
    } catch (_) {
      return false;
    }
  }

  Future<bool> clearFromInbox(int messageId) async {
    if (AppConfig.mockMode || messageId < 1) return false;
    try {
      final response = await http.delete(AppConfig.api('/api/v1/notifications/messages/$messageId'), headers: await _headers()).timeout(const Duration(seconds: 5));
      final result = _json(response);
      return response.statusCode == 200 && result is Map && result['success'] == true;
    } catch (_) { return false; }
  }
}
