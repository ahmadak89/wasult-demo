import 'package:flutter_secure_storage/flutter_secure_storage.dart';
class SessionStore {
  static const _storage=FlutterSecureStorage(aOptions:AndroidOptions(encryptedSharedPreferences:true));
  static Future<void> save({required String token,required String role,required String userId}) async { await Future.wait([_storage.write(key:'wasult_token',value:token),_storage.write(key:'wasult_role',value:role),_storage.write(key:'wasult_user_id',value:userId)]); }
  static Future<String?> token()=>_storage.read(key:'wasult_token');
  static Future<String?> role()=>_storage.read(key:'wasult_role');
  static Future<String?> userId()=>_storage.read(key:'wasult_user_id');
  static Future<void> clear()=>_storage.deleteAll();
}
