// wasalt_auth_cache.dart
import 'package:shared_preferences/shared_preferences.dart';

class WasaltAuthCache {
  static const String _keyUserId = "wasult_cached_user_id";
  static const String _keyUserRole = "wasult_cached_user_role";
  static const String _keyRememberMe = "wasult_remember_me_state";

  /// Commits session state metrics securely down to local storage configurations
  Future<void> saveUserSession({
    required String userId,
    required String role,
    required bool rememberMe,
  }) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    
    if (rememberMe) {
      await prefs.setString(_keyUserId, userId);
      await prefs.setString(_keyUserRole, role);
      await prefs.setBool(_keyRememberMe, true);
    } else {
      await clearSessionCache();
    }
  }

  /// Verifies active application initialization parameters on launch
  Future<Map<String, dynamic>?> checkPersistedSession() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final bool isRemembered = prefs.getBool(_keyRememberMe) ?? false;

    if (!isRemembered) return null;

    final String? cachedId = prefs.getString(_keyUserId);
    final String? cachedRole = prefs.getString(_keyUserRole);

    if (cachedId != null && cachedRole != null) {
      return {
        "userId": cachedId,
        "role": cachedRole,
      };
    }
    return null;
  }

  /// Explicit logout session invalidation rule
  Future<void> clearSessionCache() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyUserId);
    await prefs.remove(_keyUserRole);
    await prefs.setBool(_keyRememberMe, false);
  }
}
