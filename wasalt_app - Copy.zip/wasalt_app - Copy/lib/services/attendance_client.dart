import 'dart:convert';

import 'package:http/http.dart' as http;

import '../core/config/app_config.dart';
import 'session_store.dart';

class AttendanceEvent {
  const AttendanceEvent({
    required this.id,
    required this.passengerId,
    required this.eventType,
    required this.verificationMethod,
    required this.occurredAt,
    this.passengerName,
  });

  final int id;
  final String passengerId;
  final String eventType;
  final String verificationMethod;
  final DateTime occurredAt;
  final String? passengerName;

  factory AttendanceEvent.fromJson(Map<String, dynamic> json) {
    return AttendanceEvent(
      id: (json['attendance_id'] as num?)?.toInt() ?? 0,
      passengerId: '${json['child_id'] ?? ''}',
      passengerName: json['passenger_name']?.toString(),
      eventType: '${json['event_type'] ?? ''}',
      verificationMethod: '${json['verification_method'] ?? ''}',
      occurredAt: DateTime.tryParse('${json['occurred_at'] ?? ''}') ?? DateTime.fromMillisecondsSinceEpoch(0),
    );
  }
}

/// Typed client for the server-authoritative attendance record. It deliberately
/// does not queue events offline: a locally queued boarding status could be
/// mistaken for verified custody information.
class AttendanceClient {
  const AttendanceClient();

  Future<bool> record({
    required String passengerId,
    required String eventType,
    required String verificationMethod,
  }) async {
    if (AppConfig.mockMode) return false;
    if (!{'BOARDED', 'DROPPED_OFF', 'NO_SHOW'}.contains(eventType) ||
        !{'MANUAL', 'QR'}.contains(verificationMethod)) return false;
    try {
      final token = await SessionStore.token();
      if (token == null || token.isEmpty) return false;
      final response = await http
          .post(AppConfig.api('/api/v1/driver/attendance'),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer $token',
              },
              body: jsonEncode({
                'childId': passengerId,
                'eventType': eventType,
                'verificationMethod': verificationMethod,
              }))
          .timeout(const Duration(seconds: 5));
      final body = jsonDecode(response.body);
      return response.statusCode < 300 && body is Map && body['success'] == true;
    } catch (_) {
      return false;
    }
  }

  Future<List<AttendanceEvent>> history({required bool guardian, int limit = 50}) async {
    if (AppConfig.mockMode) return const [];
    final boundedLimit = limit.clamp(1, guardian ? 100 : 200).toInt();
    try {
      final token = await SessionStore.token();
      if (token == null || token.isEmpty) return const [];
      final path = guardian ? '/api/v1/guardian/attendance' : '/api/v1/driver/attendance';
      final response = await http
          .get(AppConfig.api(path).replace(queryParameters: {'limit': '$boundedLimit'}),
              headers: {'Authorization': 'Bearer $token'})
          .timeout(const Duration(seconds: 5));
      final body = jsonDecode(response.body);
      if (response.statusCode != 200 || body is! Map || body['success'] != true || body['attendance'] is! List) return const [];
      return (body['attendance'] as List)
          .whereType<Map>()
          .map((row) => AttendanceEvent.fromJson(Map<String, dynamic>.from(row)))
          .toList(growable: false);
    } catch (_) {
      return const [];
    }
  }
}
