import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../core/config/app_config.dart';

class WasultOsmMap extends StatelessWidget {
  const WasultOsmMap({super.key, this.height = 300, this.onTap, this.selected, this.showFleet = true});
  final double height;
  final void Function(LatLng point)? onTap;
  final LatLng? selected;
  final bool showFleet;

  static const center = LatLng(31.9539, 35.9106);
  static const home = LatLng(31.9693, 35.8916);
  static const school = LatLng(31.9354, 35.9341);
  static const busA = LatLng(31.9528, 35.9106);
  static const busB = LatLng(31.9442, 35.8868);

  @override
  Widget build(BuildContext context) => SizedBox(
    height: height,
    child: ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: FlutterMap(
        key: ValueKey(selected?.toString() ?? 'fleet-map'),
        options: MapOptions(
          initialCenter: selected ?? center,
          initialZoom: 13.3,
          onTap: onTap == null ? null : (_, point) => onTap!(point),
        ),
        children: [
          TileLayer(
            urlTemplate: AppConfig.mockMode ? 'http://127.0.0.1:7360/{z}/{x}/{y}.png' : 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            userAgentPackageName: 'com.wasult.app',
          ),
          if (showFleet)
            PolylineLayer(polylines: [
              Polyline(points: [home, busA, school], color: Color(0xFF005B60), strokeWidth: 5),
              Polyline(points: [LatLng(31.9292, 35.8767), busB, school], color: Color(0xFFFFA500), strokeWidth: 5),
            ]),
          MarkerLayer(markers: [
            if (showFleet) ...[
              _marker(context, home, Icons.home_rounded, const Color(0xFF005B60), 'نقطة الانطلاق • عبدون، عمّان'),
              _marker(context, school, Icons.school_rounded, const Color(0xFF8D3D78), 'الوجهة • أكاديمية عمّان'),
              _marker(context, busA, Icons.directions_bus_rounded, const Color(0xFF005B60), 'Amman 04 • أحمد الخطيب • في الطريق'),
              _marker(context, busB, Icons.directions_bus_rounded, const Color(0xFFFFA500), 'Amman 12 • ليث منصور • مباشر'),
            ],
            if (selected != null) _marker(context, selected!, Icons.location_pin, Colors.red, 'الموقع المحدد'),
          ]),
          const RichAttributionWidget(attributions: [TextSourceAttribution('OpenStreetMap contributors')]),
        ],
      ),
    ),
  );

  static Marker _marker(BuildContext context, LatLng point, IconData icon, Color color, String label) => Marker(
    point: point,
    width: 44,
    height: 44,
    child: Tooltip(message: label, child: GestureDetector(
      onTap: () => showModalBottomSheet<void>(context: context, builder: (sheetContext) => SafeArea(child: ListTile(leading: Icon(icon, color: color), title: Text(label, style: const TextStyle(fontWeight: FontWeight.w900)), subtitle: Text('${point.latitude.toStringAsFixed(5)}, ${point.longitude.toStringAsFixed(5)}')))),
      child: Container(decoration: BoxDecoration(color: color, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 3)), child: Icon(icon, color: Colors.white, size: 23)),
    )),
  );
}
