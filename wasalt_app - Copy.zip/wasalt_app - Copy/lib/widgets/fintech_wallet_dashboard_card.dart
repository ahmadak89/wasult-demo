﻿// C:\src\wasalt_app\lib\widgets\fintech_wallet_dashboard_card.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../core/config/app_config.dart';
import '../services/session_store.dart';

class FintechWalletDashboardCard extends StatefulWidget {
  final String activeUserId;
  const FintechWalletDashboardCard({super.key, required this.activeUserId});

  @override
  State<FintechWalletDashboardCard> createState() => _FintechWalletDashboardCardState();
}

class _FintechWalletDashboardCardState extends State<FintechWalletDashboardCard> {
  bool _isArabic = true; // Language option defaulted to Arabic First
  bool _isSyncing = false;

  // Multi-Currency Ledger Storage Properties
  double _balanceJod = 0.00;
  double _balanceEgp = 0.00;
  String _accountLifecycleState = "Active";

  @override
  void initState() {
    super.initState();
    _syncWalletBalancesSnapshot();
  }

  /// Queries current wallet metrics directly via port 3000 Node infrastructure channels
  Future<void> _syncWalletBalancesSnapshot() async {
    setState(() => _isSyncing = true);
    try {
      final token = await SessionStore.token();
      final userId = await SessionStore.userId() ?? widget.activeUserId;
      if (token == null) return;
      final response = await http.get(AppConfig.api('/api/v1/wallet/transactions/$userId'), headers: {'Authorization': 'Bearer $token'});
      if (response.statusCode == 200 && (response.headers['content-type'] ?? '').toLowerCase().contains('application/json')) {
        // The summary card never manufactures a balance when the ledger API
        // returns only transaction rows. Detailed balances remain on the
        // authenticated wallet screen.
        setState(() => _accountLifecycleState = "Active");
      }
    } catch (e) {
      debugPrint("[Wasult Ledger Sync Exception Vector]: $e");
    } finally {
      setState(() => _isSyncing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool isSuspended = _accountLifecycleState.toLowerCase() == "suspended";

    return Directionality(
      textDirection: _isArabic ? TextDirection.rtl : TextDirection.ltr,
      child: Card(
        elevation: 3,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        color: isSuspended ? Colors.red[50] : Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Widget Header Panel Toggles Row Configuration
              Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.account_balance_wallet, color: Color(0xFF005B60)),
                      const SizedBox(width: 8),
                      Text(
                        _isArabic ? "محفظة رصيد وصلت" : "Wasult Wallet Balance Matrix",
                        style: const TextStyle(fontFamily: 'Al Messri', fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  IconButton(
                    icon: _isSyncing 
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) 
                      : const Icon(Icons.refresh, size: 20, color: Color(0xFF005B60)),
                    onPressed: _syncWalletBalancesSnapshot,
                  )
                ],
              ),
              const Divider(height: 24),

              // Multi-Currency Ledger Storage Display Matrices
              Row(
                children: [
                  Expanded(
                    child: _buildCurrencyBalanceBox(
                      label: _isArabic ? "رصيد الدينار الأردني" : "JOD Ledger Balance",
                      value: _balanceJod,
                      symbol: "JOD",
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildCurrencyBalanceBox(
                      label: _isArabic ? "رصيد الجنيه المصري" : "EGP Ledger Balance",
                      value: _balanceEgp,
                      symbol: "EGP",
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // Enforce lock warning banner states instantly if profile thresholds fall low [UC-6]
              if (isSuspended)
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: Colors.red[100], borderRadius: BorderRadius.circular(8)),
                  child: Row(
                    children: [
                      const Icon(Icons.error, color: Colors.red),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          _isArabic 
                            ? "الحساب معلق مؤقتاً لتجاوز حدود الائتمان! يرجى شحن الرصيد فوراً." 
                            : "Account is Suspended due to insufficient funds! Please top up.",
                          style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold, fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCurrencyBalanceBox({required String label, required double value, required String symbol}) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0xFF005B60).withOpacity(0.05), borderRadius: BorderRadius.circular(10)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
          const SizedBox(height: 4),
          Text(
            "${value.toStringAsFixed(2)} $symbol",
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF005B60)),
          ),
        ],
      ),
    );
  }
}
