﻿// C:\src\wasalt_app\lib\widgets\skip_pickup_bottom_sheet.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../core/config/app_config.dart';
import '../services/session_store.dart';

class SkipPickupBottomSheet extends StatefulWidget {
  final String passengerId;
  final String assignedDriverId;
  
  const SkipPickupBottomSheet({
    super.key, 
    required this.passengerId, 
    required this.assignedDriverId
  });

  @override
  State<SkipPickupBottomSheet> createState() => _SkipPickupBottomSheetState();
}

class _SkipPickupBottomSheetState extends State<SkipPickupBottomSheet> {
  bool _isArabic = true; // Language option defaulted to Arabic First
  bool _isSubmitting = false;
  DateTime _selectedTargetDate = DateTime.now().add(const Duration(days: 1)); // Default targets tomorrow

  /// Submits the predefined macro cancel intent to the Node service port 3000
  Future<void> _transmitSkipNotice() async {
    setState(() => _isSubmitting = true);
    final String formattedDateStr = "${_selectedTargetDate.year}-${_selectedTargetDate.month}-${_selectedTargetDate.day}";

    try {
      final token = await SessionStore.token();
      if (token == null) throw StateError('GUARDIAN_SESSION_REQUIRED');
      final response = await http.post(AppConfig.api('/api/v1/notifications/skip-pickup'), headers: {"Content-Type": "application/json", "Authorization": "Bearer $token"}, body: jsonEncode({"childId": widget.passengerId, "driverId": widget.assignedDriverId, "targetDate": formattedDateStr}));
      if (!(response.headers['content-type'] ?? '').toLowerCase().contains('application/json')) throw const FormatException('NON_JSON_API_RESPONSE');
      final Map<String, dynamic> responseData = jsonDecode(response.body) as Map<String, dynamic>;

      if (response.statusCode == 202 && responseData['success'] == true) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(
              _isArabic ? "تم إرسال إشعار عدم الحضور بنجاح" : "Skip notice successfully broadcasted.",
              style: const TextStyle(fontFamily: 'Al Messri'),
            ),
            backgroundColor: const Color(0xFF005B60),
          ));
          Navigator.pop(context); // Close sheet structural modal context view ports
        }
      } else {
        _showErrorSnackBar(_isArabic ? "فشل الإرسال، يرجى المحاولة لاحقاً" : "Unable to dispatch messaging packet.");
      }
    } catch (e) {
      _showErrorSnackBar(_isArabic ? "خطأ في الاتصال بالشبكة" : "Network layer pipeline exception.");
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  void _showErrorSnackBar(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg, style: const TextStyle(fontFamily: 'Al Messri')), backgroundColor: Colors.redAccent));
  }

  @override
  Widget build(BuildContext context) {
    final String formattedDateLabel = "${_selectedTargetDate.day}/${_selectedTargetDate.month}/${_selectedTargetDate.year}";

    return Directionality(
      textDirection: _isArabic ? TextDirection.rtl : TextDirection.ltr,
      child: Container(
        padding: const EdgeInsets.all(24.0),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(topLeft: Radius.circular(20), topRight: Radius.circular(20)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  _isArabic ? "إرسال إشعار عدم حضور" : "Send Predefined Skip Macro",
                  style: const TextStyle(fontFamily: 'Al Messri', fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF005B60)),
                ),
                TextButton(
                  onPressed: () => setState(() => _isArabic = !_isArabic),
                  child: Text(_isArabic ? "English" : "العربية", style: const TextStyle(fontWeight: FontWeight.bold)),
                )
              ],
            ),
            const SizedBox(height: 16),
            
            // Macro text string context preview area
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.grey.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
              child: Text(
                _isArabic 
                  ? "نص الرسالة: لن آتي لاستلام المستخدم/الطفل ذو المعرف [${widget.passengerId}] غداً"
                  : "Macro Text: Don't Come to pickup child ID Number [${widget.passengerId}] Tomorrow",
                style: const TextStyle(fontStyle: FontStyle.italic, fontSize: 13, color: Colors.black87),
              ),
            ),
            const SizedBox(height: 20),

            // Date picker display section configuration layout
            ListTile(
              leading: const Icon(Icons.calendar_today, color: Color(0xFF005B60)),
              title: Text(_isArabic ? "تاريخ إلغاء الرحلة" : "Target Cancellation Date"),
              trailing: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(border: Border.all(color: Colors.grey), borderRadius: BorderRadius.circular(8)),
                child: Text(formattedDateLabel, style: const TextStyle(fontWeight: FontWeight.bold)),
              ),
              onTap: () async {
                final DateTime? selected = await showDatePicker(
                  context: context,
                  initialDate: _selectedTargetDate,
                  firstDate: DateTime.now(),
                  lastDate: DateTime.now().add(const Duration(days: 14)),
                );
                if (selected != null) {
                  setState(() => _selectedTargetDate = selected);
                }
              },
            ),
            const SizedBox(height: 24),

            // Submit Button
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF005B60), // Dark Teal Corporate branding color
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: _isSubmitting ? null : _transmitSkipNotice,
              child: _isSubmitting
                  ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : Text(
                      _isArabic ? "إرسال التنبيه الفوري" : "Dispatch Skip Signal",
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'Al Messri'),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
