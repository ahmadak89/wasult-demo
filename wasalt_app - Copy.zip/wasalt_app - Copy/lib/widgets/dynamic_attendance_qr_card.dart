﻿// C:\src\wasalt_app\lib\widgets\dynamic_attendance_qr_card.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart'; // Ensure 'qr_flutter: ^4.1.0' is appended to pubspec.yaml
import '../services/passenger_qr_encoder.dart';

class DynamicAttendanceQrCard extends StatefulWidget {
  final String currentPassengerId;
  const DynamicAttendanceQrCard({super.key, required this.currentPassengerId});

  @override
  State<DynamicAttendanceQrCard> createState() => _DynamicAttendanceQrCardState();
}

class _DynamicAttendanceQrCardState extends State<DynamicAttendanceQrCard> {
  final PassengerQrEncoder _qrEncoder = PassengerQrEncoder();
  late String _activeEncryptedString;
  Timer? _rollingRefreshTimer;

  @override
  void initState() {
    super.initState();
    _recomputeActiveQrPayload();
    // Refresh frame string configuration bounds every 30 seconds to stay safely within the 90s tracking lifecycle window
    _rollingRefreshTimer = Timer.periodic(const Duration(seconds: 30), (timer) {
      _recomputeActiveQrPayload();
    });
  }

  void _recomputeActiveQrPayload() {
    setState(() {
      _activeEncryptedString = _qrEncoder.buildDynamicPayloadFrame(widget.currentPassengerId);
    });
  }

  @override
  void dispose() {
    _rollingRefreshTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      color: Colors.white,
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              "رمز الحضور الديناميكي",
              style: TextStyle(fontFamily: 'Al Messri', fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF005B60)),
            ),
            const SizedBox(height: 6),
            const Text(
              "امسح الرمز لتسجيل صعود أو نزول الحافلة بأمان",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13, color: Colors.grey),
            ),
            const SizedBox(height: 20),
            
            // Render high-density visual graphic matrix
            QrImageView(
              data: _activeEncryptedString,
              version: QrVersions.auto,
              size: 220.0,
              gapless: true,
              embeddedImageStyle: const QrEmbeddedImageStyle(size: Size(40, 40)),
              eyeStyle: const QrEyeStyle(eyeShape: QrEyeShape.square, color: Color(0xFF005B60)),
              dataModuleStyle: const QrDataModuleStyle(dataModuleShape: QrDataModuleShape.square, color: Color(0xFF005B60)),
            ),
            
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(
                  width: 12,
                  height: 12,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFFFFA500)),
                ),
                const SizedBox(width: 10),
                Text(
                  "يتغير الرمز تلقائياً لحماية التتبع",
                  style: TextStyle(fontSize: 12, color: Colors.grey[600], fontFamily: 'Al Messri'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
