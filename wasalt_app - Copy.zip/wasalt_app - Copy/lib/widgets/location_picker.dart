import 'dart:convert';
import 'package:flutter/material.dart';
import '../core/config/app_config.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import 'wasult_osm_map.dart';

class PickedLocation {
  const PickedLocation(this.point, this.address);
  final LatLng point;
  final String address;
}

class LocationPicker extends StatefulWidget {
  const LocationPicker({super.key, this.arabic = true, this.title = 'الموقع', this.initial});
  final bool arabic;
  final String title;
  final PickedLocation? initial;

  @override
  State<LocationPicker> createState() => _LocationPickerState();
}

class _LocationPickerState extends State<LocationPicker> {
  final search = TextEditingController();
  final address = TextEditingController();
  final map = MapController();
  LatLng? point;
  bool busy = false;
  String? error;
  List<PickedLocation> results = [];

  String t(String ar, String en) => widget.arabic ? ar : en;

  @override
  void initState() {
    super.initState();
    point = widget.initial?.point;
    address.text = widget.initial?.address ?? '';
  }

  @override
  void dispose() {
    search.dispose();
    address.dispose();
    map.dispose();
    super.dispose();
  }

  Future<void> locate() async {
    setState(() { busy = true; error = null; });
    try {
      if (!await Geolocator.isLocationServiceEnabled()) throw StateError('services');
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) throw StateError('permission');
      final current = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 12)));
      await select(LatLng(current.latitude, current.longitude));
    } catch (_) {
      if (mounted) setState(() => error = t('تعذر تحديد موقعك. ابحث أو ضع دبوساً على الخريطة.', 'Could not locate you. Search or place a pin.'));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> select(LatLng candidate) async {
    setState(() { point = candidate; results = []; error = null; address.text = '${candidate.latitude.toStringAsFixed(6)}, ${candidate.longitude.toStringAsFixed(6)}'; });
    try {
      final uri = Uri.https('nominatim.openstreetmap.org', '/reverse', {'format': 'jsonv2', 'lat': '${candidate.latitude}', 'lon': '${candidate.longitude}', 'accept-language': widget.arabic ? 'ar' : 'en'});
      final response = await http.get(uri, headers: {'User-Agent': 'WasultLocationPicker/1.0 (wasult.com)'}).timeout(const Duration(seconds: 8));
      if (response.statusCode == 200 && mounted && point == candidate) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        final label = '${data['display_name'] ?? ''}'.trim();
        if (label.isNotEmpty) setState(() => address.text = label);
      }
    } catch (_) { /* Coordinates remain usable when reverse lookup is unavailable. */ }
  }

  Future<void> searchPlace() async {
    final query = search.text.trim();
    if (query.length < 3) return;
    setState(() { busy = true; error = null; results = []; });
    try {
      final uri = Uri.https('nominatim.openstreetmap.org', '/search', {'format': 'jsonv2', 'q': query, 'limit': '5', 'addressdetails': '1', 'accept-language': widget.arabic ? 'ar' : 'en'});
      final response = await http.get(uri, headers: {'User-Agent': 'WasultLocationPicker/1.0 (wasult.com)'}).timeout(const Duration(seconds: 8));
      if (response.statusCode != 200) throw StateError('search');
      final data = jsonDecode(response.body) as List<dynamic>;
      if (mounted) setState(() => results = data.map((item) { final row = item as Map<String, dynamic>; return PickedLocation(LatLng(double.parse('${row['lat']}'), double.parse('${row['lon']}')), '${row['display_name']}'); }).toList());
    } catch (_) {
      if (mounted) setState(() => error = t('تعذر البحث حالياً. يمكنك وضع دبوس يدوياً.', 'Search unavailable. You can place a pin manually.'));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: widget.arabic ? TextDirection.rtl : TextDirection.ltr,
    child: Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: SafeArea(child: Column(children: [
        Padding(padding: const EdgeInsets.all(12), child: Row(children: [
          Expanded(child: TextField(controller: search, textInputAction: TextInputAction.search, onSubmitted: (_) => searchPlace(), decoration: InputDecoration(labelText: t('ابحث عن عنوان أو مكان', 'Search address or place'), prefixIcon: const Icon(Icons.search)))),
          IconButton.filledTonal(onPressed: busy ? null : searchPlace, icon: const Icon(Icons.search)),
          IconButton.filledTonal(onPressed: busy ? null : locate, tooltip: t('موقعي الحالي', 'My current location'), icon: const Icon(Icons.my_location)),
        ])),
        if (busy) const LinearProgressIndicator(),
        if (error != null) Padding(padding: const EdgeInsets.symmetric(horizontal: 14), child: Text(error!, style: const TextStyle(color: Colors.red))),
        if (results.isNotEmpty) SizedBox(height: 170, child: ListView.builder(itemCount: results.length, itemBuilder: (context, index) { final item = results[index]; return ListTile(leading: const Icon(Icons.place_outlined), title: Text(item.address, maxLines: 2, overflow: TextOverflow.ellipsis), onTap: () { map.move(item.point, 15); select(item.point); }); })),
        Expanded(child: FlutterMap(
          mapController: map,
          options: MapOptions(initialCenter: point ?? WasultOsmMap.center, initialZoom: point == null ? 12.5 : 15, onTap: (_, candidate) => select(candidate)),
          children: [
            TileLayer(urlTemplate: AppConfig.mockMode ? 'http://127.0.0.1:7360/{z}/{x}/{y}.png' : 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.wasult.app'),
            if (point != null) MarkerLayer(markers: [Marker(point: point!, width: 48, height: 48, child: const Icon(Icons.location_pin, color: Colors.red, size: 46))]),
            const RichAttributionWidget(attributions: [TextSourceAttribution('OpenStreetMap contributors')]),
          ],
        )),
        Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(t('اضغط على الخريطة لتحديد الدبوس، ثم راجع العنوان.', 'Tap the map to place a pin, then review the address.')),
          const SizedBox(height: 8),
          TextField(controller: address, maxLines: 2, decoration: InputDecoration(labelText: t('العنوان المقروء (يمكن تعديله)', 'Readable address (editable)'))),
          const SizedBox(height: 8),
          FilledButton.icon(onPressed: point == null || address.text.trim().isEmpty ? null : () => Navigator.pop(context, PickedLocation(point!, address.text.trim())), icon: const Icon(Icons.check_circle_outline), label: Text(t('تأكيد هذا الموقع', 'Confirm this location'))),
        ])),
      ])),
    ),
  );
}
