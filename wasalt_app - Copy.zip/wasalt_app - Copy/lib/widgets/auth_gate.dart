import 'package:flutter/material.dart';
import '../services/session_store.dart';

/// Client-side navigation guard. Backend JWT verification and RBAC remain authoritative.
class AuthGate extends StatelessWidget {
  const AuthGate({super.key, required this.role, required this.child, required this.loginRoute});
  final String role;
  final Widget child;
  final String loginRoute;

  @override
  Widget build(BuildContext context) => FutureBuilder<(String?, String?)>(
    future: Future.wait([SessionStore.token(), SessionStore.role()]).then((values) => (values[0], values[1])),
    builder: (context, snapshot) {
      if (!snapshot.hasData) return const Scaffold(body: Center(child: CircularProgressIndicator()));
      final (token, storedRole) = snapshot.data!;
      if (token != null && token.isNotEmpty && storedRole == role) return child;
      return Scaffold(body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.lock_outline_rounded, size: 48),
        const SizedBox(height: 12),
        const Text('تسجيل الدخول مطلوب للوصول إلى هذه المساحة'),
        const SizedBox(height: 12),
        FilledButton(onPressed: () => Navigator.pushReplacementNamed(context, loginRoute), child: const Text('تسجيل الدخول')),
      ])));
    },
  );
}
