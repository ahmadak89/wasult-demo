﻿// C:\src\wasalt_app\lib\widgets\driver_emergency_alert_panel.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../core/config/app_config.dart';
import '../services/session_store.dart';

class DriverEmergencyAlertPanel extends StatefulWidget {
  final String activeDriverId;
  const DriverEmergencyAlertPanel({super.key, required this.activeDriverId});

  @override
  State<DriverEmergencyAlertPanel> createState() => _DriverEmergencyAlertPanelState();
}

class _DriverEmergencyAlertPanelState extends State<DriverEmergencyAlertPanel> {
  bool _isArabic = true; // Language default configuration toggled to Arabic First
  bool _isSending = false;

  // Pre-defined Statement Options Dataset array mapped to database keys [Requirement 3]
  final List<Map<String, dynamic>> _incidentTemplates = [
    {"key": "traffic", "ar": "تأخير بسبب ازدحام مروري شديد", "en": "Heavy Traffic delay"},
    {"key": "service", "ar": "الحافلة / السيارة خارج الخدمة حالياً", "en": "CAR/Bus out of service"},
    {"key": "unavailable", "ar": "أنا غير متاح اليوم، نعتذر عن الإزعاج", "en": "I am not available today"},
  ];

  /// Dispatches the emergency signal to Node server endpoint channels on port 3000
  Future<void> _fireEmergencyBroadcast(String templateKey, String description) async {
    setState(() => _isSending = true);
    try {
      final token = await SessionStore.token();
      if (token == null) throw StateError('DRIVER_SESSION_REQUIRED');
      final response = await http.post(AppConfig.api('/api/v1/notifications/emergency'), headers: {"Content-Type": "application/json", "Authorization": "Bearer $token"}, body: jsonEncode({"templateKey": templateKey, "customText": description}));

      if (response.statusCode == 202 && (response.headers['content-type'] ?? '').toLowerCase().contains('application/json')) {
        _showConfirmationDialog();
      }
    } catch (e) {
      debugPrint("[Wasult Emergency Outbound Pipe Exception]: $e");
    } finally {
      setState(() => _isSending = false);
    }
  }

  void _showConfirmationDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(_isArabic ? "تم إرسال التنبيه الفوري" : "Broadcast Complete"),
        content: Text(_isArabic ? "تم إرسال إشعار الطوارئ لجميع أولياء الأمور بنجاح." : "All route guardians have been notified."),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("OK")),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: _isArabic ? TextDirection.rtl : TextDirection.ltr,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(topLeft: Radius.circular(20), topRight: Radius.circular(20)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  _isArabic ? "إرسال إشعار طوارئ وتأخير" : "Dispatch Route Incident Alert",
                  style: const TextStyle(fontFamily: 'Al Messri', fontSize: 18, fontWeight: FontWeight.bold, color: Colors.red),
                ),
                TextButton(
                  onPressed: () => setState(() => _isArabic = !_isArabic),
                  child: Text(_isArabic ? "English" : "العربية", style: const TextStyle(fontWeight: FontWeight.bold)),
                )
              ],
            ),
            const SizedBox(height: 16),
            
            // Render Oversized Driver-Safe Single-Tap Buttons Block [Requirement 3]
            Column(
              children: _incidentTemplates.map((template) {
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6.0),
                  child: SizedBox(
                    width: double.infinity,
                    height: 60,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.redAccent.withOpacity(0.1),
                        foregroundColor: Colors.red,
                        elevation: 0,
                        alignment: _isArabic ? Alignment.centerRight : Alignment.centerLeft,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      icon: const Icon(Icons.warning_amber_rounded, color: Colors.red),
                      label: Text(
                        _isArabic ? template['ar'] : template['en'],
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                      ),
                      onPressed: _isSending ? null : () => _fireEmergencyBroadcast(template['key'], template['en']),
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}
