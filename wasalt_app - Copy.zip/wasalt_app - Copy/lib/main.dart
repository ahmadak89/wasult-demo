// C:\src\wasalt_app\lib\main.dart
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'design/wasult_theme.dart';
import 'core/config/app_config.dart';

// Unified Pre-Production Module Architecture Viewports Imports
import 'screens/splash_screen.dart';
import 'screens/landing_selection_screen.dart';
import 'screens/guardian_register_screen.dart';
import 'screens/guardian_login_screen.dart';
import 'screens/guardian_fleet_monitor_screen.dart';
import 'screens/guardian_dynamic_qr_screen.dart';
import 'screens/guardian_wallet_ledger_screen.dart';
import 'screens/driver_registration_onboarding_screen.dart';
import 'screens/driver_login_screen.dart';
import 'screens/driver_trip_dashboard_screen.dart';
import 'screens/driver_profile_update_screen.dart';
import 'screens/driver_qr_scanner_screen.dart';
import 'screens/super_admin_dashboard_screen.dart';
import 'screens/corporate_admin_dashboard_screen.dart';
import 'screens/role_login_screen.dart';
import 'screens/sibling_enrolment_screen.dart';
import 'screens/route_location_screen.dart';
import 'screens/demo_workspace_screen.dart';
import 'widgets/auth_gate.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const WasultEcosystemAppCore());
}

class WasultEcosystemAppCore extends StatelessWidget {
  const WasultEcosystemAppCore({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Wasult',
      debugShowCheckedModeBanner: false,
      theme: WasultTheme.light,
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      locale: const Locale('ar', 'QA'),
      supportedLocales: const [Locale('ar', 'QA'), Locale('en', 'US')],
      routes: {
        '/': (context) => AppConfig.mockMode
            ? const LandingSelectionScreen()
            : const WasultSplashScreen(),
        '/landing': (context) => const LandingSelectionScreen(),

        // 1. Guardian Route Maps
        '/register-guardian': (context) => const GuardianRegisterScreen(),
        '/login-guardian': (context) => const GuardianLoginScreen(),
        // The pilot workspace is intentionally used for authenticated local demos: it
        // exposes the complete role navigation while individual API-backed modules
        // are progressively substituted for their pilot-data counterparts.
        '/map-multiplex': (context) => AppConfig.mockMode
            ? const DemoWorkspaceScreen(role: 'GUARDIAN')
            : const AuthGate(
                role: 'GUARDIAN',
                loginRoute: '/login-guardian',
                child: DemoWorkspaceScreen(role: 'GUARDIAN')),
        '/guardian-qr': (context) => AppConfig.mockMode
            ? const GuardianDynamicQrScreen()
            : const AuthGate(
                role: 'GUARDIAN',
                loginRoute: '/login-guardian',
                child: GuardianDynamicQrScreen()),
        '/guardian-wallet': (context) => AppConfig.mockMode
            ? const GuardianWalletLedgerScreen()
            : const AuthGate(
                role: 'GUARDIAN',
                loginRoute: '/login-guardian',
                child: GuardianWalletLedgerScreen()),
        '/guardian-child-add': (context) => AppConfig.mockMode
            ? const SiblingEnrolmentScreen()
            : const AuthGate(
                role: 'GUARDIAN',
                loginRoute: '/login-guardian',
                child: SiblingEnrolmentScreen()),
        '/route-location': (context) => AppConfig.mockMode
            ? const RouteLocationScreen()
            : const AuthGate(
                role: 'GUARDIAN',
                loginRoute: '/login-guardian',
                child: RouteLocationScreen()),

        // 2. Driver Route Maps
        '/register-driver': (context) =>
            const DriverRegistrationOnboardingScreen(),
        '/login-driver': (context) => const DriverLoginScreen(),
        '/driver-trip': (context) => AppConfig.mockMode
            ? const DemoWorkspaceScreen(role: 'DRIVER')
            : const AuthGate(
                role: 'DRIVER',
                loginRoute: '/login-driver',
                child: DemoWorkspaceScreen(role: 'DRIVER')),
        '/driver-profile': (context) => AppConfig.mockMode
            ? const DriverProfileUpdateScreen()
            : const AuthGate(
                role: 'DRIVER',
                loginRoute: '/login-driver',
                child: DriverProfileUpdateScreen()),
        '/driver-scan': (context) => AppConfig.mockMode
            ? const DriverQrScannerScreen()
            : const AuthGate(
                role: 'DRIVER',
                loginRoute: '/login-driver',
                child: DriverQrScannerScreen()),

        // 3. Administrative Workspaces Maps
        '/super-admin': (context) => AppConfig.mockMode
            ? const DemoWorkspaceScreen(role: 'SUPER_ADMIN')
            : const AuthGate(
                role: 'SUPER_ADMIN',
                loginRoute: '/login-superadmin',
                child: DemoWorkspaceScreen(role: 'SUPER_ADMIN')),
        '/corporate-admin': (context) => AppConfig.mockMode
            ? const DemoWorkspaceScreen(role: 'CORPORATE_ADMIN')
            : const AuthGate(
                role: 'CORPORATE_ADMIN',
                loginRoute: '/login-corporate',
                child: DemoWorkspaceScreen(role: 'CORPORATE_ADMIN')),
        '/advertiser': (context) => AppConfig.mockMode
            ? const DemoWorkspaceScreen(role: 'ADVERTISER')
            : const AuthGate(
                role: 'ADVERTISER',
                loginRoute: '/login-advertiser',
                child: DemoWorkspaceScreen(role: 'ADVERTISER')),
        '/login-corporate': (context) => const RoleLoginScreen(
            role: 'CORPORATE_ADMIN',
            destination: '/corporate-admin',
            title: 'دخول إدارة الشركة',
            icon: Icons.apartment_rounded),
        '/login-superadmin': (context) => const RoleLoginScreen(
            role: 'SUPER_ADMIN',
            destination: '/super-admin',
            title: 'دخول الإدارة العليا',
            icon: Icons.admin_panel_settings_rounded),
        '/login-advertiser': (context) => const RoleLoginScreen(
            role: 'ADVERTISER',
            destination: '/advertiser',
            title: 'دخول المعلن',
            icon: Icons.campaign_rounded),
      },
    );
  }
}
