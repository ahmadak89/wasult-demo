// C:\src\wasalt_app\lib\screens\guardian_register_screen.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../core/config/app_config.dart';
import '../services/session_store.dart';
import '../widgets/location_picker.dart';

class GuardianRegisterScreen extends StatefulWidget {
  const GuardianRegisterScreen({super.key});

  @override
  State<GuardianRegisterScreen> createState() => _GuardianRegisterScreenState();
}

class _GuardianRegisterScreenState extends State<GuardianRegisterScreen> {
  bool _isArabic = true; // Language option defaulted to Arabic First
  bool _isLoading = false;

  // Form Fields Controllers Matrix
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _idController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  bool _acceptTerms = false;
  bool _acceptPrivacy = false;
  PickedLocation? _pickupLocation;

  @override
  void dispose() {
    _idController.dispose();
    _nameController.dispose();
    _phoneController.dispose();
    _passwordController.dispose();
    _addressController.dispose();
    super.dispose();
  }

  /// Submits payload data array asynchronously to your Express engine on Port 3000
  Future<void> _submitRegistrationForm() async {
    if (!_formKey.currentState!.validate()) return;
    if (_pickupLocation == null) {
      _showFeedbackSnackBar(_isArabic
          ? 'حدد موقعك الافتراضي من الخريطة ثم أكّد العنوان'
          : 'Choose and confirm your default location on the map.');
      return;
    }

    setState(() => _isLoading = true);

    try {
      final response = await http.post(
        AppConfig.api('/api/v1/auth/register-guardian'),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "passengerId": _idController.text.trim(),
          "fullName": _nameController.text.trim(),
          "whatsappNumber": _phoneController.text.trim(),
          "rawShortPassword": _passwordController.text.trim(),
          "preferredLanguage": _isArabic ? "ar" : "en",
          "locationAddress": _addressController.text.trim(),
          "latitude": _pickupLocation?.point.latitude,
          "longitude": _pickupLocation?.point.longitude,
          "acceptTerms": _acceptTerms,
          "acceptPrivacy": _acceptPrivacy
        }),
      );

      final Map<String, dynamic> responseData = jsonDecode(response.body);

      if (response.statusCode == 201 && responseData['success'] == true) {
        await SessionStore.save(
            token: responseData['token'],
            role: 'GUARDIAN',
            userId: _idController.text.trim());
        if (!mounted) return;
        _showFeedbackDialog(
          title: _isArabic ? "تم التسجيل" : "Success",
          body: _isArabic
              ? "تم إنشاء الحساب بنجاح وتفعيل رصيد الترحيب!"
              : "Account created successfully with welcome points!",
          isSuccess: true,
        );
      } else {
        String errorMsg = responseData['error_code'] == 'DUPLICATE_USER_ID'
            ? (_isArabic
                ? "معرف المستخدم مسجل مسبقاً"
                : "User ID already exists")
            : (_isArabic
                ? "فشل إنشاء الحساب، يرجى المحاولة لاحقاً"
                : "Registration failed, try again");
        _showFeedbackSnackBar(errorMsg);
      }
    } catch (e) {
      _showFeedbackSnackBar(_isArabic
          ? "خطأ في الاتصال بالخادم الرئيسي"
          : "Connection server error");
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showFeedbackSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content:
            Text(message, style: const TextStyle(fontFamily: 'Al Messri'))));
  }

  void _showFeedbackDialog(
      {required String title, required String body, bool isSuccess = false}) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text(title,
            style: const TextStyle(
                fontFamily: 'Al Messri', fontWeight: FontWeight.bold)),
        content: Text(body),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context); // Dismiss dialog framework context path
              if (isSuccess)
                Navigator.pushReplacementNamed(context, '/map-multiplex');
            },
            child: const Text("OK"),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF005B60),
        foregroundColor: Colors.white,
        title: Text(_isArabic ? "إنشاء حساب ولي الأمر" : "Register Guardian",
            style: const TextStyle(fontFamily: 'Al Messri')),
        actions: [
          TextButton(
            onPressed: () => setState(() => _isArabic = !_isArabic),
            child: Text(_isArabic ? "English" : "العربية",
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
          )
        ],
      ),
      body: Directionality(
        textDirection: _isArabic ? TextDirection.rtl : TextDirection.ltr,
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Quick Federated Onboarding Action Node Block
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black87,
                      side: const BorderSide(color: Colors.grey, width: 0.5),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                    icon: const Icon(Icons.g_mobiledata,
                        size: 28, color: Colors.red),
                    label: Text(
                      _isArabic
                          ? "التسجيل السريع عبر حساب Google"
                          : "Quick Sign-up with Google",
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    onPressed: () {/* Firebase Auth Native Intent Hook */},
                  ),

                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 20.0),
                    child: Row(
                      children: [
                        Expanded(child: Divider()),
                        Padding(
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            child: Text("OR")),
                        Expanded(child: Divider()),
                      ],
                    ),
                  ),

                  // User Account ID String Input Mapping Fields
                  TextFormField(
                    controller: _idController,
                    decoration: InputDecoration(
                      labelText: _isArabic
                          ? "معرف المستخدم فريد (رقم وطني أو بريد)"
                          : "Unique User ID / Identity String",
                      border: const OutlineInputBorder(),
                      prefixIcon: const Icon(Icons.badge),
                    ),
                    validator: (val) => val == null || val.trim().isEmpty
                        ? (_isArabic ? "الحقل مطلوب" : "Required field")
                        : null,
                  ),
                  const SizedBox(height: 16),

                  // Full Passenger Registered Name
                  TextFormField(
                    controller: _nameController,
                    decoration: InputDecoration(
                      labelText: _isArabic
                          ? "الاسم الكامل لولي الأمر"
                          : "Guardian Full Name",
                      border: const OutlineInputBorder(),
                      prefixIcon: const Icon(Icons.person),
                    ),
                    validator: (val) => val == null || val.trim().isEmpty
                        ? (_isArabic ? "الحقل مطلوب" : "Required field")
                        : null,
                  ),
                  const SizedBox(height: 16),

                  // Mobile WhatsApp Transmission Protocol Interface Channel Target
                  TextFormField(
                    controller: _phoneController,
                    keyboardType: TextInputType.phone,
                    decoration: InputDecoration(
                      labelText: _isArabic
                          ? "رقم الواتساب للتنبيهات (مثل: 974xxxx+)"
                          : "WhatsApp Number for Alerts (+974...)",
                      border: const OutlineInputBorder(),
                      prefixIcon: const Icon(Icons.chat_bubble),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Short Password Alpha-Numeric Strict Max 5 Constraint Custom Form Field
                  TextFormField(
                    controller: _passwordController,
                    obscureText: true,
                    maxLength:
                        5, // Structural restriction rule checked on device
                    decoration: InputDecoration(
                      labelText: _isArabic
                          ? "كلمة المرver القصيرة (الحد الأقصى 5 رموز وأرقام)"
                          : "Short Passcode (Max 5 Alphanumeric Characters)",
                      border: const OutlineInputBorder(),
                      prefixIcon: const Icon(Icons.lock),
                      counterText:
                          "", // Hides internal default character layout counter labels
                    ),
                    validator: (val) {
                      if (val == null || val.isEmpty)
                        return _isArabic ? "الحقل مطلوب" : "Required field";
                      final alphaNumericExp = RegExp(r'^[a-zA-Z0-9]{1,5}$');
                      if (!alphaNumericExp.hasMatch(val)) {
                        return _isArabic
                            ? "أدخل من 1 إلى 5 رموز وأرقam فقط"
                            : "Enter 1-5 alphanumeric characters only";
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),

                  TextFormField(
                    controller: _addressController,
                    readOnly: true,
                    minLines: 2,
                    maxLines: 3,
                    decoration: InputDecoration(
                      labelText: _isArabic
                          ? "الموقع الافتراضي المؤكد"
                          : "Confirmed default location",
                      border: const OutlineInputBorder(),
                      prefixIcon: const Icon(Icons.location_on_outlined),
                    ),
                    validator: (value) => _pickupLocation == null
                        ? (_isArabic
                            ? 'اختر دبوساً مؤكداً من الخريطة'
                            : 'Choose a confirmed map pin')
                        : null,
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: () async {
                      final result = await Navigator.push<PickedLocation>(
                          context,
                          MaterialPageRoute(
                              builder: (_) => LocationPicker(
                                  arabic: _isArabic,
                                  title: _isArabic
                                      ? 'تحديد نقطة الاستلام'
                                      : 'Choose pickup location',
                                  initial: _pickupLocation)));
                      if (result != null && mounted)
                        setState(() {
                          _pickupLocation = result;
                          _addressController.text = result.address;
                        });
                    },
                    icon: const Icon(Icons.map_outlined),
                    label: Text(_isArabic
                        ? 'ابحث أو حدد دبوساً على الخريطة'
                        : 'Search or pin on map'),
                  ),
                  const SizedBox(height: 12),
                  CheckboxListTile(
                    value: _acceptTerms,
                    onChanged: (value) =>
                        setState(() => _acceptTerms = value ?? false),
                    controlAffinity: ListTileControlAffinity.leading,
                    contentPadding: EdgeInsets.zero,
                    title: Text(_isArabic
                        ? "أوافق على شروط الاستخدام"
                        : "I accept the terms of use"),
                  ),
                  CheckboxListTile(
                    value: _acceptPrivacy,
                    onChanged: (value) =>
                        setState(() => _acceptPrivacy = value ?? false),
                    controlAffinity: ListTileControlAffinity.leading,
                    contentPadding: EdgeInsets.zero,
                    title: Text(_isArabic
                        ? "أوافق على سياسة الخصوصية ومعالجة بيانات الموقع"
                        : "I accept the privacy and location-data policy"),
                    subtitle: Text(_isArabic
                        ? "لن يتم إنشاء الحساب دون الموافقتين"
                        : "Both consents are required"),
                  ),
                  const SizedBox(height: 20),

                  // Trigger Registration Submit Action Loop Node
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor:
                          const Color(0xFF005B60), // Dark Teal Branding Cues
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: _isLoading || !_acceptTerms || !_acceptPrivacy
                        ? null
                        : _submitRegistrationForm,
                    child: _isLoading
                        ? const SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(
                                color: Colors.white, strokeWidth: 2))
                        : Text(
                            _isArabic
                                ? "تأكيد وإنشاء الحساب الحساب"
                                : "Confirm & Register Account",
                            style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Al Messri'),
                          ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
