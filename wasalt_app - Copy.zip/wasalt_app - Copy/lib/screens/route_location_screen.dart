import 'package:flutter/material.dart';
import '../widgets/location_picker.dart';
import '../core/config/app_config.dart';
import '../services/demo_store.dart';

class RouteLocationScreen extends StatefulWidget {
  const RouteLocationScreen({super.key});
  @override
  State<RouteLocationScreen> createState() => _RouteLocationScreenState();
}

class _RouteLocationScreenState extends State<RouteLocationScreen> {
  PickedLocation? from;
  PickedLocation? to;

  Future<void> choose(bool origin) async {
    final result = await Navigator.push<PickedLocation>(context, MaterialPageRoute(builder: (_) => LocationPicker(title: origin ? 'حدد نقطة الانطلاق' : 'حدد الوجهة', initial: origin ? from : to)));
    if (result != null && mounted) setState(() { if (origin) { from = result; } else { to = result; } });
  }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('من الموقع إلى الوجهة')),
      body: SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Text('اختر نقطة الانطلاق والوجهة على الخريطة، ثم راجعهما قبل المتابعة.', style: TextStyle(fontSize: 17)),
        const SizedBox(height: 20),
        ListTile(leading: const Icon(Icons.trip_origin), title: const Text('من الموقع'), subtitle: Text(from?.address ?? 'لم يحدد بعد'), trailing: const Icon(Icons.map_outlined), onTap: () => choose(true)),
        const Divider(),
        ListTile(leading: const Icon(Icons.place_outlined), title: const Text('إلى الوجهة'), subtitle: Text(to?.address ?? 'لم تحدد بعد'), trailing: const Icon(Icons.map_outlined), onTap: () => choose(false)),
        const Spacer(),
        FilledButton.icon(onPressed: from == null || to == null ? null : () { if (AppConfig.mockMode) { DemoStore.instance.update((data) { data['routeFrom'] = from!.address; data['routeTo'] = to!.address; }); DemoStore.instance.announce('طلب تغيير نقطة الانطلاق/الوجهة بانتظار موافقة السائق', audience: 'DRIVER'); } ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تأكيد النقطتين. طلب المسار بانتظار موافقة السائق.'))); }, icon: const Icon(Icons.check_circle_outline), label: const Text('تأكيد من / إلى')),
      ]))),
    ),
  );
}
