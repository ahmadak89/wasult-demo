﻿// C:\src\wasalt_app\lib\screens\driver_route_execution_screen.dart
import 'package:flutter/material.dart';

class DriverRouteExecutionScreen extends StatefulWidget {
  final String activeDriverId;
  const DriverRouteExecutionScreen({super.key, required this.activeDriverId});

  @override
  State<DriverRouteExecutionScreen> createState() => _DriverRouteExecutionScreenState();
}

class _DriverRouteExecutionScreenState extends State<DriverRouteExecutionScreen> {
  bool _isRouteActive = false;
  String _currentRouteStateText = "غير نشط | Idle";
  double _mockVehicleSpeedKmh = 0.0;

  /// Changes trip state dynamically and syncs coordinates to the platform database
  Future<void> _toggleRouteLifecycleState() async {
    // The authenticated Driver workspace owns persisted trip execution. This
    // legacy screen keeps a safe visual rehearsal only and never calls a
    // malformed placeholder endpoint.
    setState(() {
      _isRouteActive = !_isRouteActive;
      _currentRouteStateText = _isRouteActive ? "جاري القيادة | EnRoute" : "منتهي | Finished";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF005B60), // Dark Teal Identity Tone
        title: const Text(
          "منصة السائق - مسار حافلات وصلت",
          style: TextStyle(fontFamily: 'Al Messri', color: Colors.white),
        ),
      ),
      body: Directionality(
        textDirection: TextDirection.rtl, // RTL First Layout Native Architecture
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Operational Metric Status Monitor
              Card(
                color: const Color(0xFF005B60).withOpacity(0.05),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text("حالة التتبع الحالية:", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      Text(
                        _currentRouteStateText,
                        style: const TextStyle(fontSize: 18, color: Color(0xFF005B60), fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 40),

              // Single-Button Blind-Tap Tracking Driver Controller
              SizedBox(
                width: double.infinity,
                height: 120,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _isRouteActive ? Colors.redAccent : const Color(0xFF005B60),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  onPressed: _toggleRouteLifecycleState,
                  child: Text(
                    _isRouteActive ? "إنهاء المسار والرحلة\nEnd Route" : "بدء المسار والرحلة التلقائية\nStart Route",
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold, fontFamily: 'Al Messri'),
                  ),
                ),
              ),
              const SizedBox(height: 30),

              // Enforce lock overlay parameters if transit speed indicates vehicular movement
              if (_mockVehicleSpeedKmh > 5.0)
                Container(
                  padding: const EdgeInsets.all(12),
                  color: Colors.redAccent.withOpacity(0.15),
                  child: const Row(
                    children: [
                      Icon(Icons.block, color: Colors.red),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          "الكتابة معطلة تلقائياً أثناء حركة المركبة لحمايتك.",
                          style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
                        ),
                      )
                    ],
                  ),
                )
            ],
          ),
        ),
      ),
    );
  }
}
