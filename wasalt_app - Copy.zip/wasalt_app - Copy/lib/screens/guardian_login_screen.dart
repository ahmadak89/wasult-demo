import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../core/config/app_config.dart';
import '../design/wasult_theme.dart';
import '../design/wasult_widgets.dart';
import '../services/session_store.dart';
import '../services/demo_accounts.dart';

class GuardianLoginScreen extends StatefulWidget {
  const GuardianLoginScreen({super.key});
  @override State<GuardianLoginScreen> createState() => _GuardianLoginScreenState();
}

class _GuardianLoginScreenState extends State<GuardianLoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _id = TextEditingController();
  final _passcode = TextEditingController();
  bool _arabic = true, _remember = true, _hidden = true, _loading = false;
  String t(String ar, String en) => _arabic ? ar : en;

  @override void dispose() { _id.dispose(); _passcode.dispose(); super.dispose(); }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      if (AppConfig.mockMode) {
        final account = DemoAccounts.authenticate('GUARDIAN', _id.text.trim(), _passcode.text);
        if (!mounted) return;
        if (account == null) { _message(t('بيانات التجربة غير صحيحة', 'Invalid demo credentials'), error: true); return; }
        Navigator.pushReplacementNamed(context, account.destination);
        return;
      }
      final response = await http.post(AppConfig.api('/api/v1/auth/login-guardian'), headers: {'Content-Type': 'application/json'}, body: jsonEncode({'passengerId': _id.text.trim(), 'rawShortPassword': _passcode.text}));
      if (!mounted) return;
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        await SessionStore.save(token: data['token'], role: 'GUARDIAN', userId: _id.text.trim());
        if (!mounted) return;
        Navigator.pushReplacementNamed(context, '/map-multiplex');
      } else {
        _message(t('تحقق من المعرّف ورمز المرور ثم حاول مجدداً.', 'Check your ID and passcode, then try again.'), error: true);
      }
    } catch (_) {
      if (mounted) _message(t('تعذر الاتصال بالخدمة. يمكنك المحاولة مجدداً.', 'Service is unavailable. Please try again.'), error: true);
    } finally { if (mounted) setState(() => _loading = false); }
  }

  void _message(String value, {bool error = false}) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value), backgroundColor: error ? WasultColors.danger : WasultColors.teal));

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: _arabic ? TextDirection.rtl : TextDirection.ltr,
    child: Scaffold(
      appBar: AppBar(actions: [TextButton.icon(onPressed: () => setState(() => _arabic = !_arabic), icon: const Icon(Icons.language_rounded), label: Text(_arabic ? 'English' : 'العربية'))]),
      body: SafeArea(child: LayoutBuilder(builder: (context, constraints) => SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
        child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 480), child: Form(key: _formKey, child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Center(child: Container(width: 92, height: 92, padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28), boxShadow: const [BoxShadow(color: Color(0x18005B60), blurRadius: 25, offset: Offset(0, 12))]), child: Image.asset('assets/images/logo.png'))),
          const SizedBox(height: 24),
          Text(t('أهلاً بعودتك', 'Welcome back'), textAlign: TextAlign.center, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text(t('تابع رحلات أبنائك وتنبيهات الوصول من مكان واحد.', 'Track journeys and arrival alerts from one place.'), textAlign: TextAlign.center, style: const TextStyle(color: WasultColors.muted, height: 1.5)),
          const SizedBox(height: 28),
          WasultPanel(child: Column(children: [
            TextFormField(controller: _id, textInputAction: TextInputAction.next, decoration: InputDecoration(labelText: t('معرّف المستخدم', 'User ID'), prefixIcon: const Icon(Icons.badge_outlined)), validator: (v) => v == null || v.trim().isEmpty ? t('أدخل معرّف المستخدم', 'Enter your user ID') : null),
            const SizedBox(height: 14),
            TextFormField(controller: _passcode, obscureText: _hidden, maxLength: 5, onFieldSubmitted: (_) => _login(), decoration: InputDecoration(labelText: t('رمز المرور', 'Passcode'), helperText: AppConfig.mockMode ? 'DEMO: DEMO_PARENT / P26a1' : t('خمسة أحرف أو أرقام كحد أقصى', 'Up to five letters or numbers'), prefixIcon: const Icon(Icons.lock_outline_rounded), suffixIcon: IconButton(onPressed: () => setState(() => _hidden = !_hidden), icon: Icon(_hidden ? Icons.visibility_outlined : Icons.visibility_off_outlined)), counterText: ''), validator: (v) { if (v == null || v.isEmpty) return t('أدخل رمز المرور', 'Enter your passcode'); if (!RegExp(r'^[a-zA-Z0-9]{1,5}$').hasMatch(v)) return t('استخدم أحرفاً وأرقاماً فقط', 'Use letters and numbers only'); return null; }),
            CheckboxListTile(value: _remember, onChanged: (v) => setState(() => _remember = v ?? false), contentPadding: EdgeInsets.zero, controlAffinity: ListTileControlAffinity.leading, title: Text(t('تذكرني على هذا الجهاز', 'Remember me on this device')), subtitle: Text(t('لا تستخدمها على جهاز مشترك', 'Avoid this on a shared device'), style: const TextStyle(fontSize: 12, color: WasultColors.muted))),
            const SizedBox(height: 8),
            WasultPressButton(label: _loading ? t('جاري تسجيل الدخول…', 'Signing in…') : t('دخول آمن', 'Secure sign in'), icon: _loading ? Icons.hourglass_top_rounded : Icons.login_rounded, onPressed: _loading ? null : _login),
          ])),
          const SizedBox(height: 18),
          OutlinedButton.icon(onPressed: () => _message(t('سيتم تفعيل تسجيل Google بعد ربط Firebase Auth.', 'Google sign-in will activate after Firebase Auth is connected.')), icon: const Icon(Icons.g_mobiledata_rounded, size: 30), label: Text(t('المتابعة باستخدام Google', 'Continue with Google')), style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)))),
          TextButton(onPressed: () => Navigator.pushNamed(context, '/register-guardian'), child: Text(t('مستخدم جديد؟ أنشئ حساباً', 'New here? Create an account'))),
        ])))),
      ))),
    ),
  );
}
