import 'dart:async';
import 'package:flutter/material.dart';
import '../design/wasult_theme.dart';

class WasultSplashScreen extends StatefulWidget {
  const WasultSplashScreen({super.key});
  @override
  State<WasultSplashScreen> createState() => _WasultSplashScreenState();
}

class _WasultSplashScreenState extends State<WasultSplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))..forward();
    Timer(const Duration(milliseconds: 2100), () {
      if (mounted) Navigator.pushReplacementNamed(context, '/landing');
    });
  }
  @override
  void dispose() { _controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    body: DecoratedBox(
      decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF003F43), WasultColors.teal, Color(0xFF0D7779)])),
      child: Stack(children: [
        Positioned.fill(child: CustomPaint(painter: _OrbitPainter())),
        Center(child: FadeTransition(opacity: CurvedAnimation(parent: _controller, curve: Curves.easeOut), child: ScaleTransition(
          scale: Tween(begin: .84, end: 1.0).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutBack)),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 148, height: 148, padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(42), boxShadow: const [BoxShadow(color: Color(0x55000000), blurRadius: 32, offset: Offset(0, 18))]), child: Image.asset('assets/images/logo.png', fit: BoxFit.contain)),
            const SizedBox(height: 28),
            const Text('وصلت', style: TextStyle(color: Colors.white, fontSize: 52, fontWeight: FontWeight.w900, height: 1)),
            const SizedBox(height: 10),
            const Text('WASULT', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800, letterSpacing: 6)),
            const SizedBox(height: 16),
            const Text('رحلتكم، أماننا', style: TextStyle(color: Color(0xFFE4FFFF), fontSize: 16, fontWeight: FontWeight.w600)),
          ]),
        ))),
        const Positioned(bottom: 38, left: 0, right: 0, child: Center(child: SizedBox(width: 28, height: 28, child: CircularProgressIndicator(color: WasultColors.amber, strokeWidth: 3)))),
      ]),
    ),
  );
}

class _OrbitPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white.withValues(alpha: .08)..style = PaintingStyle.stroke..strokeWidth = 1;
    final center = Offset(size.width / 2, size.height * .44);
    for (final radius in [170.0, 245.0, 330.0]) { canvas.drawCircle(center, radius, paint); }
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
