// C:\src\wasalt_app\lib\screens\driver_registration_onboarding_screen.dart
import 'package:flutter/material.dart';

class DriverRegistrationOnboardingScreen extends StatefulWidget {
  const DriverRegistrationOnboardingScreen({super.key});

  @override
  State<DriverRegistrationOnboardingScreen> createState() =>
      _DriverRegistrationOnboardingScreenState();
}

class _DriverRegistrationOnboardingScreenState
    extends State<DriverRegistrationOnboardingScreen> {
  final _formKey = GlobalKey<FormState>();
  bool _documentsAttached = false;
  bool _submitted = false;

  @override
  Widget build(BuildContext context) {
    if (_submitted) {
      return Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: const Text('حالة طلب السائق')),
          body: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.pending_actions_rounded,
                    size: 72, color: Color(0xFFF0A020)),
                const SizedBox(height: 18),
                const Text('طلبك قيد المراجعة',
                    style:
                        TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
                const SizedBox(height: 10),
                const Text(
                    'تم استلام ملفك ووثائقك. ستصلك رسالة عند الاعتماد أو عند الحاجة إلى استكمال مستند. لا يمكنك بدء مسار أو رؤية بيانات الركاب قبل الاعتماد.',
                    textAlign: TextAlign.center),
                const SizedBox(height: 18),
                const SelectableText('Driver Unique ID: يصدر بعد الاعتماد',
                    textDirection: TextDirection.ltr),
                const SizedBox(height: 18),
                FilledButton.icon(
                    onPressed: () => Navigator.pushReplacementNamed(
                        context, '/login-driver'),
                    icon: const Icon(Icons.login_rounded),
                    label: const Text('العودة إلى تسجيل الدخول')),
              ]),
            ),
          ),
        ),
      );
    }
    return Scaffold(
      appBar: AppBar(
          backgroundColor: const Color(0xFF005B60),
          foregroundColor: Colors.white,
          title: const Text("تسجيل حساب سائق جديد")),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.all(24),
            children: [
              const Text("بوابة الانضمام الرقمية لحافلات وصلت",
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF005B60))),
              const SizedBox(height: 20),
              TextFormField(
                  decoration: const InputDecoration(
                      labelText: "الاسم الكامل (مطابق للهوية)",
                      border: OutlineInputBorder()),
                  validator: (value) => value == null || value.trim().length < 3
                      ? 'أدخل الاسم الكامل كما في الهوية'
                      : null),
              const SizedBox(height: 12),
              TextFormField(
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(
                      labelText: "رقم الجوال الشخصي مع رمز الدولة",
                      hintText: '+9627…',
                      border: OutlineInputBorder()),
                  validator: (value) => value == null ||
                          !RegExp(r'^\+[1-9]\d{7,14}$')
                              .hasMatch(value.replaceAll(RegExp(r'\s'), ''))
                      ? 'أدخل رقم جوال صحيحاً مع رمز الدولة'
                      : null),
              const SizedBox(height: 16),

              // Document Checks File Upload Matrix Mock Utility
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text("تحميل وثائق التحقق والمطابقة الرسمية:",
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    const Text(
                        "رخصة القيادة العمومية + بطاقة الهوية الوطنية ومستندات الحافلة",
                        style: TextStyle(fontSize: 12, color: Colors.grey)),
                    const SizedBox(height: 10),
                    ElevatedButton.icon(
                      icon: const Icon(Icons.upload_file),
                      label: Text(_documentsAttached
                          ? "تم إرفاق الملفات بنجاح ✔️"
                          : "اضغط لرفع الصور والملفات"),
                      onPressed: () =>
                          setState(() => _documentsAttached = true),
                    )
                  ],
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () {
                  if (!_documentsAttached) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                        content: Text(
                            'أرفق رخصة القيادة والهوية ووثائق المركبة أولاً')));
                    return;
                  }
                  if (_formKey.currentState!.validate())
                    setState(() => _submitted = true);
                },
                style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF005B60),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16)),
                child: const Text("إرسال طلب التسجيل والمستندات"),
              )
            ],
          ),
        ),
      ),
    );
  }
}
