﻿// C:\src\wasalt_app\lib\screens\guardian_dynamic_qr_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:crypto/crypto.dart';
import 'dart:convert';
import 'package:qr_flutter/qr_flutter.dart';

class GuardianDynamicQrScreen extends StatefulWidget {
  final String passengerId;
  const GuardianDynamicQrScreen({super.key, this.passengerId = 'PAS_SAMER'});

  @override
  State<GuardianDynamicQrScreen> createState() => _GuardianDynamicQrScreenState();
}

class _GuardianDynamicQrScreenState extends State<GuardianDynamicQrScreen> {
  late String _calculatedQrString;
  late Timer _refreshTimer;
  int _secondsRemaining = 30;
  final String _systemSalt = "wasult_qatar_mena_secure_secret_2026";

  @override
  void initState() {
    super.initState();
    _computeRollingQrSignature();
    _refreshTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (_secondsRemaining > 1) {
          _secondsRemaining--;
        } else {
          _computeRollingQrSignature();
          _secondsRemaining = 30;
        }
      });
    });
  }

  void _computeRollingQrSignature() {
    final int epochTimestamp = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    final String messagePayload = "${widget.passengerId}:$epochTimestamp";
    final hmac = Hmac(sha256, utf8.encode(_systemSalt));
    final signature = hmac.convert(utf8.encode(messagePayload));
    _calculatedQrString = "wasult_payload_struct:${widget.passengerId}:$epochTimestamp:$signature";
  }

  @override
  void dispose() {
    _refreshTimer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: const Color(0xFF005B60), foregroundColor: Colors.white, title: const Text("رمز الحضور المشفر المباشر")),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text("امسح الرمز لتسجيل صعود الحافلة", style: TextStyle(fontFamily: 'Al Messri', fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              QrImageView(
                data: _calculatedQrString,
                version: QrVersions.auto,
                size: 260.0,
                eyeStyle: const QrEyeStyle(eyeShape: QrEyeShape.square, color: Color(0xFF005B60)),
                dataModuleStyle: const QrDataModuleStyle(dataModuleShape: QrDataModuleShape.square, color: Color(0xFF005B60)),
              ),
              const SizedBox(height: 24),
              LinearProgressIndicator(value: _secondsRemaining / 30, color: const Color(0xFFFFA500), backgroundColor: Colors.grey.withOpacity(0.2)),
              const SizedBox(height: 12),
              Text("يتجدد الرمز تلقائياً خلال $_secondsRemaining ثانية لحماية التتبع", style: const TextStyle(fontSize: 13, color: Colors.grey)),
            ],
          ),
        ),
      ),
    );
  }
}
