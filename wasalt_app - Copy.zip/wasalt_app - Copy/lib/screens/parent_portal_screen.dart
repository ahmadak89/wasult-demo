// parent_portal_screen.dart
import 'package:flutter/material.dart';

class ChildTracker {
  final String childName;
  final String assignedDriverId;
  String currentCoordinates;

  ChildTracker({required this.childName, required this.assignedDriverId, this.currentCoordinates = "Awaiting coordinate ping..."});
}

class ParentPortalScreen extends StatefulWidget {
  const ParentPortalScreen({super.key});

  @override
  State<ParentPortalScreen> createState() => _ParentPortalScreenState();
}

class _ParentPortalScreenState extends State<ParentPortalScreen> {
  // Multi-child selection dataset engine
  final List<ChildTracker> _linkedChildren = [
    ChildTracker(childName: "Sami (Amman Route)", assignedDriverId: "driver_route_east"),
    ChildTracker(childName: "Nour (Giza Fleet)", assignedDriverId: "driver_route_south"),
  ];

  final Set<String> _selectedChildIds = {};

  @override
  void initState() {
    super.initState();
    // Default select all to populate multiplex tracker canvas instantly
    for (var child in _linkedChildren) {
      _selectedChildIds.add(child.assignedDriverId);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Wasult Parent Tracking Dashboard"),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Select Children to Track Concurrently:",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            // Multi-child horizontal selection toggle chips
            Wrap(
              spacing: 8.0,
              children: _linkedChildren.map((child) {
                final isSelected = _selectedChildIds.contains(child.assignedDriverId);
                return FilterChip(
                  label: Text(child.childName),
                  selected: isSelected,
                  onSelected: (bool checked) {
                    setState(() {
                      if (checked) {
                        _selectedChildIds.add(child.assignedDriverId);
                      } else {
                        _selectedChildIds.remove(child.assignedDriverId);
                      }
                    });
                  },
                );
              }).toList(),
            ),
            const Divider(height: 30, thickness: 2),
            const Text(
              "Live Fleet Stream Feeds (wasult.com link):",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: _linkedChildren.length,
                itemBuilder: (context, index) {
                  final child = _linkedChildren[index];
                  final isTracked = _selectedChildIds.contains(child.assignedDriverId);

                  if (!isTracked) return const SizedBox.shrink();

                  return Card(
                    elevation: 4,
                    margin: const EdgeInsets.symmetric(vertical: 8),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Row(
                        children: [
                          const CircleAvatar(
                            backgroundColor: Colors.teal,
                            child: Icon(Icons.directions_bus, color: Colors.white),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(child.childName, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                                const SizedBox(height: 4),
                                Text("Driver Stream: ${child.assignedDriverId}", style: TextStyle(color: Colors.grey.shade600)),
                                const SizedBox(height: 6),
                                Text(
                                  child.currentCoordinates,
                                  style: const TextStyle(fontFamily: 'Courier', color: Colors.blue, fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
