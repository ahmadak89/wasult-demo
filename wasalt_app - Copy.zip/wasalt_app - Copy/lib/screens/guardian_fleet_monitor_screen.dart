import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../core/config/app_config.dart';
import '../design/wasult_theme.dart';
import '../design/wasult_widgets.dart';
import '../services/session_store.dart';
import '../widgets/wasult_osm_map.dart';

class GuardianFleetMonitorScreen extends StatefulWidget {
  const GuardianFleetMonitorScreen(
      {super.key, this.guardianPassengerId = 'PAS_SAMER'});
  final String guardianPassengerId;
  @override
  State<GuardianFleetMonitorScreen> createState() =>
      _GuardianFleetMonitorScreenState();
}

class _GuardianFleetMonitorScreenState
    extends State<GuardianFleetMonitorScreen> {
  bool _arabic = true,
      _refreshing = false,
      _offline = false,
      _rateLimited = false;
  int _tab = 0;
  Timer? _timer;
  List<dynamic> _nodes = const [];
  String t(String ar, String en) => _arabic ? ar : en;

  static const _previewNodes = [
    {
      'passengerName': 'سامي',
      'serviceSegment': 'MORNING',
      'etaMinutes': 6,
      'assignmentSource': 'SERVICE_ASSIGNMENT',
      'driver': {
        'name': 'أحمد',
        'plate': 'AM 55421',
        'tripState': 'Approaching'
      },
      'telemetry': {
        'speedKmh': 24,
        'lat': 31.9546,
        'lng': 35.9106,
        'freshness': 'LIVE'
      }
    },
    {
      'passengerName': 'يارا',
      'serviceSegment': 'AFTERNOON',
      'etaMinutes': 14,
      'assignmentSource': 'SERVICE_ASSIGNMENT',
      'driver': {'name': 'ليث', 'plate': 'AM 99212', 'tripState': 'On the way'},
      'telemetry': {
        'speedKmh': 31,
        'lat': 31.9685,
        'lng': 35.8956,
        'freshness': 'STALE'
      }
    },
  ];

  @override
  void initState() {
    super.initState();
    _refresh();
    _timer = Timer.periodic(
        const Duration(seconds: 12), (_) => _refresh(silent: true));
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _refresh({bool silent = false}) async {
    if (!silent) setState(() => _refreshing = true);
    if (AppConfig.mockMode) {
      if (mounted)
        setState(() {
          _nodes = _previewNodes;
          _offline = false;
          _rateLimited = false;
          _refreshing = false;
        });
      return;
    }
    try {
      final token = await SessionStore.token();
      final response = await http.get(
          AppConfig.api('/api/v1/telemetry/multi-child-snapshot'),
          headers: {
            'Authorization': 'Bearer ${token ?? ''}'
          }).timeout(const Duration(seconds: 5));
      if (response.statusCode == 429) {
        if (mounted) setState(() => _rateLimited = true);
        return;
      }
      if (response.statusCode < 200 || response.statusCode >= 300)
        throw StateError('Snapshot unavailable');
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      if (mounted)
        setState(() {
          _nodes = (data['active_monitored_nodes'] as List? ?? const [])
              .take(3)
              .toList();
          _offline = false;
          _rateLimited = false;
        });
    } catch (_) {
      if (mounted)
        setState(() {
          _offline = true;
          if (_nodes.isEmpty) _nodes = _previewNodes;
        });
    } finally {
      if (mounted && !silent) setState(() => _refreshing = false);
    }
  }

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: _arabic ? TextDirection.rtl : TextDirection.ltr,
        child: Scaffold(
          appBar: AppBar(
              title: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(t('مرحباً، سامر', 'Hello, Samer'),
                        style: const TextStyle(fontWeight: FontWeight.w900)),
                    Text(t('متابعة الرحلات المباشرة', 'Live journey overview'),
                        style: const TextStyle(
                            fontSize: 12, color: WasultColors.muted))
                  ]),
              actions: [
                IconButton(
                    onPressed: () => setState(() => _arabic = !_arabic),
                    icon: const Icon(Icons.language_rounded)),
                IconButton(
                    onPressed: _refresh,
                    icon: AnimatedRotation(
                        turns: _refreshing ? 1 : 0,
                        duration: const Duration(milliseconds: 600),
                        child: const Icon(Icons.refresh_rounded)))
              ]),
          body: SafeArea(
              child: RefreshIndicator(
                  onRefresh: _refresh,
                  child: ListView(
                      padding: const EdgeInsets.fromLTRB(18, 8, 18, 110),
                      children: [
                        if (_offline)
                          Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                  color:
                                      WasultColors.amber.withValues(alpha: .18),
                                  borderRadius: BorderRadius.circular(16)),
                              child: Row(children: [
                                const Icon(Icons.cloud_off_rounded,
                                    color: Color(0xFF8B5D00)),
                                const SizedBox(width: 10),
                                Expanded(
                                    child: Text(
                                        t('وضع المعاينة: سنعيد الاتصال تلقائياً.',
                                            'Preview mode: reconnecting automatically.'),
                                        style: const TextStyle(
                                            fontWeight: FontWeight.w700)))
                              ])),
                        if (_rateLimited)
                          Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                  color: WasultColors.tealSoft,
                                  borderRadius: BorderRadius.circular(16)),
                              child: Row(children: [
                                const Icon(Icons.schedule_rounded,
                                    color: WasultColors.teal),
                                const SizedBox(width: 10),
                                Expanded(
                                    child: Text(
                                        t('يتم تحديث الخريطة بوتيرة آمنة. ستتم إعادة المحاولة تلقائياً.',
                                            'The map is refreshing safely. It will retry automatically.'),
                                        style: const TextStyle(
                                            fontWeight: FontWeight.w700)))
                              ])),
                        if (_offline) const SizedBox(height: 16),
                        if (_rateLimited) const SizedBox(height: 16),
                        const WasultOsmMap(height: 280),
                        const SizedBox(height: 18),
                        Row(children: [
                          Expanded(
                              child: Text(
                                  t('الرحلات النشطة', 'Active journeys'),
                                  style: const TextStyle(
                                      fontSize: 21,
                                      fontWeight: FontWeight.w900))),
                          WasultStatusPill(
                              label: t('${_nodes.length} مركبات',
                                  '${_nodes.length} vehicles'),
                              color: WasultColors.success,
                              icon: Icons.sensors_rounded)
                        ]),
                        const SizedBox(height: 12),
                        ..._nodes.asMap().entries.map((entry) => Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: _JourneyCard(
                                node: entry.value as Map,
                                index: entry.key,
                                arabic: _arabic))),
                        const SizedBox(height: 6),
                        OutlinedButton.icon(
                            onPressed: () =>
                                Navigator.pushNamed(context, '/route-location'),
                            icon: const Icon(Icons.alt_route_rounded),
                            label: Text(t('تحديد من الموقع إلى الوجهة',
                                'Choose from and to on map'))),
                        const SizedBox(height: 8),
                        Row(children: [
                          Expanded(
                              child: WasultPressButton(
                                  label: t('إضافة طفل أو سائق',
                                      'Add child or driver'),
                                  icon: Icons.person_add_alt_1_rounded,
                                  onPressed: () => Navigator.pushNamed(
                                      context, '/guardian-child-add'))),
                          const SizedBox(width: 12),
                          WasultPressButton(
                              label: t('QR', 'QR'),
                              icon: Icons.qr_code_2_rounded,
                              expanded: false,
                              color: WasultColors.orange,
                              onPressed: () =>
                                  Navigator.pushNamed(context, '/guardian-qr'))
                        ]),
                      ]))),
          bottomNavigationBar: NavigationBar(
              selectedIndex: _tab,
              onDestinationSelected: (value) {
                setState(() => _tab = value);
                if (value == 1)
                  Navigator.pushNamed(context, '/guardian-wallet');
                if (value == 2) Navigator.pushNamed(context, '/guardian-qr');
              },
              destinations: [
                NavigationDestination(
                    icon: const Icon(Icons.map_outlined),
                    selectedIcon: const Icon(Icons.map_rounded),
                    label: t('التتبع', 'Tracking')),
                NavigationDestination(
                    icon: const Icon(Icons.account_balance_wallet_outlined),
                    selectedIcon:
                        const Icon(Icons.account_balance_wallet_rounded),
                    label: t('المحفظة', 'Wallet')),
                NavigationDestination(
                    icon: const Icon(Icons.qr_code_2_rounded),
                    label: t('الحضور', 'Attendance')),
                NavigationDestination(
                    icon: const Icon(Icons.notifications_none_rounded),
                    label: t('التنبيهات', 'Alerts'))
              ]),
        ),
      );
}

class _MapOverview extends StatelessWidget {
  const _MapOverview({required this.count, required this.arabic});
  final int count;
  final bool arabic;
  @override
  Widget build(BuildContext context) => Container(
      height: 220,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: const LinearGradient(
              colors: [Color(0xFFDCEDEC), Color(0xFFF9E7C6)])),
      child: Stack(children: [
        Positioned.fill(child: CustomPaint(painter: _RoutePainter())),
        const Positioned(
            top: 38,
            right: 55,
            child: _MapPin(icon: Icons.home_rounded, color: WasultColors.teal)),
        const Positioned(
            bottom: 46,
            left: 46,
            child:
                _MapPin(icon: Icons.school_rounded, color: Color(0xFF8D3D78))),
        const Positioned(
            top: 95,
            left: 0,
            right: 0,
            child: Center(
                child: _MapPin(
                    icon: Icons.directions_bus_filled_rounded,
                    color: WasultColors.orange,
                    large: true))),
        Positioned(
            top: 14,
            left: 14,
            child: WasultStatusPill(
                label: arabic ? 'مباشر الآن' : 'Live now',
                color: WasultColors.success,
                icon: Icons.wifi_tethering_rounded)),
        Positioned(
            bottom: 14,
            right: 14,
            child: Text(
                arabic ? '$count رحلات على الخريطة' : '$count journeys on map',
                style: const TextStyle(
                    fontWeight: FontWeight.w800,
                    color: WasultColors.tealDark))),
      ]));
}

class _RoutePainter extends CustomPainter {
  @override
  void paint(Canvas c, Size s) {
    final p = Paint()
      ..color = WasultColors.teal.withValues(alpha: .35)
      ..strokeWidth = 4
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final path = Path()
      ..moveTo(s.width * .18, s.height * .78)
      ..cubicTo(s.width * .25, s.height * .25, s.width * .75, s.height * .8,
          s.width * .82, s.height * .2);
    c.drawPath(path, p);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _MapPin extends StatelessWidget {
  const _MapPin({required this.icon, required this.color, this.large = false});
  final IconData icon;
  final Color color;
  final bool large;
  @override
  Widget build(BuildContext context) => Container(
      width: large ? 58 : 42,
      height: large ? 58 : 42,
      decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white, width: 3),
          boxShadow: const [
            BoxShadow(
                color: Color(0x33000000), blurRadius: 12, offset: Offset(0, 6))
          ]),
      child: Icon(icon, color: Colors.white, size: large ? 30 : 22));
}

class _JourneyCard extends StatelessWidget {
  const _JourneyCard(
      {required this.node, required this.index, required this.arabic});
  final Map node;
  final int index;
  final bool arabic;
  @override
  Widget build(BuildContext context) {
    final d = node['driver'] as Map? ?? {};
    final telemetry = node['telemetry'] as Map?;
    final freshness = '${telemetry?['freshness'] ?? 'NO_SIGNAL'}';
    final state = '${d['tripState'] ?? 'Live'}';
    final color = freshness == 'LIVE'
        ? (state == 'Approaching' ? WasultColors.orange : WasultColors.success)
        : freshness == 'STALE'
            ? WasultColors.orange
            : WasultColors.danger;
    return WasultPanel(
        child: Column(children: [
      Row(children: [
        CircleAvatar(
            radius: 24,
            backgroundColor: [
              WasultColors.tealSoft,
              const Color(0xFFFFEBCD),
              const Color(0xFFEDE5FA)
            ][index % 3],
            child: Text('${index + 1}',
                style: const TextStyle(
                    fontWeight: FontWeight.w900, color: WasultColors.teal))),
        const SizedBox(width: 12),
        Expanded(
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${node['passengerName'] ?? 'Passenger'}',
              style:
                  const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
          Text('${d['name'] ?? ''} • ${d['plate'] ?? ''}',
              style: const TextStyle(color: WasultColors.muted, fontSize: 12))
        ])),
        WasultStatusPill(
            label: state, color: color, icon: Icons.navigation_rounded)
      ]),
      const SizedBox(height: 16),
      LinearProgressIndicator(
          value: state == 'Approaching' ? .78 : .46,
          minHeight: 7,
          borderRadius: BorderRadius.circular(20),
          color: color,
          backgroundColor: WasultColors.tealSoft),
      const SizedBox(height: 12),
      Row(children: [
        Icon(Icons.speed_rounded, size: 18, color: WasultColors.muted),
        const SizedBox(width: 6),
        Text('${telemetry?['speedKmh'] ?? 0} km/h',
            style: const TextStyle(fontWeight: FontWeight.w700)),
        const Spacer(),
        Text(
            '${node['serviceSegment'] ?? '—'} • ${node['etaMinutes'] ?? '—'} ${arabic ? 'د' : 'min'}',
            style: const TextStyle(fontWeight: FontWeight.w800))
      ]),
      const SizedBox(height: 6),
      Align(
          alignment: AlignmentDirectional.centerStart,
          child: Text(
              freshness == 'LIVE'
                  ? '${node['assignmentSource'] ?? '—'} • LIVE — الموقع محدث'
                  : freshness == 'STALE'
                      ? 'آخر موقع معروف — لا تستخدمه لتأكيد الحضور'
                      : 'لا توجد إشارة حالياً — سيتم إعادة المحاولة تلقائياً',
              style: TextStyle(
                  fontSize: 11, color: color, fontWeight: FontWeight.w700))),
      Align(
          alignment: AlignmentDirectional.centerEnd,
          child: TextButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.route_rounded),
              label: Text(arabic ? 'عرض التفاصيل' : 'View details'))),
    ]));
  }
}
