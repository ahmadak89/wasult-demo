﻿// C:\src\wasalt_app\lib\screens\driver_passenger_manifest_screen.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../core/config/app_config.dart';
import '../services/session_store.dart';

class DriverPassengerManifestScreen extends StatefulWidget {
  final String currentDriverId;
  const DriverPassengerManifestScreen({super.key, required this.currentDriverId});

  @override
  State<DriverPassengerManifestScreen> createState() => _DriverPassengerManifestScreenState();
}

class _DriverPassengerManifestScreenState extends State<DriverPassengerManifestScreen> {
  bool _isArabic = true; // Language default configuration toggled to Arabic First
  bool _isLoading = false;
  List<dynamic> _passengerManifestList = [];

  @override
  void initState() {
    super.initState();
    _loadAssignedPassengersList();
  }

  /// Queries current passengers linked to this active vehicle routing boundary
  Future<void> _loadAssignedPassengersList() async {
    setState(() => _isLoading = true);
    try {
      final token = await SessionStore.token();
      if (token == null) throw StateError('DRIVER_SESSION_REQUIRED');
      final today = DateTime.now().toIso8601String().substring(0, 10);
      final response = await http.get(AppConfig.api('/api/v1/driver/roster').replace(queryParameters: {'serviceDate': today, 'segment': 'MORNING'}), headers: {'Authorization': 'Bearer $token'});
      if (response.statusCode == 200 && (response.headers['content-type'] ?? '').toLowerCase().contains('application/json')) {
        final Map<String, dynamic> data = jsonDecode(response.body) as Map<String, dynamic>;
        setState(() {
          _passengerManifestList = data['roster'] ?? [];
        });
      }
    } catch (e) {
      _showFeedbackSnackBar(_isArabic ? "خطأ في تحميل قائمة الركاب" : "Error syncing manifest tracking records.");
    } finally {
      setState(() => _isLoading = false);
    }
  }

  /// Toggles individual child deployment statuses dynamically
  Future<void> _togglePassengerDeployment(String passengerId, bool currentEnabledState) async {
    // In a full production loop, this dispatches a mutation payload to public.passenger_driver_assignments
    _showFeedbackSnackBar(
      _isArabic 
        ? "تم تحديث حالة تفعيل الراكب بنجاح" 
        : "Passenger state mutation completed."
    );
  }

  void _showFeedbackSnackBar(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg, style: const TextStyle(fontFamily: 'Al Messri'))));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF005B60), // Corporate Dark Teal Identity Tone
        foregroundColor: Colors.white,
        title: Text(
          _isArabic ? "إدارة الركاب والمشتركين" : "Passenger Manifest Registry",
          style: const TextStyle(fontFamily: 'Al Messri', fontWeight: FontWeight.bold),
        ),
        actions: [
          TextButton(
            onPressed: () => setState(() => _isArabic = !_isArabic),
            child: Text(_isArabic ? "English" : "العربية", style: const TextStyle(color: Colors.white)),
          )
        ],
      ),
      body: Directionality(
        textDirection: _isArabic ? TextDirection.rtl : TextDirection.ltr,
        child: _isLoading
            ? const Center(child: CircularProgressIndicator(color: Color(0xFF005B60)))
            : Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    color: const Color(0xFF005B60).withOpacity(0.06),
                    child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(_isArabic ? "إجمالي المسجلين في الحافلة:" : "Total Subscribers On Board:"),
                        Text(
                          "${_passengerManifestList.length}",
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xFF005B60)),
                        )
                      ],
                    ),
                  ),
                  Expanded(
                    child: _passengerManifestList.isEmpty
                        ? Center(child: Text(_isArabic ? "لا يوجد ركاب معينين لك حالياً" : "No passengers assigned to your manifest."))
                        : ListView.builder(
                            itemCount: _passengerManifestList.length,
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            itemBuilder: (context, index) {
                              final node = _passengerManifestList[index];
                              final String passengerId = node['passengerId'].toString();
                              
                              return Card(
                                margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                                child: ListTile(
                                  leading: const CircleAvatar(
                                    backgroundColor: Color(0xFF005B60),
                                    child: Icon(Icons.person, color: Colors.white),
                                  ),
                                  title: Text(
                                    node['passengerName'],
                                    style: const TextStyle(fontWeight: FontWeight.bold),
                                  ),
                                  subtitle: Text("ID: $passengerId • ${_isArabic ? 'رقم الواتساب' : 'WhatsApp'}"),
                                  trailing: PopupMenuButton<String>(
                                    onSelected: (action) {
                                      if (action == 'disable') {
                                        _togglePassengerDeployment(passengerId, false);
                                      }
                                    },
                                    itemBuilder: (context) => [
                                      PopupMenuItem(
                                        value: 'disable',
                                        child: Text(_isArabic ? "تعطيل المشترك مؤقتاً" : "Disable Tracking Node"),
                                      ),
                                      PopupMenuItem(
                                        value: 'view',
                                        child: Text(_isArabic ? "عرض الملف الكامل" : "View Full Profile"),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
      ),
    );
  }
}
