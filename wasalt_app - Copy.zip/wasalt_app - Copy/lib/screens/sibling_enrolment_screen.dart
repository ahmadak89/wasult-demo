﻿// C:\src\wasalt_app\lib\screens\sibling_enrolment_screen.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../core/config/app_config.dart';
import '../services/session_store.dart';

class SiblingEnrolmentScreen extends StatefulWidget {
  const SiblingEnrolmentScreen({super.key});

  @override
  State<SiblingEnrolmentScreen> createState() => _SiblingEnrolmentScreenState();
}

class _SiblingEnrolmentScreenState extends State<SiblingEnrolmentScreen> {
  bool _isArabic = true; // Language default configuration toggled to Arabic First
  bool _isProcessing = false;

  final _formKey = GlobalKey<FormState>();
  final TextEditingController _siblingIdController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _driverIdController = TextEditingController();

  @override
  void dispose() {
    _siblingIdController.dispose();
    _nameController.dispose();
    _driverIdController.dispose();
    super.dispose();
  }

  /// Transmits additional passenger records asynchronously to the Node service.
  Future<void> _executeSiblingEnrolment() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isProcessing = true);
    try {
      final token = await SessionStore.token();
      final response = await http.post(
        AppConfig.api('/api/v1/guardian/children'),
        headers: {"Content-Type": "application/json", "Authorization": "Bearer ${token ?? ''}"},
        body: jsonEncode({
          "childId": _siblingIdController.text.trim(),
          "fullName": _nameController.text.trim(),
          "uniqueDriverCode": _driverIdController.text.trim()
        }),
      );

      if (!mounted) return;
      final Map<String, dynamic> responsePayload = jsonDecode(response.body);

      if (response.statusCode == 201 && responsePayload['success'] == true) {
        _displayFeedbackBanner(_isArabic ? "تم تسجيل الراكب الإضافي وربط سائقه الحصري!" : "Passenger added and bound to a separate tracking channel!");
        Navigator.pop(context);
      } else {
        final code = responsePayload['error_code'];
        final message = code == 'VEHICLE_MONITOR_LIMIT_REACHED'
            ? (_isArabic ? "يمكن متابعة ثلاث مركبات كحد أقصى" : "You can monitor at most three vehicles.")
            : code == 'ACTIVE_DRIVER_CODE_NOT_FOUND'
                ? (_isArabic ? "رمز السائق غير موجود أو غير نشط" : "Driver code was not found or is inactive.")
                : (_isArabic ? "تعذر إضافة الراكب. تحقق من المعرف." : "Unable to add the passenger. Check the identifier.");
        _displayFeedbackBanner(message);
      }
    } catch (e) {
      _displayFeedbackBanner(_isArabic ? "فشل الاتصال بمخدم المسارات الإقليمي" : "Unable to establish communication with local API backend.");
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  void _displayFeedbackBanner(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text, style: const TextStyle(fontFamily: 'Al Messri'))));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF005B60),
        foregroundColor: Colors.white,
        title: Text(_isArabic ? "إضافة راكب جديد" : "Add Passenger", style: const TextStyle(fontFamily: 'Al Messri')),
        actions: [
          TextButton(
            onPressed: () => setState(() => _isArabic = !_isArabic),
            child: Text(_isArabic ? "English" : "العربية", style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          )
        ],
      ),
      body: Directionality(
        textDirection: _isArabic ? TextDirection.rtl : TextDirection.ltr,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _label(_isArabic ? 'معرّف الراكب (رقم المدرسة أو الهوية)' : 'Passenger ID', TextFormField(
                  controller: _siblingIdController,
                  decoration: InputDecoration(
                    hintText: _isArabic ? "أدخل معرّف الراكب" : "Enter passenger ID",
                    border: const OutlineInputBorder(),
                    prefixIcon: const Icon(Icons.badge_outlined),
                  ),
                  validator: (v) => v == null || v.trim().isEmpty ? (_isArabic ? "الحقل مطلوب" : "Required field") : null,
                )),
                const SizedBox(height: 16),

                _label(_isArabic ? 'الاسم الكامل للراكب' : 'Passenger full legal name', TextFormField(
                  controller: _nameController,
                  decoration: InputDecoration(
                    hintText: _isArabic ? "أدخل الاسم الكامل" : "Enter full legal name",
                    border: const OutlineInputBorder(),
                    prefixIcon: const Icon(Icons.person_outline),
                  ),
                  validator: (v) => v == null || v.trim().isEmpty ? (_isArabic ? "الحقل مطلوب" : "Required field") : null,
                )),
                const SizedBox(height: 16),

                _label(_isArabic ? 'رمز السائق المخصص للراكب' : 'Unique driver code for this passenger', TextFormField(
                  controller: _driverIdController,
                  decoration: InputDecoration(
                    hintText: _isArabic ? "أدخل رمز السائق" : "Enter driver code",
                    border: const OutlineInputBorder(),
                    prefixIcon: const Icon(Icons.directions_bus_outlined),
                    helperText: _isArabic ? "تتيح لك وصلت تعيين سائق مختلف لكل راكب" : "Wasult allows matching unique drivers per passenger.",
                  ),
                  validator: (v) => v == null || v.trim().isEmpty ? (_isArabic ? "الحقل مطلوب" : "Required field") : null,
                )),
                const SizedBox(height: 32),

                // Submit Onboarding Intent Button
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF005B60),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: _isProcessing ? null : _executeSiblingEnrolment,
                  child: _isProcessing
                      ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                      : Text(
                          _isArabic ? "تأكيد تسجيل الراكب" : "Confirm passenger onboarding",
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Al Messri'),
                        ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _label(String label, Widget field) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 7), field]);
}
