﻿// C:\src\wasalt_app\lib\screens\driver_profile_update_screen.dart
import 'package:flutter/material.dart';

class DriverProfileUpdateScreen extends StatefulWidget {
  const DriverProfileUpdateScreen({super.key});

  @override
  State<DriverProfileUpdateScreen> createState() => _DriverProfileUpdateScreenState();
}

class _DriverProfileUpdateScreenState extends State<DriverProfileUpdateScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController(text: "أحمد الكواري");
  final _plateController = TextEditingController(text: "QA-55421");
  String _vehicleType = "bus";

  Future<void> _saveDriverProfileData() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    // Profile changes are performed in the authenticated Driver workspace. Do
    // not call a placeholder URL here: it could return the HTML app shell.
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("تم حفظ التغييرات محلياً. استخدم مساحة السائق لإرسالها للمراجعة.")));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: const Color(0xFF005B60), foregroundColor: Colors.white, title: const Text("ملف السائق الشخصي")),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextFormField(controller: _nameController, decoration: const InputDecoration(labelText: "اسم السائق بالكامل", border: OutlineInputBorder())),
                const SizedBox(height: 16),
                TextFormField(controller: _plateController, decoration: const InputDecoration(labelText: "رقم اللوحة المرورية", border: OutlineInputBorder())),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: _vehicleType,
                  decoration: const InputDecoration(labelText: "نوع حافلة النقل", border: OutlineInputBorder()),
                  items: const [DropdownMenuItem(value: "bus", child: Text("حافلة مدرسة جماعية")), DropdownMenuItem(value: "car", child: Text("سيارة ركاب صغيرة"))],
                  onChanged: (v) => setState(() => _vehicleType = v ?? "bus"),
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: _saveDriverProfileData,
                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF005B60), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 16)),
                  child: const Text("تحديث وحفظ البيانات الشخصية"),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
