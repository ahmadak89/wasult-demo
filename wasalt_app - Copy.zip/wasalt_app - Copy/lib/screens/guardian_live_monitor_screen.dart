﻿// C:\src\wasalt_app\lib\screens\guardian_live_monitor_screen.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../core/config/app_config.dart';
import '../services/session_store.dart';

class GuardianLiveMonitorScreen extends StatefulWidget {
  final String guardianPassengerId;
  const GuardianLiveMonitorScreen({super.key, required this.guardianPassengerId});

  @override
  State<GuardianLiveMonitorScreen> createState() => _GuardianLiveMonitorScreenState();
}

class _GuardianLiveMonitorScreenState extends State<GuardianLiveMonitorScreen> {
  bool _isArabic = true; // Multi-lingual selection variable default to Arabic First
  bool _isPollingActive = true;
  List<dynamic> _monitoredDriversList = [];
  Timer? _pollingIntervalTimer;

  @override
  void initState() {
    super.initState();
    _fetchLiveTelemetrySnapshot();
    // Establish a high-frequency telemetry query sweep loop every 10 seconds
    _pollingIntervalTimer = Timer.periodic(const Duration(seconds: 10), (timer) {
      if (_isPollingActive) _fetchLiveTelemetrySnapshot();
    });
  }

  /// Queries the aggregated multiplex snapshot endpoint on port 3000
  Future<void> _fetchLiveTelemetrySnapshot() async {
    try {
      final token = await SessionStore.token();
      if (token == null) return;
      final response = await http.get(AppConfig.api('/api/v1/telemetry/multi-child-snapshot'), headers: {'Authorization': 'Bearer $token'});
      if (response.statusCode == 200 && (response.headers['content-type'] ?? '').toLowerCase().contains('application/json')) {
        final Map<String, dynamic> data = jsonDecode(response.body) as Map<String, dynamic>;
        setState(() {
          // STRICT COMPLIANCE: Limit observation vector array up to max 3 drivers simultaneously
          List<dynamic> nodes = data['active_monitored_nodes'] ?? data['snapshots'] ?? [];
          _monitoredDriversList = nodes.length > 3 ? nodes.sublist(0, 3) : nodes;
        });
      }
    } catch (e) {
      debugPrint("[Wasult Network Telemetry Sync Crash]: $e");
    }
  }

  @override
  void dispose() {
    _pollingIntervalTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF005B60), // Corporate Dark Teal core tone
        foregroundColor: Colors.white,
        title: Text(
          _isArabic ? "مراقبة الحافلات المباشرة" : "Live Driver Monitor",
          style: const TextStyle(fontFamily: 'Al Messri', fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: Icon(_isPollingActive ? Icons.sync : Icons.sync_disabled),
            onPressed: () => setState(() => _isPollingActive = !_isPollingActive),
          ),
          TextButton(
            onPressed: () => setState(() => _isArabic = !_isArabic),
            child: Text(_isArabic ? "English" : "العربية", style: const TextStyle(color: Colors.white)),
          )
        ],
      ),
      body: Directionality(
        textDirection: _isArabic ? TextDirection.rtl : TextDirection.ltr,
        child: Column(
          children: [
            // Status bar showing telemetry activity counts
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              color: const Color(0xFF005B60).withOpacity(0.08),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    _isArabic ? "المركبات قيد التتبع النشط (الحد الأقصى 3):" : "Monitored Vehicles (Max 3):",
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Text(
                    "${_monitoredDriversList.length} / 3",
                    style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF005B60), fontSize: 16),
                  )
                ],
              ),
            ),
            
            Expanded(
              child: _monitoredDriversList.isEmpty
                  ? Center(child: Text(_isArabic ? "لا توجد حافلات نشطة في مسارك حالياً" : "No active routes monitored."))
                  : ListView.builder(
                      itemCount: _monitoredDriversList.length,
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      itemBuilder: (context, index) {
                        final node = _monitoredDriversList[index];
                        final driver = node['driver'];
                        final telemetry = node['telemetry'];
                        final String tripState = driver['tripState'] ?? 'Idle';

                        return Card(
                          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          child: Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "${_isArabic ? 'الراكب' : 'Passenger'}: ${node['passengerName']}",
                                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                                    ),
                                    // Material Status Tag Mapping dynamically matching driver progress states
                                    _buildStateIndicatorBadge(tripState),
                                  ],
                                ),
                                const Divider(height: 20),
                                Text("${_isArabic ? 'السائق الحالي' : 'Driver'}: ${driver['name']}"),
                                Text("${_isArabic ? 'رقم اللوحة' : 'Vehicle Plate'}: ${driver['plate']}"),
                                
                                if (telemetry != null) ...[
                                  const SizedBox(height: 6),
                                  Text("${_isArabic ? 'السرعة الحالية' : 'Current Speed'}: ${telemetry['speedKmh']} ${_isArabic ? 'كم/س' : 'km/h'}"),
                                  Text(
                                    "${_isArabic ? 'آخر تحديث لموقع الإحداثيات' : 'Last Coordinate Link'}: ${telemetry['recordedAt'].toString().substring(11, 19)}",
                                    style: const TextStyle(color: Colors.grey, fontSize: 12),
                                  ),
                                ] else ...[
                                  const SizedBox(height: 6),
                                  Text(
                                    _isArabic ? "لا توجد إشارات GPS صادرة من السائق" : "No GPS logs emitted by driver.",
                                    style: const TextStyle(color: Colors.orange, fontSize: 13),
                                  ),
                                ]
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStateIndicatorBadge(String tripState) {
    Color badgeColor;
    String labelAr;
    String labelEn;

    switch (tripState.toLowerCase()) {
      case 'live':
      case 'on the way':
        badgeColor = Colors.green;
        labelAr = "في الطريق";
        labelEn = "On The Way";
        break;
      case 'approaching':
        badgeColor = Colors.orange;
        labelAr = "اقترب من الموقع";
        labelEn = "Approaching";
        break;
      case 'arrived':
        badgeColor = Colors.blue;
        labelAr = "وصل الموقع";
        labelEn = "Arrived";
        break;
      default:
        badgeColor = Colors.grey;
        labelAr = "غير نشط";
        labelEn = "Idle";
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: badgeColor.withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
      child: Text(
        _isArabic ? labelAr : labelEn,
        style: TextStyle(color: badgeColor, fontWeight: FontWeight.bold, fontSize: 12, fontFamily: 'Al Messri'),
      ),
    );
  }
}
