﻿// C:\src\wasalt_app\lib\screens\driver_qr_scanner_screen.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../core/config/app_config.dart';
import '../services/session_store.dart';

class DriverQrScannerScreen extends StatefulWidget {
  const DriverQrScannerScreen({super.key});

  @override
  State<DriverQrScannerScreen> createState() => _DriverQrScannerScreenState();
}

class _DriverQrScannerScreenState extends State<DriverQrScannerScreen> {
  final TextEditingController _payloadTextController = TextEditingController();
  bool _isProcessing = false;
  String _scanResultDiagnosticLog = "Awaiting inbound dynamic attendance payload text data stream...";

  Future<void> _submitScannedQrPayload(String scannedString) async {
    if (scannedString.trim().isEmpty) return;
    setState(() {
      _isProcessing = true;
      _scanResultDiagnosticLog = "Processing cryptographic check-in signature...";
    });

    try {
      final driverId = await SessionStore.userId();
      final token = await SessionStore.token();
      if (driverId == null || token == null) throw StateError('DRIVER_SESSION_REQUIRED');
      final res = await http.post(AppConfig.api('/api/v1/linkage/verify-attendance-qr'),
        headers: {"Content-Type": "application/json", "Authorization": "Bearer $token"},
        body: jsonEncode({"qrPayloadString": scannedString.trim(), "driverId": driverId}));
      if (!(res.headers['content-type'] ?? '').toLowerCase().contains('application/json')) throw const FormatException('NON_JSON_API_RESPONSE');
      final Map<String, dynamic> data = jsonDecode(res.body) as Map<String, dynamic>;

      setState(() {
        if (res.statusCode == 200 && data['success'] == true) {
          _scanResultDiagnosticLog = "SUCCESS: Passenger check-in verified for your active roster.";
        } else {
          _scanResultDiagnosticLog = "REJECTED: Verification check failed. Code: ${data['error_code']}";
        }
      });
    } catch (e) {
      setState(() => _scanResultDiagnosticLog = "CRITICAL: Network communication error connecting to backend.");
    } finally {
      setState(() => _isProcessing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: const Color(0xFF005B60), foregroundColor: Colors.white, title: const Text("كاميرا مسح رمز الحضور (السائق)")),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                height: 180,
                decoration: BoxDecoration(color: Colors.black.withOpacity(0.05), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFF005B60), width: 1.5)),
                child: const Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.qr_code_scanner, size: 54, color: Color(0xFF005B60)),
                    SizedBox(height: 10),
                    Text("عدسة محاكاة المسح المباشر نشطة", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              TextField(
                controller: _payloadTextController,
                decoration: const InputDecoration(labelText: "أدخل أو الصق نص الرمز المشفر هنا للتجربة", border: OutlineInputBorder()),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: _isProcessing ? null : () => _submitScannedQrPayload(_payloadTextController.text),
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF005B60), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14)),
                child: const Text("تأكيد ومعالجة الرمز المشفر"),
              ),
              const SizedBox(height: 24),
              Container(
                padding: const EdgeInsets.all(16),
                color: Colors.grey.withOpacity(0.12),
                child: Text(_scanResultDiagnosticLog, style: const TextStyle(fontFamily: 'monospace', fontSize: 13, fontWeight: FontWeight.bold)),
              )
            ],
          ),
        ),
      ),
    );
  }
}
