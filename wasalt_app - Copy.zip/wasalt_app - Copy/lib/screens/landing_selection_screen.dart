import 'package:flutter/material.dart';
import '../design/wasult_theme.dart';
import '../design/wasult_widgets.dart';

class LandingSelectionScreen extends StatefulWidget {
  const LandingSelectionScreen({super.key});
  @override
  State<LandingSelectionScreen> createState() => _LandingSelectionScreenState();
}

class _LandingSelectionScreenState extends State<LandingSelectionScreen> {
  bool _isArabic = true;
  String t(String ar, String en) => _isArabic ? ar : en;
  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: _isArabic ? TextDirection.rtl : TextDirection.ltr,
    child: Scaffold(body: SafeArea(child: LayoutBuilder(builder: (context, constraints) {
      final wide = constraints.maxWidth >= 760;
      return SingleChildScrollView(
        padding: EdgeInsets.symmetric(horizontal: wide ? 54 : 20, vertical: 18),
        child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 1080), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            Image.asset('assets/images/logo.png', width: 52, height: 52), const SizedBox(width: 12),
            const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('وصلت', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: WasultColors.teal)), Text('WASULT', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 2.4, color: WasultColors.muted))]),
            const Spacer(), TextButton.icon(onPressed: () => setState(() => _isArabic = !_isArabic), icon: const Icon(Icons.language_rounded), label: Text(_isArabic ? 'English' : 'العربية')),
          ]),
          const SizedBox(height: 30),
          Container(
            padding: EdgeInsets.all(wide ? 40 : 24),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [WasultColors.tealDark, WasultColors.teal]), borderRadius: BorderRadius.circular(32), boxShadow: const [BoxShadow(color: Color(0x33005B60), blurRadius: 34, offset: Offset(0, 18))]),
            child: Flex(direction: wide ? Axis.horizontal : Axis.vertical, children: [
              Expanded(flex: wide ? 3 : 0, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7), decoration: BoxDecoration(color: Colors.white.withValues(alpha: .12), borderRadius: BorderRadius.circular(999)), child: Text(t('منصة النقل الذكي الآمن', 'Safe smart mobility'), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700))),
                const SizedBox(height: 20),
                Text(t('تابع رحلتهم.\nواطمئن في كل محطة.', 'Follow every journey.\nFeel safe at every stop.'), style: const TextStyle(color: Colors.white, fontSize: 34, height: 1.25, fontWeight: FontWeight.w900)),
                const SizedBox(height: 14),
                Text(t('تتبّع مباشر، حضور آمن، وتنبيهات تصل في الوقت المناسب.', 'Live tracking, secure attendance, and timely alerts.'), style: const TextStyle(color: Color(0xFFD7EEEE), height: 1.6, fontSize: 15)),
              ])),
              if (wide) const SizedBox(width: 40) else const SizedBox(height: 26),
              Image.asset('assets/images/logo.png', width: wide ? 220 : 150, height: wide ? 220 : 150),
            ]),
          ),
          const SizedBox(height: 26),
          Text(t('اختر بوابتك', 'Choose your workspace'), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text(t('يمكنك تغيير اللغة أو الدور لاحقاً من الإعدادات.', 'You can change language or role later in settings.'), style: const TextStyle(color: WasultColors.muted)),
          const SizedBox(height: 18),
          GridView.count(crossAxisCount: wide ? 5 : 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisSpacing: 14, mainAxisSpacing: 14, childAspectRatio: wide ? 1.05 : .88, children: [
            _RoleCard(icon: Icons.family_restroom_rounded, title: t('ولي الأمر', 'Guardian'), subtitle: t('الأطفال والرحلات', 'Children & trips'), onTap: () => Navigator.pushNamed(context, '/login-guardian')),
            _RoleCard(icon: Icons.directions_bus_filled_rounded, title: t('السائق', 'Driver'), subtitle: t('المسار والحضور', 'Route & attendance'), onTap: () => Navigator.pushNamed(context, '/login-driver')),
            _RoleCard(icon: Icons.apartment_rounded, title: t('الشركات', 'Corporate'), subtitle: t('الأسطول والاشتراك', 'Fleet & subscription'), onTap: () => Navigator.pushNamed(context, '/login-corporate')),
            _RoleCard(icon: Icons.admin_panel_settings_rounded, title: t('الإدارة العليا', 'Super admin'), subtitle: t('التحكم والامتثال', 'Control & compliance'), onTap: () => Navigator.pushNamed(context, '/login-superadmin')),
            _RoleCard(icon: Icons.campaign_rounded, title: t('المعلن', 'Advertiser'), subtitle: t('الحملات والفواتير', 'Campaigns & billing'), onTap: () => Navigator.pushNamed(context, '/login-advertiser')),
          ]),
          const SizedBox(height: 22),
          WasultPressButton(label: t('متابعة كولي أمر أو راكب', 'Continue as guardian or passenger'), icon: Icons.arrow_forward_rounded, color: WasultColors.orange, onPressed: () => Navigator.pushNamed(context, '/login-guardian')),
          const SizedBox(height: 22),
          Center(child: Text(t('بوابة آمنة • دعم عربي وإنجليزي • خصوصية أولاً', 'Secure access • Arabic & English • Privacy first'), style: const TextStyle(color: WasultColors.muted, fontSize: 12))),
        ]))),
      );
    }))),
  );
}

class _RoleCard extends StatefulWidget {
  const _RoleCard({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon; final String title; final String subtitle; final VoidCallback onTap;
  @override State<_RoleCard> createState() => _RoleCardState();
}

class _RoleCardState extends State<_RoleCard> {
  bool pressed = false;
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTapDown: (_) => setState(() => pressed = true), onTapCancel: () => setState(() => pressed = false),
    onTapUp: (_) { setState(() => pressed = false); widget.onTap(); },
    child: AnimatedScale(scale: pressed ? .96 : 1, duration: const Duration(milliseconds: 100), child: WasultPanel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(width: 48, height: 48, decoration: BoxDecoration(color: WasultColors.tealSoft, borderRadius: BorderRadius.circular(16)), child: Icon(widget.icon, color: WasultColors.teal, size: 27)),
      const Spacer(), Text(widget.title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)), const SizedBox(height: 5), Text(widget.subtitle, style: const TextStyle(fontSize: 12, color: WasultColors.muted)), const SizedBox(height: 10), const Align(alignment: AlignmentDirectional.centerEnd, child: Icon(Icons.arrow_forward_rounded, color: WasultColors.orange)),
    ]))),
  );
}
