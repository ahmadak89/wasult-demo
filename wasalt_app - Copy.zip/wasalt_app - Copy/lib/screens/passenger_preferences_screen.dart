﻿// passenger_preferences_screen.dart
import 'package:flutter/material.dart';

class PassengerPreferencesScreen extends StatefulWidget {
  const PassengerPreferencesScreen({super.key});

  @override
  State<PassengerPreferencesScreen> createState() => _PassengerPreferencesScreenState();
}

class _PassengerPreferencesScreenState extends State<PassengerPreferencesScreen> {
  // UC-5 State Metrics Flags
  bool _isWhatsAppEnabled = true;
  bool _isPushEnabled = true;
  bool _isAdHocBookingActive = false;
  String _selectedLanguage = 'ar'; // Default language setting rule matches Arabic default template

  void _saveSystemPreferences() {
    // Persistent local caching storage hooks execute cleanly here via SharedPreferences layer
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          "تم حفظ الإعدادات بنجاح | Preference Matrix Synchronized",
          style: TextStyle(fontFamily: 'Al Messri', fontSize: 16),
        ),
        backgroundColor: Colors.teal,
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isRtl = _selectedLanguage == 'ar';

    return Directionality(
      textDirection: isRtl ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            "إعدادات الحساب والخصوصية", 
            style: TextStyle(fontFamily: 'Al Messri', fontWeight: FontWeight.bold),
          ),
          backgroundColor: Colors.teal.shade700,
          foregroundColor: Colors.white,
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Language Selector Row Layout Element
              const Text(
                "اللغة المفضلة / Application Language",
                style: TextStyle(fontFamily: 'Al Messri', fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: _selectedLanguage,
                decoration: const InputDecoration(border: OutlineInputBorder()),
                items: const [
                  DropdownMenuItem(value: 'ar', child: Text("العربية (الافتراضية)", style: TextStyle(fontFamily: 'Al Messri'))),
                  DropdownMenuItem(value: 'en', child: Text("English (Wasult)", style: TextStyle(fontFamily: 'Al Messri'))),
                  DropdownMenuItem(value: 'fr', child: Text("Français", style: TextStyle(fontFamily: 'Al Messri'))),
                  DropdownMenuItem(value: 'es', child: Text("Español", style: TextStyle(fontFamily: 'Al Messri'))),
                ],
                onChanged: (value) {
                  setState(() {
                    if (value != null) _selectedLanguage = value;
                  });
                },
              ),
              const Divider(height: 40, thickness: 1.5),

              // UC-5 Feature Control Grid Section Heading
              const Text(
                "قنوات الإشعارات والتحكم الذاتي",
                style: TextStyle(fontFamily: 'Al Messri', fontSize: 18, fontWeight: FontWeight.bold, color: Colors.teal),
              ),
              const SizedBox(height: 6),
              const Text(
                "تخصيص كيفية استقبال تنبيهات اقتراب المركبة والرحلات اليومية",
                style: TextStyle(fontFamily: 'Al Messri', fontSize: 13, color: Colors.grey),
              ),
              const SizedBox(height: 20),

              // Toggle Element Card 1: WhatsApp Communications Rule Filter
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: SwitchListTile(
                  title: const Text("تفعيل رسائل الواتساب تفاعلية", style: TextStyle(fontFamily: 'Al Messri', fontWeight: FontWeight.bold)),
                  subtitle: const Text("استقبال إشعار اقتراب بمسافة 500م عبر قنوات الواتساب", style: TextStyle(fontFamily: 'Al Messri', fontSize: 12)),
                  value: _isWhatsAppEnabled,
                  activeColor: Colors.teal,
                  onChanged: (bool value) {
                    setState(() {
                      _isWhatsAppEnabled = value;
                    });
                  },
                ),
              ),
              const SizedBox(height: 12),

              // Toggle Element Card 2: Native Device Push Signals
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: SwitchListTile(
                  title: const Text("إشعارات الهاتف المباشرة (Push)", style: TextStyle(fontFamily: 'Al Messri', fontWeight: FontWeight.bold)),
                  subtitle: const Text("عرض التنبيهات المنبثقة على الشاشة الرئيسية للجهاز", style: TextStyle(fontFamily: 'Al Messri', fontSize: 12)),
                  value: _isPushEnabled,
                  activeColor: Colors.teal,
                  onChanged: (bool value) {
                    setState(() {
                      _isPushEnabled = value;
                    });
                  },
                ),
              ),
              const SizedBox(height: 12),

              // Toggle Element Card 3: Ad-Hoc Alternative Booking Engine Rule
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: SwitchListTile(
                  title: const Text("طلبات التعديل اللحظي (Ad-Hoc)", style: TextStyle(fontFamily: 'Al Messri', fontWeight: FontWeight.bold)),
                  subtitle: const Text("السماح بحجز رحلات مؤقتة وتغيير العناوين الافتراضية", style: TextStyle(fontFamily: 'Al Messri', fontSize: 12)),
                  value: _isAdHocBookingActive,
                  activeColor: Colors.teal,
                  onChanged: (bool value) {
                    setState(() {
                      _isAdHocBookingActive = value;
                    });
                  },
                ),
              ),
              const SizedBox(height: 40),

              // Core Responsive Interaction Save Button
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton(
                  onPressed: _saveSystemPreferences,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal.shade700,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text(
                    "حفظ التغييرات / Save Preferences",
                    style: TextStyle(fontFamily: 'Al Messri', fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
