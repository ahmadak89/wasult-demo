import 'package:flutter/material.dart';
import 'role_login_screen.dart';
class DriverLoginScreen extends StatelessWidget { const DriverLoginScreen({super.key}); @override Widget build(BuildContext context)=>const RoleLoginScreen(role:'DRIVER',destination:'/driver-trip',title:'دخول السائق',icon:Icons.directions_bus_filled_rounded); }
