import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../design/wasult_theme.dart';
import '../design/wasult_widgets.dart';
import '../services/demo_store.dart';
import '../services/alert_audio_service.dart';
import '../services/operational_message_client.dart';
import '../services/private_trip_client.dart';
import '../services/journey_completion_client.dart';
import '../services/emergency_alert_client.dart';
import '../core/config/app_config.dart';
import '../widgets/wasult_osm_map.dart';
import '../widgets/location_picker.dart';

class DemoWorkspaceScreen extends StatefulWidget {
  const DemoWorkspaceScreen({super.key, required this.role});
  final String role;
  @override
  State<DemoWorkspaceScreen> createState() => _DemoWorkspaceScreenState();
}

class _DemoWorkspaceScreenState extends State<DemoWorkspaceScreen> {
  final store = DemoStore.instance;
  final alertAudio = AlertAudioService();
  Timer? timer;
  int tab = 0;
  bool busy = false;
  bool loadingInbox = false;
  List<OperationalMessage> inboxMessages = const [];
  late final List<_Page> pages = switch (widget.role) {
    'GUARDIAN' => const [
        _Page('الرحلات', Icons.map_rounded),
        _Page('الركاب', Icons.groups_rounded),
        _Page('المحفظة', Icons.account_balance_wallet_rounded),
        _Page('التنبيهات', Icons.notifications_rounded),
        _Page('الإعدادات', Icons.tune_rounded)
      ],
    'DRIVER' => const [
        _Page('الرحلة', Icons.route_rounded),
        _Page('الركاب', Icons.groups_rounded),
        _Page('الرسائل', Icons.chat_rounded),
        _Page('الملف والتقرير', Icons.assignment_rounded)
      ],
    'CORPORATE_ADMIN' => const [
        _Page('نظرة عامة', Icons.dashboard_rounded),
        _Page('الأسطول', Icons.directions_bus_rounded),
        _Page('أجهزة GPS', Icons.sensors_rounded),
        _Page('الاشتراك', Icons.receipt_long_rounded),
        _Page('التنبيهات', Icons.notifications_rounded),
        _Page('هوية الشركة', Icons.palette_rounded)
      ],
    'SUPER_ADMIN' => const [
        _Page('المنصة', Icons.space_dashboard_rounded),
        _Page('المؤسسات', Icons.apartment_rounded),
        _Page('القواعد', Icons.rule_rounded),
        _Page('الهوية والإعلانات', Icons.palette_rounded),
        _Page('التدقيق والحملات', Icons.fact_check_rounded),
        _Page('التقارير', Icons.analytics_rounded),
        _Page('الإعدادات العامة', Icons.settings_rounded),
        _Page('الهوية والصلاحيات', Icons.admin_panel_settings_rounded),
        _Page('المالية والتسويات', Icons.account_balance_rounded),
        _Page('الحوادث والبيانات', Icons.health_and_safety_rounded),
        _Page('السلامة والاستمرارية', Icons.health_and_safety_rounded),
        _Page('كيانات الأسطول والإعلان', Icons.account_tree_rounded)
      ],
    _ => const [
        _Page('لوحة المعلن', Icons.campaign_rounded),
        _Page('الحملات', Icons.view_list_rounded),
        _Page('الأصول', Icons.image_rounded),
        _Page('المخزون والمواضع', Icons.inventory_2_outlined),
        _Page('الفواتير', Icons.receipt_long_rounded),
        _Page('التقارير', Icons.analytics_rounded),
        _Page('إعدادات البوابة', Icons.tune_rounded),
        _Page('التنبيهات', Icons.notifications_rounded)
      ],
  };

  @override
  void initState() {
    super.initState();
    store.initialize();
    if (!AppConfig.mockMode) _loadInbox();
    timer = Timer.periodic(const Duration(seconds: 3), (_) => store.refresh());
  }

  Future<void> _loadInbox() async {
    if (!mounted) return;
    setState(() => loadingInbox = true);
    final messages = await const OperationalMessageClient().inbox();
    if (mounted)
      setState(() {
        inboxMessages = messages;
        loadingInbox = false;
      });
  }

  @override
  void dispose() {
    timer?.cancel();
    alertAudio.dispose();
    super.dispose();
  }

  String get title => switch (widget.role) {
        'GUARDIAN' => 'بوابة ولي الأمر',
        'DRIVER' => 'مساحة السائق',
        'CORPORATE_ADMIN' => 'إدارة الأسطول',
        'SUPER_ADMIN' => 'مركز الإدارة العليا',
        _ => 'بوابة المعلن',
      };

  void toast(String message) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(message)));
  String newId(String prefix) =>
      '$prefix-${DateTime.now().millisecondsSinceEpoch.toString().substring(5)}';

  Future<Map<String, String>?> form(String title, List<_Field> fields,
      {Map<String, dynamic>? initial}) async {
    final controllers = {
      for (final field in fields)
        field.key: TextEditingController(text: '${initial?[field.key] ?? ''}')
    };
    final pickedLocations = <String, PickedLocation>{};
    final key = GlobalKey<FormState>();
    final result = await showDialog<Map<String, String>>(
        context: context,
        builder: (dialogContext) => Directionality(
            textDirection: TextDirection.rtl,
            child: AlertDialog(
              title: Text(title),
              content: SizedBox(
                  width: 440,
                  child: Form(
                      key: key,
                      child: SingleChildScrollView(
                          child:
                              Column(mainAxisSize: MainAxisSize.min, children: [
                        for (final field in fields)
                          Padding(
                              padding: const EdgeInsets.only(bottom: 16),
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(field.label,
                                        style: const TextStyle(
                                            fontWeight: FontWeight.w900,
                                            fontSize: 15)),
                                    const SizedBox(height: 7),
                                    if (field.options != null)
                                      DropdownButtonFormField<String>(
                                          value: field.options!.contains(
                                                  controllers[field.key]!.text)
                                              ? controllers[field.key]!.text
                                              : null,
                                          isExpanded: true,
                                          decoration: InputDecoration(
                                              hintText: field.hint),
                                          items: [
                                            for (final item in field.options!)
                                              DropdownMenuItem(
                                                  value: item,
                                                  child: Text(item))
                                          ],
                                          onChanged: (value) =>
                                              controllers[field.key]!.text =
                                                  value ?? '',
                                          validator: (value) =>
                                              field.required &&
                                                      (value == null ||
                                                          value.isEmpty)
                                                  ? 'هذا الحقل مطلوب'
                                                  : null)
                                    else
                                      TextFormField(
                                          controller: controllers[field.key],
                                          readOnly: field.location ||
                                              field.image ||
                                              field.date ||
                                              field.time,
                                          keyboardType: field.number
                                              ? TextInputType.number
                                              : TextInputType.text,
                                          onTap: field.date
                                              ? () async {
                                                  final initial =
                                                      DateTime.tryParse(
                                                              controllers[field
                                                                      .key]!
                                                                  .text) ??
                                                          DateTime.now();
                                                  final selected =
                                                      await showDatePicker(
                                                          context:
                                                              dialogContext,
                                                          initialDate: initial,
                                                          firstDate:
                                                              DateTime(2020),
                                                          lastDate:
                                                              DateTime(2100));
                                                  if (selected != null)
                                                    controllers[field.key]!
                                                            .text =
                                                        '${selected.year.toString().padLeft(4, '0')}-${selected.month.toString().padLeft(2, '0')}-${selected.day.toString().padLeft(2, '0')}';
                                                }
                                              : field.time
                                                  ? () async {
                                                      final match = RegExp(
                                                              r'^(\\d{1,2}):(\\d{2})$')
                                                          .firstMatch(
                                                              controllers[field
                                                                      .key]!
                                                                  .text);
                                                      final selected = await showTimePicker(
                                                          context:
                                                              dialogContext,
                                                          initialTime: match ==
                                                                  null
                                                              ? TimeOfDay.now()
                                                              : TimeOfDay(
                                                                  hour: int.parse(
                                                                      match.group(
                                                                          1)!),
                                                                  minute: int.parse(
                                                                      match.group(
                                                                          2)!)));
                                                      if (selected != null)
                                                        controllers[field.key]!
                                                                .text =
                                                            '${selected.hour.toString().padLeft(2, '0')}:${selected.minute.toString().padLeft(2, '0')}';
                                                    }
                                                  : field.location
                                                      ? () async {
                                                          final picked = await Navigator.of(
                                                                  dialogContext)
                                                              .push<PickedLocation>(MaterialPageRoute(
                                                                  builder: (_) =>
                                                                      LocationPicker(
                                                                          title:
                                                                              field.label)));
                                                          if (picked != null) {
                                                            pickedLocations[
                                                                    field.key] =
                                                                picked;
                                                            controllers[field
                                                                        .key]!
                                                                    .text =
                                                                picked.address;
                                                          }
                                                        }
                                                      : field.image
                                                          ? () async {
                                                              final file = await FilePicker
                                                                  .platform
                                                                  .pickFiles(
                                                                      type: FileType
                                                                          .image,
                                                                      withData:
                                                                          true);
                                                              final picked =
                                                                  file?.files
                                                                      .single;
                                                              if (picked
                                                                      ?.bytes !=
                                                                  null)
                                                                controllers[field
                                                                            .key]!
                                                                        .text =
                                                                    'data:image/*;base64,${base64Encode(picked!.bytes!)}';
                                                            }
                                                          : null,
                                          decoration: InputDecoration(
                                              hintText: field.hint,
                                              suffixIcon: field.date
                                                  ? const Icon(Icons
                                                      .calendar_month_rounded)
                                                  : field.time
                                                      ? const Icon(Icons
                                                          .access_time_rounded)
                                                      : field.location
                                                          ? const Icon(
                                                              Icons.map_rounded)
                                                          : field.image
                                                              ? const Icon(Icons
                                                                  .upload_file_rounded)
                                                              : null),
                                          validator: (value) {
                                            if (field.required &&
                                                (value == null ||
                                                    value.trim().isEmpty))
                                              return 'هذا الحقل مطلوب';
                                            if (field.number &&
                                                double.tryParse(value ?? '') ==
                                                    null)
                                              return 'أدخل رقماً صحيحاً';
                                            return null;
                                          }),
                                    if (field.image &&
                                        controllers[field.key]!.text.isNotEmpty)
                                      Padding(
                                          padding:
                                              const EdgeInsets.only(top: 8),
                                          child: imagePreview(
                                              controllers[field.key]!.text)),
                                  ])),
                      ])))),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(dialogContext),
                    child: const Text('إلغاء')),
                FilledButton.icon(
                    onPressed: () {
                      if (key.currentState!.validate()) {
                        final values = <String, String>{
                          for (final entry in controllers.entries)
                            entry.key: entry.value.text.trim()
                        };
                        for (final entry in pickedLocations.entries) {
                          final prefix = switch (entry.key) {
                            'pickupAddress' => 'pickup',
                            'dropoffAddress' => 'dropoff',
                            'startAddress' => 'start',
                            'endAddress' => 'end',
                            _ => entry.key
                          };
                          values['${prefix}Latitude'] =
                              entry.value.point.latitude.toStringAsFixed(6);
                          values['${prefix}Longitude'] =
                              entry.value.point.longitude.toStringAsFixed(6);
                          values['${prefix}LocationSource'] =
                              'MAP_PIN_CONFIRMED';
                        }
                        Navigator.pop(dialogContext, values);
                      }
                    },
                    icon: const Icon(Icons.check_rounded),
                    label: const Text('حفظ'))
              ],
            )));
    Future<void>.delayed(const Duration(milliseconds: 300), () {
      for (final controller in controllers.values) {
        controller.dispose();
      }
    });
    return result;
  }

  Widget action(String label, IconData icon, VoidCallback onPressed,
          {bool filled = false, Color? color}) =>
      Padding(
          padding: const EdgeInsets.only(left: 8, bottom: 8),
          child: filled
              ? FilledButton.icon(
                  onPressed: onPressed,
                  icon: Icon(icon),
                  label: Text(label),
                  style: FilledButton.styleFrom(
                      backgroundColor: color ?? WasultColors.teal))
              : OutlinedButton.icon(
                  onPressed: onPressed, icon: Icon(icon), label: Text(label)));
  Widget heading(String text, {Widget? trailing}) => Padding(
      padding: const EdgeInsets.only(top: 20, bottom: 12),
      child: Row(children: [
        Expanded(
            child: Text(text,
                style: const TextStyle(
                    fontSize: 22, fontWeight: FontWeight.w900))),
        if (trailing != null) trailing
      ]));
  Widget panel(Widget child) => Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: WasultPanel(child: child));
  Widget imagePreview(String source) {
    final image = source.startsWith('data:image')
        ? Image.memory(base64Decode(source.substring(source.indexOf(',') + 1)),
            fit: BoxFit.cover)
        : Image.network(source,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) =>
                const Center(child: Icon(Icons.broken_image_outlined)));
    return ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: SizedBox(height: 120, width: double.infinity, child: image));
  }

  Map<String, dynamic> get corporateBrand {
    final value = store.data['corporateBrand'];
    return value is Map
        ? Map<String, dynamic>.from(value)
        : <String, dynamic>{};
  }

  Widget corporateLogo({double size = 42}) {
    final logo = '${corporateBrand['logoData'] ?? ''}';
    if (logo.startsWith('data:image')) {
      return ClipOval(
          child: SizedBox(
              height: size,
              width: size,
              child: Image.memory(
                  base64Decode(logo.substring(logo.indexOf(',') + 1)),
                  fit: BoxFit.cover)));
    }
    return CircleAvatar(
        radius: size / 2,
        backgroundColor: WasultColors.teal,
        child: Text('${corporateBrand['mark'] ?? 'W'}',
            style: TextStyle(
                color: Colors.white,
                fontSize: size * .42,
                fontWeight: FontWeight.w900)));
  }

  Widget stateChip(String value) {
    final active = value == 'Active' ||
        value == 'Live' ||
        value == 'Online' ||
        value == 'Boarded';
    return WasultStatusPill(
        label: value,
        color: active ? WasultColors.success : WasultColors.orange,
        icon: active ? Icons.check_circle_rounded : Icons.pending_rounded);
  }

  Widget rowCard(
          String title, String subtitle, String status, List<Widget> actions) =>
      panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const CircleAvatar(
              backgroundColor: WasultColors.tealSoft,
              child: Icon(Icons.route_rounded, color: WasultColors.teal)),
          const SizedBox(width: 10),
          Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Text(title,
                    style: const TextStyle(
                        fontWeight: FontWeight.w900, fontSize: 16)),
                Text(subtitle,
                    style: const TextStyle(
                        color: WasultColors.muted, fontSize: 12))
              ])),
          stateChip(status)
        ]),
        if (actions.isNotEmpty) ...[
          const Divider(height: 22),
          Wrap(children: actions)
        ]
      ]));
  Widget overviewMap() => const Padding(
      padding: EdgeInsets.only(bottom: 16), child: WasultOsmMap(height: 270));

  Future<void> openMoreMenu() => showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => Directionality(
          textDirection: TextDirection.rtl,
          child: SafeArea(
              child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Wrap(children: [
                    const Padding(
                        padding: EdgeInsets.only(bottom: 10),
                        child: Text('المزيد من الأدوات',
                            style: TextStyle(
                                fontSize: 20, fontWeight: FontWeight.w900))),
                    for (var index = 4; index < pages.length; index++)
                      ListTile(
                          leading:
                              Icon(pages[index].icon, color: WasultColors.teal),
                          title: Text(pages[index].label,
                              style:
                                  const TextStyle(fontWeight: FontWeight.w800)),
                          onTap: () {
                            Navigator.pop(sheetContext);
                            setState(() => tab = index);
                          })
                  ])))));

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
      animation: store,
      builder: (context, _) => Directionality(
          textDirection: TextDirection.rtl,
          child: LayoutBuilder(builder: (context, size) {
            final wide = size.maxWidth >= 850;
            final body = ListView(
                padding: EdgeInsets.fromLTRB(
                    wide ? 28 : 16, 12, wide ? 28 : 16, 110),
                children: [
                  if (widget.role != 'GUARDIAN')
                    panel(const Row(children: [
                      Icon(Icons.science_outlined, color: WasultColors.orange),
                      SizedBox(width: 8),
                      Expanded(
                          child: Text(
                              'وضع تجريبي محلي • كل عمليات الدفع والإرسال والموافقة محاكاة فقط',
                              style: TextStyle(fontWeight: FontWeight.w700)))
                    ])),
                  ..._content(),
                ]);
            final driverLocked =
                widget.role == 'DRIVER' && store.text('tripState') == 'Moving';
            final notificationTab = pages
                .indexWhere((page) => page.icon == Icons.notifications_rounded);
            return Scaffold(
              appBar: AppBar(
                  leading: widget.role == 'CORPORATE_ADMIN'
                      ? Padding(
                          padding: const EdgeInsets.all(8),
                          child: corporateLogo(size: 34))
                      : null,
                  title: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title,
                            style:
                                const TextStyle(fontWeight: FontWeight.w900)),
                        const Text('Amman, Jordan • Mock workspace',
                            style: TextStyle(
                                fontSize: 11, color: WasultColors.muted))
                      ]),
                  actions: [
                    IconButton(
                        tooltip: 'التنبيهات',
                        onPressed: notificationTab < 0
                            ? null
                            : () => setState(() => tab = notificationTab),
                        icon: const Icon(Icons.notifications_outlined)),
                    IconButton(
                        tooltip: 'تبديل الدور',
                        onPressed: () =>
                            Navigator.pushReplacementNamed(context, '/landing'),
                        icon: const Icon(Icons.swap_horiz_rounded))
                  ]),
              body: Stack(children: [
                wide
                    ? Row(children: [
                        NavigationRail(
                            extended: size.maxWidth > 1100,
                            selectedIndex: tab,
                            onDestinationSelected: driverLocked
                                ? null
                                : (value) => setState(() => tab = value),
                            destinations: [
                              for (final page in pages)
                                NavigationRailDestination(
                                    icon: Icon(page.icon),
                                    label: Text(page.label))
                            ]),
                        Expanded(child: body)
                      ])
                    : body,
                if (driverLocked)
                  Positioned.fill(
                      child: ColoredBox(
                          color: const Color(0xDD122B2D),
                          child: Center(
                              child: ConstrainedBox(
                                  constraints:
                                      const BoxConstraints(maxWidth: 420),
                                  child: WasultPanel(
                                      child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                        const Icon(Icons.no_crash_rounded,
                                            size: 62,
                                            color: WasultColors.orange),
                                        const SizedBox(height: 12),
                                        const Text('قفل الحركة الآمن',
                                            style: TextStyle(
                                                fontSize: 24,
                                                fontWeight: FontWeight.w900)),
                                        const SizedBox(height: 8),
                                        const Text(
                                            'السرعة التجريبية 24 كم/ساعة. الكتابة ومسح QR وتعديل الحضور معطلة حتى تتوقف المركبة.',
                                            textAlign: TextAlign.center),
                                        const SizedBox(height: 18),
                                        FilledButton.icon(
                                            onPressed: () => trip('Arrived'),
                                            icon: const Icon(Icons.stop_circle),
                                            label: const Text('تأكيد التوقف'))
                                      ]))))))
              ]),
              bottomNavigationBar: wide
                  ? null
                  : NavigationBar(
                      selectedIndex: tab < 4 ? tab : 4,
                      onDestinationSelected: driverLocked
                          ? null
                          : (value) {
                              if (value == 4 && pages.length > 4) {
                                openMoreMenu();
                              } else {
                                setState(() => tab = value);
                              }
                            },
                      destinations: [
                          for (final page in pages.take(4))
                            NavigationDestination(
                                icon: Icon(page.icon), label: page.label),
                          if (pages.length > 4)
                            const NavigationDestination(
                                icon: Icon(Icons.more_horiz_rounded),
                                label: 'المزيد')
                        ]),
            );
          })));

  List<Widget> _content() => switch (widget.role) {
        'GUARDIAN' => _guardian(),
        'DRIVER' => _driver(),
        'CORPORATE_ADMIN' => _corporate(),
        'SUPER_ADMIN' => _superAdmin(),
        _ => _advertiser(),
      };

  List<Widget> _guardian() => switch (tab) {
        0 => [
            heading('رحلات العائلة في عمّان'),
            overviewMap(),
            panel(
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('حالة الرحلة: ${store.text('tripState')}',
                  style: const TextStyle(
                      fontWeight: FontWeight.w900, fontSize: 17)),
              Text(store.text('routeFrom').isEmpty
                  ? 'المسار 04 • من عبدون إلى أكاديمية عمّان'
                  : '${store.text('routeFrom')} ← ${store.text('routeTo')}'),
              const SizedBox(height: 8),
              const LinearProgressIndicator(value: .64, minHeight: 8),
              const SizedBox(height: 6),
              const Text(
                  'اضغط على أي دبوس بالخريطة لعرض معلوماته • الوصول المتوقع خلال 6 دقائق')
            ])),
            heading('طلبات الاستلام والرحلات'),
            ...tripRequestCards(forDriver: false),
            heading('الرسائل والتنبيهات'),
            ...notices('GUARDIAN').skip(1).take(3),
            heading('آخر حالات الحضور'),
            for (final event in store.rows('attendanceEvents').take(3))
              rowCard(
                  '${store.rows('children').firstWhere((child) => child['id'] == event['childId'], orElse: () => {
                        'name': 'راكب'
                      })['name']}',
                  '${event['at']} • ${event['verificationMethod']}',
                  '${event['eventType']}',
                  const []),
            heading('الركاب'),
            for (final child in store.rows('children'))
              rowCard(
                  '${child['name']}',
                  '${child['school']} • ${child['route']} • السائق: ${child['assignedDriver'] ?? 'غير معين'}\n${store.rows('serviceAssignments').where((item) => item['passengerId'] == child['id']).map((item) => '${item['segment']} ${item['role']} • ${item['status']}').join(' | ')}',
                  '${child['attendance']}', [
                action('رحلة خاصة مع سائق', Icons.person_pin_circle_outlined,
                    () => requestOneToOneTrip(child),
                    filled: true),
                action('إدارة تعيين السائق', Icons.alt_route_rounded,
                    () => requestServiceAssignment(child)),
                action('تعيين بمعرّف السائق', Icons.badge_outlined,
                    () => assignDriverByUniqueId(child)),
                action('التفاصيل', Icons.info_outline,
                    () => toast('معرّف الراكب: ${child['id']}'))
              ]),
            Wrap(children: [
              action('إضافة راكب', Icons.person_add_alt_1, addChild,
                  filled: true),
              action('تحديد من / إلى بالخريطة', Icons.pin_drop_outlined,
                  () => Navigator.pushNamed(context, '/route-location')),
              action('ربط بمعرّف السائق', Icons.link_rounded, linkDriverByCode),
              action('ربط جهاز تتبع', Icons.sensors_rounded, linkHardware)
            ]),
            if (store.text('hardwareToken').isNotEmpty)
              panel(Text(
                  'وضع التتبع المقيد نشط: ${store.text('hardwareToken')} • الرسائل والمكالمات مع السائق مخفية، وتظهر فقط بيانات الموقع والجيوفنس.',
                  style: const TextStyle(fontWeight: FontWeight.w700)))
          ],
        1 => [
            heading('ملفات الركاب',
                trailing:
                    action('إضافة راكب', Icons.add, addChild, filled: true)),
            for (final child in store.rows('children'))
              rowCard(
                  '${child['name']}',
                  '${child['school']} • ${child['route']} • ${child['id']}\nالسائق: ${child['assignedDriver'] ?? 'غير معين'}\n${store.rows('serviceAssignments').where((item) => item['passengerId'] == child['id']).map((item) => '${item['segment']} ${item['role']} • ${item['status']}').join(' | ')}',
                  '${child['status']}', [
                action('طلب تعيين سائق', Icons.person_pin_circle_outlined,
                    () => requestServiceAssignment(child),
                    filled: true),
                action('تعيين بمعرّف السائق', Icons.badge_outlined,
                    () => assignDriverByUniqueId(child)),
                action('تعديل', Icons.edit_outlined, () => editChild(child)),
                action(
                    child['status'] == 'Active' ? 'إيقاف' : 'تفعيل',
                    Icons.toggle_on_outlined,
                    () => store.edit(
                        'children',
                        '${child['id']}',
                        {
                          'status':
                              child['status'] == 'Active' ? 'Paused' : 'Active'
                        },
                        notice: 'تم تحديث ملف الراكب ${child['name']}')),
                action(
                    'غياب غداً', Icons.event_busy, () => reportAbsence(child))
              ])
          ],
        2 => [
            heading('محفظة العائلة'),
            panel(
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${store.number('walletJod').toStringAsFixed(2)} JOD',
                  style: const TextStyle(
                      fontSize: 32, fontWeight: FontWeight.w900)),
              const Text('رصيد تجريبي • لا توجد معاملة مالية حقيقية'),
              const Divider(),
              Text('${store.number('walletEgp').toStringAsFixed(2)} EGP'),
              if (store.number('walletJod') < 10)
                const Text('تنبيه: الرصيد أقل من الحد الأدنى',
                    style: TextStyle(color: WasultColors.danger))
            ])),
            Wrap(children: [
              action('إضافة رصيد تجريبي', Icons.add_card, topUp, filled: true),
              action('خصم رحلة تجريبية', Icons.directions_bus, debit)
            ]),
            heading('السجل'),
            for (final row in store.rows('ledger'))
              rowCard('${row['text']}', '${row['at']} • ${row['currency']}',
                  '${row['amount']}', [])
          ],
        3 => notices('GUARDIAN'),
        4 => [
            heading('الإعدادات والتواصل'),
            panel(const Text(
                'الموقع الافتراضي: عمّان، الأردن\nالتنبيهات: عند اقتراب المركبة مسافة 1 كم')),
            panel(const Text(
                'خصوصية الإعلانات: لا تُستخدم بيانات الركاب أو الحضور أو الرسائل أو الموقع الدقيق للاستهداف. لا تظهر الإعلانات داخل الخريطة الحية، ETA، الحضور، الدفع، الحضانة، أو تنبيهات السلامة.')),
            Wrap(children: [
              action('تغيير نقاط الرحلة', Icons.map,
                  () => Navigator.pushNamed(context, '/route-location')),
              action('رمز الحضور QR', Icons.qr_code_2,
                  () => Navigator.pushNamed(context, '/guardian-qr')),
              action('إبلاغ عن إعلان', Icons.report_problem_outlined,
                  reportAdCompliance),
              if (store.text('hardwareToken').isEmpty)
                action(
                    'إرسال رسالة للسائق', Icons.chat, () => compose('DRIVER'))
              else
                action(
                    'إلغاء ربط الجهاز',
                    Icons.link_off,
                    () => store.setValue('hardwareToken', '',
                        notice: 'تم إلغاء ربط جهاز التتبع'))
            ])
          ],
        _ => const [],
      };

  List<Widget> _driver() => switch (tab) {
        0 => [
            heading('رحلة عمّان 04'),
            overviewMap(),
            panel(
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('الحالة: ${store.text('tripState')}',
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.w900)),
              const Text('AM 55421 • أحمد الخطيب • 9 ركاب'),
              const SizedBox(height: 8),
              if (store.text('tripState') == 'Moving')
                const Text(
                    'قفل الحركة نشط: الكتابة وتعديل السجل معطلان فوق 5 كم/ساعة.',
                    style: TextStyle(
                        color: WasultColors.danger,
                        fontWeight: FontWeight.w700))
            ])),
            panel(
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('معرّف السائق ومشاركة الربط',
                  style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
              const SizedBox(height: 6),
              const SelectableText('Driver Unique ID: DRV-101',
                  textDirection: TextDirection.ltr,
                  style: TextStyle(fontWeight: FontWeight.w800)),
              const SelectableText('Pairing code: WASULT-DRV-101',
                  textDirection: TextDirection.ltr),
              const SizedBox(height: 6),
              const Text(
                  'شارك المعرّف مع ولي الأمر. لا تتم إضافة راكب إلى بيان الرحلة قبل قبول التعيين.'),
            ])),
            Wrap(children: [
              action('بدء المسار', Icons.play_arrow, () => trip('Moving'),
                  filled: true),
              action('وصلت', Icons.flag, () => trip('Arrived')),
              action('إنهاء الرحلة', Icons.stop, () => trip('Completed')),
              action(
                  'ازدحام', Icons.traffic, () => alert('Heavy Traffic delay')),
              action(
                  'عطل مركبة',
                  Icons.car_repair,
                  () => alert('CAR/Bus is out of service',
                      severity: 'emergency')),
              action('SOS', Icons.sos,
                  () => alert('Emergency SOS', severity: 'critical')),
              if (store.text('tripState') != 'Moving')
                action('إبلاغ عن إعلان', Icons.report_problem_outlined,
                    reportAdCompliance)
            ]),
            panel(const Text(
                'أمان العرض: لا تظهر مواد إعلانية أثناء الرحلة أو مع قفل الحركة أو على شاشة SOS. بطاقات السائق المسموحة تعمل فقط قبل/بعد المسار أو عند سرعة مؤكدة أقل من 5 كم/ساعة.'))
          ],
        1 => [
            heading('دليل الركاب النشطين'),
            panel(const Text(
                'لا يشارك الرمز أي كشف أسماء أو مسارات. أنشئ رمز ربط مؤقتاً فقط بعد التحقق من ولي الأمر، ثم يستطيع ولي الأمر ربط الراكب بحساب السائق.')),
            heading('طلبات تعيين الخدمة'),
            for (final assignment in store.rows('serviceAssignments').where(
                (item) =>
                    item['driverId'] == 'DRV-101' &&
                    item['status'] == 'Pending'))
              rowCard(
                  '${store.rows('children').firstWhere((child) => child['id'] == assignment['passengerId'], orElse: () => {
                        'name': 'راكب'
                      })['name']}',
                  '${assignment['segment']} • ${assignment['role']} • من ${assignment['effectiveFrom']} إلى ${assignment['effectiveTo']}',
                  'بانتظار قرارك',
                  [
                    action('قبول', Icons.check_circle_outline,
                        () => decideServiceAssignment(assignment, true),
                        filled: true),
                    action('رفض', Icons.cancel_outlined,
                        () => decideServiceAssignment(assignment, false))
                  ]),
            for (final child in store
                .rows('children')
                .where((item) => item['assignedDriver'] == 'DRV-101'))
              rowCard(
                  '${child['name']}',
                  '${child['school']} • ${child['route']}\n${child['pickupAddress'] ?? 'عنوان استلام غير مؤكد'}',
                  '${child['attendance']}', [
                action(
                    child['attendance'] == 'Boarded'
                        ? 'تأكيد النزول'
                        : 'تأكيد الصعود',
                    Icons.fact_check,
                    () => attendance(child))
              ]),
            Wrap(children: [
              action('رمز مشاركة القائمة', Icons.share, generateRosterShareCode,
                  filled: true),
              action('مسح QR', Icons.qr_code_scanner,
                  () => Navigator.pushNamed(context, '/driver-scan'))
            ])
          ],
        2 => [
            heading('طلبات الاستلام بانتظار قرار السائق'),
            ...tripRequestCards(forDriver: true),
            ...notices('DRIVER',
                composeEnabled: store.text('tripState') != 'Moving')
          ],
        _ => [
            heading('الملف وتقرير الوردية'),
            for (final driver
                in store.rows('drivers').where((d) => d['id'] == 'DRV-101'))
              rowCard(
                  '${driver['name']}',
                  '${driver['plate']} • ${driver['phone']} • سعة ${driver['capacity']}',
                  '${driver['status']}',
                  [action('تعديل', Icons.edit, () => editDriver(driver))]),
            panel(const Text(
                'المستندات: رخصة القيادة والهوية بانتظار التحقق الفعلي من الخادم.')),
            action('حفظ تقرير الوردية', Icons.assignment_turned_in,
                submitShiftReport,
                filled: true)
          ],
      };

  List<Widget> _corporate() => switch (tab) {
        0 => [
            heading(
                '${corporateBrand['name'] ?? 'شركة عمّان للنقل'} • الأسطول'),
            overviewMap(),
            metrics([
              (
                'السائقون',
                '${store.rows('drivers').length}',
                Icons.directions_bus
              ),
              ('المركبات المباشرة', '2', Icons.sensors),
              ('الركاب', '${store.rows('children').length}', Icons.groups),
              (
                'طلبات الموافقة',
                '${store.rows('drivers').where((d) => d['status'] == 'Pending').length}',
                Icons.pending_actions
              ),
              (
                'تعيينات بانتظار القرار',
                '${store.rows('serviceAssignments').where((item) => item['status'] == 'Pending').length}',
                Icons.assignment_late_outlined
              )
            ]),
            panel(const Text(
                'مركز التشغيل: تعرض الخريطة آخر موقع موثوق فقط. تُراجع إشارات السرعة والانحراف والنبض قبل اتخاذ إجراء. أجهزة GPS تدعم التتبع والجيوفنس ولا تحل محل السائق البشري أو إجراءات الحضور/التسليم.')),
            panel(
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('سلامة المواضع الإعلانية',
                  style: TextStyle(fontWeight: FontWeight.w900)),
              const Text(
                  'يمكن للشركة الإبلاغ عن محتوى أو موضع غير مناسب دون الوصول إلى بيانات المعلن أو بيانات الركاب.'),
              action('إبلاغ عن إعلان', Icons.report_problem_outlined,
                  reportAdCompliance)
            ])),
            heading('آخر التنبيهات'),
            ...notices('CORPORATE_ADMIN').take(3),
            heading('مراجعة تعيينات الخدمة'),
            if (store.rows('serviceAssignments').isEmpty)
              panel(const Text('لا توجد تعيينات خدمة في بيانات العرض.'))
            else
              for (final assignment in store.rows('serviceAssignments').take(5))
                rowCard(
                    '${store.rows('children').firstWhere((child) => child['id'] == assignment['passengerId'], orElse: () => {
                          'name': 'راكب'
                        })['name']}',
                    '${assignment['segment']} • ${assignment['role']} • ${assignment['driverId']}\n${assignment['effectiveFrom']} إلى ${assignment['effectiveTo']}',
                    '${assignment['status']}',
                    [
                      if (assignment['role'] == 'SUBSTITUTE' &&
                          assignment['status'] == 'Active')
                        action('تفعيل بديل محدد', Icons.swap_horiz_rounded,
                            () => activateSubstitute(assignment),
                            filled: true)
                    ]),
            heading('البدلاء المفعلون'),
            if (store
                .rows('substituteActivations')
                .where((item) => item['status'] == 'Active')
                .isEmpty)
              panel(const Text('لا يوجد بديل مفعل في بيانات العرض.'))
            else
              for (final activation in store
                  .rows('substituteActivations')
                  .where((item) => item['status'] == 'Active'))
                rowCard(
                    '${activation['driverId']} • ${activation['passengerId']}',
                    '${activation['serviceDate']} • ${activation['segment']}\n${activation['reason']}',
                    '${activation['status']}', [
                  action('إنهاء التفعيل', Icons.stop_circle_outlined,
                      () => endSubstitute(activation))
                ]),
            heading('غيابات الركاب المسجلة'),
            if (store.rows('absenceReports').isEmpty)
              panel(const Text(
                  'لا توجد غيابات مسجلة في بيانات العرض. في الإنتاج تعرض القائمة المؤسسة والحقول التشغيلية فقط.'))
            else
              for (final absence in store.rows('absenceReports').take(5))
                rowCard(
                    '${store.rows('children').firstWhere((child) => child['id'] == absence['childId'], orElse: () => {
                          'name': 'راكب'
                        })['name']}',
                    '${absence['serviceDate']} • ${absence['tripSegment']}',
                    '${absence['status']}',
                    const [])
          ],
        1 => [
            heading('إدارة السائقين والمركبات',
                trailing:
                    action('إضافة سائق', Icons.add, addDriver, filled: true)),
            panel(
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('تنبيهات الامتثال',
                  style: TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 4),
              Text(
                  '${store.rows('drivers').where((driver) => driver['documentStatus'] != 'Approved').length} سائق/مركبة بحاجة إلى اعتماد مستندات أو مراجعة انتهاء الصلاحية.'),
              const Text(
                  'في الإنتاج تُحمّل هذه القائمة من تقرير الامتثال المقيد بالمؤسسة؛ لا تعتمد على بيانات شاشة محلية.',
                  style: TextStyle(color: WasultColors.muted))
            ])),
            for (final driver in store.rows('drivers'))
              rowCard(
                  '${driver['name']}',
                  '${driver['plate']} • ${driver['route']} • ${driver['phone']}\nالمستندات: ${driver['documentStatus'] ?? 'Pending'} • انتهاء: ${driver['documentExpiry'] ?? '—'}',
                  '${driver['status']}', [
                action('تعديل', Icons.edit, () => editDriver(driver)),
                action(
                    driver['status'] == 'Active' ? 'تعليق' : 'تفعيل',
                    Icons.toggle_on,
                    () => store.edit(
                        'drivers',
                        '${driver['id']}',
                        {
                          'status': driver['status'] == 'Active'
                              ? 'Suspended'
                              : 'Active'
                        },
                        notice: 'تم تحديث حالة السائق ${driver['name']}')),
                action(
                    'إعادة رمز الدخول',
                    Icons.lock_reset,
                    () => store.announce(
                        'طلب إعادة رمز السائق ${driver['id']} قيد المعالجة',
                        audience: 'DRIVER')),
                if (driver['documentStatus'] != 'Approved')
                  action(
                      'اعتماد المستندات',
                      Icons.verified_user_outlined,
                      () => store.edit(
                          'drivers',
                          '${driver['id']}',
                          {
                            'documentStatus': 'Approved',
                            'status': 'Active',
                            'documentExpiry': '2027-12-31'
                          },
                          notice: 'تم اعتماد مستندات السائق ${driver['name']}'))
              ])
          ],
        2 => hardware(),
        3 => [
            heading('الاشتراك والرخص'),
            panel(Text(
                'Business Plus • ${store.rows('drivers').length} من 25 رخصة مستخدمة\nالرصيد التجريبي للشركة: 240 JOD')),
            action('طلب زيادة الرخص', Icons.add_card, requestLicenseCapacity,
                filled: true),
            heading('سجل الطلبات'),
            ...notices('CORPORATE_ADMIN')
          ],
        4 => notices('CORPORATE_ADMIN', composeEnabled: true),
        _ => corporateBranding(),
      };

  List<Widget> corporateBranding() => [
        heading('هوية الشركة البيضاء',
            trailing: action(
                'تعديل الهوية', Icons.edit_outlined, editCorporateBrand,
                filled: true)),
        panel(Row(children: [
          corporateLogo(size: 84),
          const SizedBox(width: 18),
          Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Text('${corporateBrand['name'] ?? 'شركة عمّان للنقل'}',
                    style: const TextStyle(
                        fontSize: 20, fontWeight: FontWeight.w900)),
                Text(
                    'اللون المميز: ${corporateBrand['accentColor'] ?? '#005B60'}'),
                Text('معرّف الحساب: ${corporateBrand['tenantId'] ?? 'TEN-01'}')
              ]))
        ])),
        heading('شعار حساب الشركة'),
        if ('${corporateBrand['logoData'] ?? ''}'.isNotEmpty)
          panel(imagePreview('${corporateBrand['logoData']}'))
        else
          panel(const Text(
              'لم يتم رفع شعار بعد. يظهر رمز حساب آمن مؤقت إلى أن تعتمد المؤسسة شعارها.')),
        Wrap(children: [
          action('رفع أو تغيير الشعار', Icons.upload_file_rounded,
              uploadCorporateLogo,
              filled: true),
          action('إزالة الشعار المرفوع', Icons.delete_outline, () {
            store.setValue(
                'corporateBrand', {...corporateBrand, 'logoData': ''},
                notice: 'تمت إزالة شعار الشركة المرفوع؛ سيبقى الرمز الافتراضي');
          })
        ]),
        panel(const Text(
            'يسمح في وضع العرض بملفات PNG/JPG/JPEG/WebP حتى 512 كيلوبايت للمعاينة المحلية. في الإنتاج تُفحص الملفات، تحفظ في مخزن خاص، تُراجع قبل النشر، وتُستخدم روابط موقعة بدلاً من تخزين الصورة داخل إعدادات العميل.')),
        heading('حدود العلامة البيضاء'),
        panel(const Text(
            'تخصيص الاسم، الشعار، اللون، وتذييل الفاتورة خاص بالمؤسسة. لا يمكن للشعار أو اللون إخفاء هوية Wasult، تغيير رموز السلامة، أو تعديل حالات الطوارئ والاتصال والامتثال.'))
      ];

  List<Widget> _superAdmin() => switch (tab) {
        0 => [
            heading('مراقبة المنصة'),
            overviewMap(),
            metrics([
              ('المؤسسات', '${store.rows('tenants').length}', Icons.apartment),
              (
                'السائقون',
                '${store.rows('drivers').length}',
                Icons.directions_bus
              ),
              ('أجهزة GPS', '${store.rows('devices').length}', Icons.sensors),
              ('الحملات', '${store.rows('campaigns').length}', Icons.campaign)
            ]),
            heading('سلامة وتشغيل لحظي'),
            metrics([
              (
                'حالات طوارئ مفتوحة',
                '${store.rows('incidents').where((item) => item['severity'] == 'Critical' || item['severity'] == 'High').length}',
                Icons.sos_rounded
              ),
              (
                'مركبات خارج الاتصال',
                '${store.rows('fleetAlerts').where((item) => item['type'] == 'OFFLINE_OUTSIDE_TOLERANCE').length}',
                Icons.signal_wifi_off_rounded
              ),
              (
                'تسليمات بانتظار تحقق',
                '${store.rows('fleetAlerts').where((item) => item['type'] == 'CUSTODY_PENDING').length}',
                Icons.verified_user_outlined
              ),
              (
                'إنذارات مسار/سرعة',
                '${store.rows('fleetAlerts').where((item) => item['type'] == 'OFF_ROUTE' || item['type'] == 'DRIVING_RISK').length}',
                Icons.warning_amber_rounded
              )
            ]),
            panel(const Text(
                'مؤشرات المخاطر لا تعني إثبات مخالفة. تُراجع مع الدقة والسياق ودليل الرحلة قبل أي إجراء تأديبي أو مالي.')),
            heading('حوكمة تعيينات الخدمة'),
            metrics([
              (
                'طلبات بانتظار السائق',
                '${store.rows('serviceAssignments').where((item) => item['status'] == 'Pending').length}',
                Icons.pending_actions_outlined
              ),
              (
                'بدلاء مفعلون اليوم',
                '${store.rows('substituteActivations').where((item) => item['status'] == 'Active').length}',
                Icons.swap_horiz_rounded
              )
            ]),
            panel(const Text(
                'يعرض هذا الملخص بيانات تشغيلية دنيا فقط. لا يستطيع مدير النظام الاطلاع على عناوين الاستلام أو أرقام الاتصال أو محادثات ولي الأمر من شاشة الحوكمة.')),
            for (final activation
                in store.rows('substituteActivations').take(5))
              rowCard(
                  'بديل: ${activation['driverId']} • راكب ${activation['passengerId']}',
                  '${activation['serviceDate']} • ${activation['segment']}\n${activation['reason']}',
                  '${activation['status']}', const []),
            heading('مراجعة ترحيل الروابط القديمة'),
            panel(Text(
                '${store.rows('children').where((child) => !store.rows('serviceAssignments').any((assignment) => assignment['passengerId'] == child['id'])).length} روابط قديمة تحتاج مراجعة في بيانات العرض. هذا التقرير للقراءة فقط ولا ينشئ أو يعدل تعيينات.')),
            heading('التنبيهات'),
            ...notices('SUPER_ADMIN').take(3)
          ],
        1 => [
            heading('المؤسسات',
                trailing: action('إضافة', Icons.add, addTenant, filled: true)),
            for (final tenant in store.rows('tenants'))
              rowCard(
                  '${tenant['name']}',
                  '${tenant['tier']} • ${tenant['licenses']} رخصة • ${tenant['city'] ?? '—'}',
                  '${tenant['status']}', [
                action('تعديل', Icons.edit, () => editTenant(tenant)),
                action(
                    'بيانات الاتصال',
                    Icons.contact_page_outlined,
                    () => toast(
                        '${tenant['contactPerson'] ?? '—'} • ${tenant['mobile'] ?? '—'} • ${tenant['addressLine1'] ?? '—'}')),
                action(
                    tenant['status'] == 'Active' ? 'تعليق' : 'تفعيل',
                    Icons.toggle_on,
                    () => store.edit(
                        'tenants',
                        '${tenant['id']}',
                        {
                          'status': tenant['status'] == 'Active'
                              ? 'Suspended'
                              : 'Active'
                        },
                        notice: 'تم تحديث حالة المؤسسة ${tenant['name']}'))
              ]),
            heading('سائقو المؤسسات: عرض وتدقيق'),
            for (final driver in store.rows('drivers'))
              rowCard(
                  '${driver['name']}',
                  '${driver['id']} • ${driver['route']} • ${driver['plate']}',
                  '${driver['status']}', [
                action(
                    'عرض التدقيق',
                    Icons.fact_check_outlined,
                    () => toast(
                        'سجل التدقيق التجريبي للسائق ${driver['id']} جاهز للمراجعة')),
                action(
                    'تعطيل قسري',
                    Icons.person_off_outlined,
                    () => store.edit(
                        'drivers', '${driver['id']}', {'status': 'Suspended'},
                        notice:
                            'تم تعطيل السائق ${driver['name']} قسرياً بواسطة الإدارة العليا')),
                action(
                    'تنبيه المؤسسة',
                    Icons.notification_important_outlined,
                    () => store.announce(
                        'تنبيه إداري: راجع حالة السائق ${driver['name']} (${driver['id']})',
                        audience: 'CORPORATE_ADMIN')),
                if ('${driver['shareCode']}'.startsWith('WRL-'))
                  action(
                      'إبطال رمز الربط',
                      Icons.link_off_outlined,
                      () => store.edit('drivers', '${driver['id']}',
                          {'shareCode': '', 'shareCodeExpiresAt': ''},
                          notice:
                              'أُبطل رمز ربط السائق ${driver['name']} بواسطة الإدارة العليا'))
              ])
          ],
        2 => [
            heading('مصفوفة قواعد المخاطر والفوترة',
                trailing:
                    action('قاعدة جديدة', Icons.add, addRule, filled: true)),
            for (final rule in store.rows('rules'))
              rowCard(
                  '${rule['name']}',
                  '${rule['amount']} JOD • ${rule['id']}',
                  '${rule['status']}', [
                action('تعديل', Icons.edit, () => editRule(rule)),
                action(
                    rule['status'] == 'Active' ? 'إيقاف' : 'تفعيل',
                    Icons.toggle_on,
                    () => store.edit(
                        'rules',
                        '${rule['id']}',
                        {
                          'status':
                              rule['status'] == 'Active' ? 'Paused' : 'Active'
                        },
                        notice: 'تم تغيير قاعدة ${rule['name']}'))
              ]),
            heading('أجهزة التتبع'),
            ...hardware()
          ],
        3 => [
            heading('الهوية البصرية وإعدادات الإعلانات'),
            panel(Text('اللون الرئيسي الحالي: ${store.text('brandColor')}')),
            action('تغيير اللون', Icons.palette, changeBrand, filled: true),
            panel(
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('سعر الإعلان اليومي',
                  style: TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              Text(
                  '${store.number('dailyAdRate').toStringAsFixed(2)} JOD / يوم'),
              action('تعديل السعر اليومي', Icons.price_change_outlined,
                  changeDailyAdRate,
                  filled: true)
            ])),
            heading('بطاقات الأسعار',
                trailing: action(
                    'بطاقة سعر جديدة', Icons.add_chart, addAdRateCard,
                    filled: true)),
            for (final rateCard in store.rows('adRateCards'))
              rowCard(
                  '${rateCard['surface']} • ${rateCard['model']}',
                  '${rateCard['city']} • ${rateCard['rate']}',
                  '${rateCard['status']}', [
                action(
                    'إيقاف/تفعيل',
                    Icons.price_change_outlined,
                    () => store.edit(
                        'adRateCards',
                        '${rateCard['id']}',
                        {
                          'status': rateCard['status'] == 'Active'
                              ? 'Disabled'
                              : 'Active'
                        },
                        notice: 'تم تحديث بطاقة السعر ${rateCard['id']}'))
              ]),
            panel(Text(
                'مواضع متاحة: ${(store.data['adSlots'] as List).join(' • ')}\nالمدن المتاحة: ${(store.data['adCities'] as List).join(' • ')}')),
            panel(
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('مفتاح إيقاف عرض الإعلانات العام',
                  style: const TextStyle(fontWeight: FontWeight.w900)),
              Text(store.data['adServingEnabled'] != false
                  ? 'مفعّل: لا تزال قواعد السلامة والسرعة والمحتوى سارية.'
                  : 'متوقف: لا يتم اختيار إعلان أو قبول قياس جديد حتى إعادة التفعيل.'),
              action(
                  store.data['adServingEnabled'] != false
                      ? 'إيقاف العرض عالمياً'
                      : 'إعادة تفعيل العرض',
                  store.data['adServingEnabled'] != false
                      ? Icons.pause_circle_filled
                      : Icons.play_circle_fill,
                  () => store.setValue('adServingEnabled',
                      store.data['adServingEnabled'] == false,
                      notice: store.data['adServingEnabled'] == false
                          ? 'تمت إعادة تفعيل العرض التجريبي بعد مراجعة السلامة'
                          : 'تم إيقاف عرض الإعلانات التجريبي عالمياً لأسباب سلامة'))
            ])),
            panel(const Text(
                'معاينة الشعار والبنرات متاحة كبيانات تجريبية؛ نشر CDN الفعلي يتطلب خدمة الأصول وموافقة نشر.'))
          ],
        4 => [
            heading('الحملات: مباشرة ومجدولة'),
            for (final campaign in store.rows('campaigns'))
              panel(Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('${campaign['name']} • ${campaign['status']}',
                        style: const TextStyle(fontWeight: FontWeight.w900)),
                    Text(
                        '${campaign['slot']} • ${campaign['district']} • ${campaign['start']} → ${campaign['end']}'),
                    if ('${campaign['imageUrl'] ?? ''}'.isNotEmpty)
                      Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: imagePreview('${campaign['imageUrl']}'))
                    else
                      const Padding(
                        padding: EdgeInsets.only(top: 10),
                        child: SizedBox(
                            height: 74,
                            child: Center(
                                child: Icon(Icons.image_outlined, size: 38))),
                      ),
                    Wrap(children: [
                      if (campaign['status'] == 'Pending review')
                        action(
                            'اعتماد',
                            Icons.verified,
                            () => store.edit('campaigns', '${campaign['id']}',
                                {'status': 'Live'},
                                notice: 'تم اعتماد حملة ${campaign['name']}')),
                      action(
                          'معاينة موضع الإعلان',
                          Icons.preview_outlined,
                          () => toast(
                              'معاينة ${campaign['slot']} في ${campaign['district']}'))
                    ])
                  ])),
            heading('سجل التدقيق والرسائل'),
            heading('بلاغات التزام الإعلان'),
            for (final report in store.rows('adComplianceReports'))
              rowCard(
                  '${report['campaign']} • ${report['reason']}',
                  '${report['details']}\n${report['at']}',
                  '${report['status']}', [
                if (report['status'] == 'Open')
                  action(
                      'بدء التحقيق',
                      Icons.manage_search_outlined,
                      () => store.edit('adComplianceReports', '${report['id']}',
                          {'status': 'Investigating'},
                          notice: 'تم فتح تحقيق في البلاغ ${report['id']}')),
                if (report['status'] == 'Investigating')
                  action(
                      'حل البلاغ',
                      Icons.task_alt,
                      () => store.edit('adComplianceReports', '${report['id']}',
                          {'status': 'Resolved'},
                          notice:
                              'تم إغلاق البلاغ ${report['id']} بعد المراجعة'))
              ]),
            ...notices('SUPER_ADMIN')
          ],
        5 => reports(),
        6 => [
            heading('الإعدادات العامة والخطط'),
            panel(const Text(
                'الإعدادات الحساسة لا تُخزَّن في التطبيق: أدخل مرجعاً آمناً للخزنة (Vault reference) بدلاً من أي مفتاح أو كلمة مرور. جميع التعديلات محلية في وضع العرض.')),
            heading('خطط التسجيل والأعمال',
                trailing: action('خطة جديدة', Icons.add, addSubscriptionPlan,
                    filled: true)),
            for (final plan in store.rows('subscriptionPlans'))
              rowCard(
                  '${plan['name']}',
                  '${plan['monthly']} JOD / شهر • ${plan['licenses']} رخصة',
                  '${plan['status']}', [
                action('تعديل', Icons.edit, () => editSubscriptionPlan(plan))
              ]),
            heading('إضافات النظام والمفاتيح المُدارة',
                trailing: action('إضافة إضافة', Icons.extension, addIntegration,
                    filled: true)),
            for (final integration in store.rows('systemIntegrations'))
              rowCard(
                  '${integration['name']}',
                  '${integration['category']} • ${integration['publicConfig']} • ${integration['secretRef']}',
                  '${integration['status']}', [
                action('تعديل الإعداد', Icons.edit,
                    () => editIntegration(integration)),
                action(
                    integration['status'] == 'Active' ? 'إيقاف' : 'تفعيل',
                    Icons.power_settings_new,
                    () => store.edit(
                        'systemIntegrations',
                        '${integration['id']}',
                        {
                          'status': integration['status'] == 'Active'
                              ? 'Disabled'
                              : 'Active'
                        },
                        notice: 'تم تحديث الإضافة ${integration['name']}'))
              ]),
            heading('إطلاق الميزات تدريجياً',
                trailing: action('ميزة جديدة', Icons.add, addFeatureFlag,
                    filled: true)),
            panel(const Text(
                'لا تُفعّل ميزة على كل العملاء دفعة واحدة. سجّل سبب التغيير، نسبة الإطلاق، والمؤسسات التجريبية قبل التفعيل.')),
            for (final flag in store.rows('featureFlags'))
              rowCard(
                  '${flag['name']}',
                  '${flag['key']} • ${flag['rollout']}% • المؤسسات: ${flag['tenants']}\n${flag['reason']}',
                  flag['enabled'] == true ? 'Active' : 'Disabled', [
                action('تعديل الإطلاق', Icons.tune_outlined,
                    () => editFeatureFlag(flag)),
                action(
                    flag['enabled'] == true ? 'إيقاف فوري' : 'تفعيل تدريجي',
                    Icons.power_settings_new,
                    () => store.edit(
                        'featureFlags',
                        '${flag['id']}',
                        {
                          'enabled': flag['enabled'] != true,
                          'rollout': flag['enabled'] == true ? 0 : 10
                        },
                        notice: 'تم تحديث إطلاق الميزة ${flag['name']}'))
              ]),
            heading('بوابات الدفع'),
            for (final gateway in store.rows('paymentGateways'))
              rowCard(
                  '${gateway['logo']} ${gateway['name']}',
                  '${gateway['apiUrl']} • مرجع المفتاح مُدار عبر Vault',
                  '${gateway['status']}',
                  [action('تعديل', Icons.edit, () => editGateway(gateway))]),
            heading('كتالوج مواضع الإعلان'),
            for (final slot in store.rows('adSlotCatalog'))
              rowCard(
                  '${slot['name']}',
                  '${slot['dimensions']} • ${slot['location']}\nالسعة: ${slot['capacity'] ?? 1} • حصرية الفئة: ${slot['categoryExclusive'] ?? 'No'}',
                  '${slot['safety'] ?? 'Active'}',
                  [action('تعديل', Icons.edit, () => editAdSlot(slot))]),
            heading('مستخدمو الشركات'),
            for (final user in store.rows('corporateUsers'))
              rowCard('${user['name']}', '${user['role']} • ${user['tenant']}',
                  '${user['status']}', [
                action(
                    'تعطيل',
                    Icons.person_off_outlined,
                    () => store.edit('corporateUsers', '${user['id']}',
                        {'status': 'Suspended'},
                        notice: 'تم تعطيل مستخدم الشركة ${user['name']}'))
              ]),
            Wrap(children: [
              action(
                  'إضافة مستخدم شركة', Icons.person_add_alt_1, addCorporateUser,
                  filled: true),
              action('إضافة موضع إعلان', Icons.add_location_alt_outlined,
                  addAdSlot),
              action('إضافة مدينة/منطقة', Icons.add_location_alt_outlined,
                  addAdCity),
              action('إضافة بوابة دفع', Icons.account_balance_wallet_outlined,
                  addGateway)
            ])
          ],
        7 => [
            heading('الهوية والصلاحيات',
                trailing: action(
                    'دعوة مسؤول', Icons.person_add_alt_1, addAdminAccount,
                    filled: true)),
            panel(const Text(
                'الحسابات الإدارية فردية، MFA إلزامي، وكل تعطيل أو إعادة ضبط يسجل في التدقيق.')),
            for (final admin in store.rows('adminAccounts'))
              rowCard(
                  '${admin['name']}',
                  '${admin['role']} • MFA: ${admin['mfa']}',
                  '${admin['status']}', [
                action(
                    'إعادة ضبط الجلسات',
                    Icons.restart_alt,
                    () => store.announce(
                        'تم إبطال جلسات المسؤول ${admin['id']}',
                        audience: 'SUPER_ADMIN')),
                action(
                    admin['status'] == 'Active' ? 'تعليق' : 'تفعيل',
                    Icons.person_off_outlined,
                    () => store.edit(
                        'adminAccounts',
                        '${admin['id']}',
                        {
                          'status': admin['status'] == 'Active'
                              ? 'Suspended'
                              : 'Active'
                        },
                        notice: 'تم تحديث صلاحية ${admin['name']}'))
              ])
          ],
        8 => [
            heading('المالية والتسويات'),
            panel(const Text(
                'تتطلب التسويات، الاستردادات وتغيير الأسعار موافقة مراجع ثانٍ في الإنتاج.')),
            for (final settlement in store.rows('settlements'))
              rowCard(
                  '${settlement['tenant']}',
                  '${settlement['amount']} ${settlement['currency']} • ${settlement['id']}',
                  '${settlement['status']}', [
                if (settlement['status'] == 'Pending review')
                  action(
                      'اعتماد مبدئي',
                      Icons.verified_outlined,
                      () => store.edit('settlements', '${settlement['id']}',
                          {'status': 'Approved'},
                          notice:
                              'تم اعتماد التسوية ${settlement['id']} مبدئياً')),
                action('سجل الدفعات', Icons.receipt_long_outlined,
                    () => toast('فتح سجل التسوية ${settlement['id']}'))
              ]),
            heading('طلبات سعة الرخص'),
            for (final request in store.rows('licenseRequests'))
              rowCard(
                  '${request['tenant']}',
                  '${request['licenses']} رخصة • ${request['reason']}',
                  '${request['status']}', [
                if (request['status'] == 'Pending')
                  action(
                      'اعتماد',
                      Icons.verified_outlined,
                      () => store.edit('licenseRequests', '${request['id']}',
                          {'status': 'Approved'},
                          notice:
                              'تمت الموافقة على طلب الرخص ${request['id']}')),
                if (request['status'] == 'Pending')
                  action(
                      'رفض',
                      Icons.cancel_outlined,
                      () => store.edit('licenseRequests', '${request['id']}',
                          {'status': 'Rejected'},
                          notice: 'تم رفض طلب الرخص ${request['id']}'))
              ]),
            heading('جاهزية البوابات'),
            for (final gateway in store.rows('paymentGateways'))
              rowCard('${gateway['logo']} ${gateway['name']}',
                  '${gateway['apiUrl']}', '${gateway['status']}', [
                action(
                    'اختبار Sandbox',
                    Icons.science_outlined,
                    () =>
                        toast('تمت جدولة اختبار Sandbox لـ ${gateway['name']}'))
              ])
          ],
        9 => [
            heading('الحوادث والبيانات'),
            panel(const Text(
                'الأولوية: سلامة الركاب أولاً، ثم استمرارية الخدمة والامتثال. لا تحذف سجلات الحوادث أو البيانات الخاضعة لحجز قانوني.')),
            heading('مركز الحوادث',
                trailing: action(
                    'تسجيل حادث', Icons.add_alert_outlined, addIncident,
                    filled: true)),
            for (final incident in store.rows('incidents'))
              rowCard(
                  '${incident['title']}',
                  '${incident['severity']} • المالك: ${incident['owner']}',
                  '${incident['status']}', [
                action(
                    'تصعيد',
                    Icons.priority_high,
                    () => store.edit('incidents', '${incident['id']}',
                        {'status': 'Investigating', 'severity': 'High'},
                        notice: 'تم تصعيد الحادث ${incident['id']}')),
                action(
                    'إغلاق مع الدليل',
                    Icons.task_alt,
                    () => store.edit('incidents', '${incident['id']}',
                        {'status': 'Resolved'},
                        notice: 'تمت معالجة الحادث ${incident['id']}'))
              ]),
            heading('سياسات الاحتفاظ والخصوصية',
                trailing: action('سياسة جديدة', Icons.add, addRetentionPolicy,
                    filled: true)),
            for (final policy in store.rows('retentionPolicies'))
              rowCard('${policy['name']}', 'الاحتفاظ: ${policy['period']}',
                  '${policy['status']}', [
                action(
                    'مراجعة السياسة',
                    Icons.policy_outlined,
                    () => toast(
                        'تتطلب تغييرات الاحتفاظ موافقة قانونية وسجل تدقيق')),
                action(
                    policy['status'] == 'Active' ? 'تعطيل' : 'تفعيل',
                    Icons.toggle_on_outlined,
                    () => store.edit(
                        'retentionPolicies',
                        '${policy['id']}',
                        {
                          'status': policy['status'] == 'Active'
                              ? 'Disabled'
                              : 'Active'
                        },
                        notice: 'تم تحديث سياسة الاحتفاظ ${policy['name']}'))
              ]),
            Wrap(children: [
              action(
                  'طلب تصدير بيانات',
                  Icons.download_for_offline_outlined,
                  () => store.announce(
                      'تم إنشاء طلب تصدير بيانات بانتظار المراجعة',
                      audience: 'SUPER_ADMIN'),
                  filled: true),
              action('تسجيل حجز قانوني', Icons.gavel_outlined,
                  () => toast('الحجز القانوني يمنع الحذف حتى رفعه رسمياً'))
            ])
          ],
        10 => [
            heading('مركز السلامة والاستمرارية',
                trailing: action('تمرين طوارئ', Icons.play_circle_outline,
                    () => startEmergencyDrill(),
                    filled: true)),
            panel(const Text(
                'تجمع هذه الشاشة إنذارات الطوارئ، الاتصال، الحضانة، والانحراف. لا تُغلق حادثة أو تُرسل ادعاء سلامة دون إثبات تشغيلي.')),
            heading('إنذارات الأسطول الحية'),
            for (final alertItem in store.rows('fleetAlerts'))
              rowCard(
                  '${alertItem['title']}',
                  '${alertItem['type']} • ${alertItem['vehicle']} • ${alertItem['at']}',
                  '${alertItem['status']}', [
                action('فتح الحادث', Icons.open_in_new,
                    () => linkFleetAlertToIncident(alertItem)),
                if (alertItem['status'] != 'Acknowledged')
                  action(
                      'تأكيد الاستلام',
                      Icons.mark_email_read_outlined,
                      () => store.edit('fleetAlerts', '${alertItem['id']}',
                          {'status': 'Acknowledged'},
                          notice: 'تم تأكيد استلام إنذار ${alertItem['id']}'))
              ]),
            heading('مؤشرات أنماط الخدمة'),
            for (final mode in store.rows('serviceModeMetrics'))
              rowCard(
                  '${mode['name']}',
                  '${mode['detail']} • إشغال ${mode['utilization']}%',
                  '${mode['status']}', [
                action('عرض التقرير', Icons.analytics_outlined,
                    () => previewReport('${mode['report']}'))
              ]),
            heading('جاهزية الطوارئ'),
            panel(const Text(
                'مسار العمل: ضغط SOS محمي ← تصنيف أو مهلة 10 ثوانٍ ← حادث قابل للتدقيق ← إشعار محدود الصلاحية ← متابعة الاتصال/التسليم. SMS أو قمر صناعي أو BLE ميزات اختيارية بعد اعتماد الدولة والمزوّد والجهاز.'))
          ],
        _ => [
            heading('كيانات الأسطول والإعلان'),
            panel(const Text(
                'كل كيان تشغيلي مرتبط بمؤسسة واحدة. أجهزة GPS لا تكتسب صلاحيات سائق بشري؛ وتبقى الإعلانات مفصولة عن بيانات الركاب والمسارات الدقيقة.')),
            heading('دليل السائقين وأجهزة التتبع'),
            for (final entity in store.rows('driverEntities'))
              rowCard(
                  '${entity['name']}',
                  '${entity['type']} • ${entity['tenant']} • ${entity['vehicle']}\n${entity['detail']}',
                  '${entity['status']}', [
                action(
                    'مراجعة',
                    Icons.fact_check_outlined,
                    () => toast(
                        'مراجعة الامتثال والتدقيق للكيان ${entity['id']}')),
                action(
                    entity['status'] == 'Hold' ? 'تفعيل' : 'تعليق',
                    Icons.toggle_on_outlined,
                    () => store.edit(
                        'driverEntities',
                        '${entity['id']}',
                        {
                          'status':
                              entity['status'] == 'Hold' ? 'Active' : 'Hold'
                        },
                        notice: 'تم تحديث حالة كيان الأسطول ${entity['name']}'))
              ]),
            heading('فواتير المؤسسات والاشتراكات'),
            for (final invoice in store.rows('corporateInvoices'))
              rowCard(
                  '${invoice['tenant']} • ${invoice['id']}',
                  '${invoice['description']} • ${invoice['amount']} ${invoice['currency']} • استحقاق ${invoice['dueDate']}',
                  '${invoice['status']}', [
                action('معاينة', Icons.receipt_long_outlined,
                    () => toast('معاينة فاتورة تجريبية ${invoice['id']}')),
                action(
                    'إرسال تذكير',
                    Icons.send_outlined,
                    () => store.announce(
                        'تذكير فاتورة ${invoice['id']} بانتظار إجراءات الحسابات',
                        audience: 'CORPORATE_ADMIN'))
              ]),
            heading('المعلنون ومخزون المواضع'),
            for (final advertiser in store.rows('advertisers'))
              rowCard(
                  '${advertiser['name']}',
                  '${advertiser['category']} • رصيد ${advertiser['credit']} ${advertiser['currency']} • ${advertiser['campaigns']} حملات',
                  '${advertiser['status']}', [
                action('سجل مالي', Icons.account_balance_wallet_outlined,
                    () => toast('سجل المعلن ${advertiser['id']}'))
              ]),
            panel(const Text(
                'مواضع السائق تُخدم قبل المسار أو بعده أو عند سرعة أقل من 5 كم/ساعة فقط. مواضع الطوارئ، الحضور، الدفع، الخرائط الحية، والتنبيهات محظورة إعلانياً.'))
          ],
      };

  List<Widget> reports() {
    const reports = [
      (
        'تشغيل الأسطول والمسارات',
        'الحالة الحية، الالتزام بالمواعيد، التوقفات والتأخيرات',
        Icons.route_rounded
      ),
      (
        'طلبات رحلات الركاب',
        'معلق، مؤكد، ملغى، ومعدل قراءة الإشعارات',
        Icons.groups_rounded
      ),
      (
        'الفوترة والخصومات',
        'الأرصدة، المدفوعات، الخصومات وحالة التحصيل',
        Icons.account_balance_wallet_rounded
      ),
      (
        'أداء الإعلانات والمواضع',
        'الحملات المباشرة والمجدولة، المدن والمواضع',
        Icons.campaign_rounded
      ),
      (
        'الامتثال وسجل التدقيق',
        'المستخدمون، المستندات، التغييرات والحالات الحرجة',
        Icons.fact_check_rounded
      ),
      (
        'السلامة والاستمرارية',
        'SOS، الحوادث، انقطاع الاتصال، نبضات الأسطول والتصعيد',
        Icons.health_and_safety_rounded
      ),
      (
        'الحضانة والحضور',
        'تسليم الراكب، الاستثناءات، التحقق والملفات اليومية',
        Icons.verified_user_rounded
      ),
      (
        'أنماط الخدمة والاستخدام',
        'مدرسي، موظفين، ورحلات محمية مع السعة والانتظار',
        Icons.hub_rounded
      ),
      (
        'أداء كيانات الأسطول',
        'استخدام السائقين، جاهزية أجهزة GPS، النبضات وحالة الامتثال',
        Icons.sensors_rounded
      ),
      (
        'إيرادات الإعلانات والمخزون',
        'المعلنون، الرصيد، الحملات، إشغال المواضع وسلامة مواضع السائق',
        Icons.inventory_2_outlined
      ),
    ];
    return [
      heading('التقارير الإدارية'),
      panel(const Text(
          'اختر تقريراً للمعاينة، الطباعة أو تصدير CSV. في الإنتاج تُنشأ ملفات PDF/XLSX من خدمة التقارير المحمية.')),
      for (final report in reports)
        rowCard(report.$1, report.$2, 'Ready', [
          action('معاينة', Icons.visibility_outlined,
              () => previewReport(report.$1)),
          action('طباعة', Icons.print_outlined, () => printReport(report.$1)),
          action('تصدير CSV', Icons.download_outlined,
              () => exportDemoReport(report.$1),
              filled: true)
        ])
    ];
  }

  List<(String, String)> reportRows(String report) => switch (report) {
        'تشغيل الأسطول والمسارات' => [
            (
              'السائقون النشطون',
              '${store.rows('drivers').where((item) => item['status'] == 'Active').length}'
            ),
            (
              'الأجهزة المتصلة',
              '${store.rows('devices').where((item) => item['status'] == 'Online').length}'
            ),
            (
              'المسارات المراقبة',
              '${store.rows('children').where((item) => item['status'] == 'Active').length}'
            )
          ],
        'طلبات رحلات الركاب' => [
            (
              'مؤكدة',
              '${store.rows('tripRequests').where((item) => item['status'] == 'Confirmed').length}'
            ),
            (
              'معلقة',
              '${store.rows('tripRequests').where((item) => item['status'] == 'Pending').length}'
            ),
            (
              'ملغاة',
              '${store.rows('tripRequests').where((item) => item['status'] == 'Cancelled').length}'
            )
          ],
        'الفوترة والخصومات' => [
            ('رصيد JOD', store.number('walletJod').toStringAsFixed(2)),
            (
              'قواعد الخصم',
              '${store.rows('rules').where((item) => item['status'] == 'Active').length}'
            ),
            ('إدخالات دفتر الأستاذ', '${store.rows('ledger').length}')
          ],
        'أداء الإعلانات والمواضع' => [
            (
              'حملات مباشرة',
              '${store.rows('campaigns').where((item) => item['status'] == 'Live').length}'
            ),
            (
              'حملات مجدولة/مسودة',
              '${store.rows('campaigns').where((item) => item['status'] != 'Live').length}'
            ),
            ('مواضع مفعلة', '${store.rows('adSlotCatalog').length}')
          ],
        'السلامة والاستمرارية' => [
            (
              'حوادث مفتوحة',
              '${store.rows('incidents').where((item) => item['status'] != 'Resolved').length}'
            ),
            (
              'انقطاع خارج الحدود',
              '${store.rows('fleetAlerts').where((item) => item['type'] == 'OFFLINE_OUTSIDE_TOLERANCE').length}'
            ),
            (
              'تنبيهات مؤكدة',
              '${store.rows('fleetAlerts').where((item) => item['status'] == 'Acknowledged').length}'
            )
          ],
        'الحضانة والحضور' => [
            (
              'تحقق تسليم معلق',
              '${store.rows('fleetAlerts').where((item) => item['type'] == 'CUSTODY_PENDING').length}'
            ),
            ('ركاب على البيان', '${store.rows('children').length}'),
            (
              'حضور مؤكد',
              '${store.rows('children').where((item) => item['attendance'] == 'Boarded' || item['attendance'] == 'Dropped off').length}'
            )
          ],
        'أنماط الخدمة والاستخدام' => [
            for (final mode in store.rows('serviceModeMetrics'))
              ('${mode['name']}', '${mode['utilization']}% • ${mode['status']}')
          ],
        'أداء كيانات الأسطول' => [
            (
              'سائقون بشريون',
              '${store.rows('driverEntities').where((item) => '${item['type']}'.contains('Human')).length}'
            ),
            (
              'أجهزة GPS نشطة',
              '${store.rows('driverEntities').where((item) => '${item['type']}'.contains('Hardware') && item['status'] == 'Active').length}'
            ),
            (
              'كيانات معلقة',
              '${store.rows('driverEntities').where((item) => item['status'] == 'Hold').length}'
            )
          ],
        'إيرادات الإعلانات والمخزون' => [
            (
              'معلنون نشطون',
              '${store.rows('advertisers').where((item) => item['status'] == 'Active').length}'
            ),
            (
              'حسابات على تعليق ائتماني',
              '${store.rows('advertisers').where((item) => item['status'] == 'Credit hold').length}'
            ),
            ('مواضع معلنة', '${store.rows('adSlotCatalog').length}')
          ],
        _ => [
            ('سجلات تدقيق', '${store.rows('audit').length}'),
            (
              'تنبيهات غير مقروءة',
              '${store.rows('notices').where((item) => item['read'] != true).length}'
            ),
            (
              'إضافات نشطة',
              '${store.rows('systemIntegrations').where((item) => item['status'] == 'Active').length}'
            )
          ],
      };

  Future<void> previewReport(String report) async => showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
              title: Text(report),
              content: SizedBox(
                  width: 420,
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Align(
                        alignment: Alignment.centerRight,
                        child: Text('معاينة بيانات العرض التجريبي',
                            style: TextStyle(fontWeight: FontWeight.w900))),
                    const SizedBox(height: 12),
                    for (final row in reportRows(report))
                      ListTile(
                          title: Text(row.$1),
                          trailing: Text(row.$2,
                              style:
                                  const TextStyle(fontWeight: FontWeight.w900)))
                  ])),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(dialogContext),
                    child: const Text('إغلاق'))
              ]));

  Future<void> exportDemoReport(String report) async {
    final csv = [
      'metric,value',
      ...reportRows(report).map((row) =>
          '"${row.$1.replaceAll('"', '""')}","${row.$2.replaceAll('"', '""')}"')
    ].join('\n');
    final saved = await FilePicker.platform.saveFile(
        dialogTitle: 'تصدير $report',
        fileName: 'wasult-report.csv',
        bytes: Uint8List.fromList(utf8.encode(csv)));
    if (mounted)
      toast(saved == null ? 'تم إلغاء التصدير' : 'تم تصدير تقرير CSV');
  }

  void printReport(String report) {
    previewReport(report);
    toast(
        'المعاينة جاهزة للطباعة. في الإنتاج استخدم تقرير PDF الموقّع من خدمة التقارير.');
  }

  List<Widget> _advertiser() => switch (tab) {
        0 => [
            heading('أداء الحملات في عمّان'),
            overviewMap(),
            metrics([
              ('الحملات', '${store.rows('campaigns').length}', Icons.campaign),
              (
                'مباشرة',
                '${store.rows('campaigns').where((c) => c['status'] == 'Live').length}',
                Icons.live_tv
              ),
              ('المشاهدات', '12.4K', Icons.visibility),
              ('رصيد تجريبي', '75 JOD', Icons.account_balance_wallet)
            ]),
            heading('آخر الحملات'),
            ...campaignCards(),
            heading('تنبيهات الميزانية'),
            for (final budgetAlert in store.rows('adBudgetAlerts'))
              rowCard(
                  '${budgetAlert['campaign']} • ${budgetAlert['threshold']}',
                  'إنفاق ${budgetAlert['spend']} من ${budgetAlert['budget']}',
                  '${budgetAlert['status']}', [
                action(
                    'تأكيد القراءة',
                    Icons.done_all,
                    () => store.edit('adBudgetAlerts', '${budgetAlert['id']}',
                        {'status': 'Acknowledged'},
                        notice: 'تم تأكيد قراءة تنبيه الميزانية'))
              ]),
            panel(const Text(
                'يتم عرض القياسات كمجاميع مجهولة الهوية. لا تُستخدم بيانات الركاب أو المسارات أو الحضور أو التنبيهات لقياس أو استهداف الإعلان.'))
          ],
        1 => [
            heading('إعداد الحملات',
                trailing:
                    action('حملة جديدة', Icons.add, addCampaign, filled: true)),
            ...campaignCards()
          ],
        2 => [
            heading('مكتبة الأصول'),
            panel(const Text(
                'اختر صورة من جهازك أو أدخل رابط صورة، ثم عاينها قبل إرسال الحملة. عند عدم وجود حملة مباشرة يظهر أصل عام بدلاً من إعلان.')),
            for (final campaign in store.rows('campaigns'))
              panel(Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('${campaign['asset']}',
                        style: const TextStyle(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 8),
                    if ('${campaign['imageUrl'] ?? ''}'.isNotEmpty)
                      imagePreview('${campaign['imageUrl']}'),
                    const SizedBox(height: 8),
                    Text('${campaign['slot']} • ${campaign['district']}'),
                    Wrap(children: [
                      action('تغيير/رفع الصورة', Icons.upload_file_outlined,
                          () => editCampaign(campaign))
                    ])
                  ]))
          ],
        3 => [
            heading('مخزون المواضع والجدولة'),
            panel(const Text(
                'المواضع المتاحة تظهر فقط بعد اجتياز سعة الجدول وسياسة السلامة. لا توجد مواضع ضمن خريطة حية أو ETA أو حضور أو طوارئ.')),
            for (final slot in store.rows('adSlotCatalog'))
              rowCard(
                  '${slot['name']}',
                  '${slot['dimensions']} • ${slot['location']}',
                  '${slot['safety'] ?? 'Approved'}', [
                action('معاينة الإطار', Icons.preview_outlined,
                    () => toast('معاينة موضع ${slot['name']} في إطار آمن'))
              ]),
            panel(const Text(
                'مواضع السائق محجوبة تلقائياً عند الحركة أو عند عدم موثوقية القياس. يطبق محرك الخادم التحقق قبل كل عرض.'))
          ],
        4 => [
            heading('مركز الفواتير'),
            panel(const Text(
                'إتمام الدفع في هذا العرض محاكاة فقط؛ لا يتم استدعاء Stripe أو خصم أي بطاقة.')),
            for (final campaign in store.rows('campaigns'))
              rowCard(
                  '${campaign['name']}',
                  '${campaign['budget']} JOD • ${campaign['start']} → ${campaign['end']}',
                  '${campaign['status']}', [
                action('محاكاة الدفع والإرسال للمراجعة', Icons.payment,
                    () => checkout(campaign))
              ])
          ],
        5 => advertiserReports(),
        6 => [
            heading('إعدادات بوابة الإعلان'),
            panel(const Text(
                'المظهر: فاتح / داكن / نظام • اللغة: العربية RTL أو English LTR • المنطقة الزمنية والحسابات المالية تُعرض صراحة ولا تتحول ضمنياً.')),
            panel(const Text(
                'الحساب التجريبي: حالة الائتمان والبوابات والسجل المالي تُدار من الخادم. لا تدخل مفاتيح الدفع أو بيانات البطاقات في هذا التطبيق.'))
          ],
        _ => [
            ...notices('ADVERTISER', composeEnabled: true),
            heading('نتائج بلاغات الالتزام'),
            for (final report in store.rows('adComplianceReports'))
              rowCard('${report['campaign']} • ${report['reason']}',
                  '${report['at']}', '${report['status']}', [])
          ],
      };

  List<Widget> advertiserReports() {
    const items = [
      ('أداء الحملة', 'المشاهدات الصحيحة، النقرات، CTR، وتقدم الإنفاق'),
      ('كشف حساب المعلن', 'الفواتير، المدفوعات، الرصيد، والائتمان'),
      ('إشغال المخزون', 'المواضع المباعة والمتاحة وسعة الجدولة'),
      ('تحليل المدينة والفترة', 'مدينة مجمعة وفترات مسموحة دون بيانات فردية'),
      ('الامتثال والمراجعة', 'حالة الأصل، الرفض، واعتراضات السلامة')
    ];
    return [
      heading('تقارير الإعلان والتحليلات'),
      panel(const Text(
          'مرشحات الإنتاج: الفترة، المعلن، الحالة، التطبيق، الموضع، المدينة الإجمالية، والحالة المالية. يتم إنشاء PDF/XLSX/CSV كوظيفة تقرير مُدققة.')),
      for (final item in items)
        rowCard(item.$1, item.$2, 'Ready', [
          action('معاينة', Icons.visibility_outlined,
              () => toast('معاينة تقرير ${item.$1} التجريبية')),
          action('تصدير', Icons.download_outlined,
              () => toast('تمت جدولة تصدير ${item.$1} التجريبي'))
        ])
    ];
  }

  Widget metrics(List<(String, String, IconData)> items) => LayoutBuilder(
      builder: (context, size) => GridView.count(
            crossAxisCount: size.maxWidth > 600 ? 4 : 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: size.maxWidth > 600 ? 1.7 : 1.45,
            children: [
              for (final item in items)
                WasultPanel(
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                      Icon(item.$3, color: WasultColors.teal),
                      const Spacer(),
                      Text(item.$2,
                          style: const TextStyle(
                              fontSize: 25, fontWeight: FontWeight.w900)),
                      Text(item.$1,
                          style: const TextStyle(color: WasultColors.muted))
                    ]))
            ],
          ));

  List<Widget> notices(String audience, {bool composeEnabled = false}) => [
        heading('مركز الرسائل والتنبيهات',
            trailing: composeEnabled
                ? action(
                    'رسالة جديدة', Icons.edit, () => compose('SUPER_ADMIN'),
                    filled: true)
                : null),
        if (!AppConfig.mockMode && loadingInbox)
          const Center(
              child: Padding(
                  padding: EdgeInsets.all(24),
                  child: CircularProgressIndicator()))
        else if (!AppConfig.mockMode)
          for (final message in inboxMessages)
            rowCard(
                message.body,
                '${message.createdAt.toLocal()} • ${message.senderRole} / ${message.senderId}',
                message.readAt == null ? 'New' : 'Read', [
              if (message.readAt == null)
                action('تأكيد القراءة', Icons.mark_email_read, () async {
                  if (await const OperationalMessageClient()
                      .confirmRead(message.id)) _loadInbox();
                }),
              action('مسح من قائمتي', Icons.clear_rounded, () async {
                if (await const OperationalMessageClient()
                    .clearFromInbox(message.id)) _loadInbox();
              })
            ])
        else
          for (final notice in store.rows('notices').where((n) =>
              n['audience'] == audience ||
              (audience == 'SUPER_ADMIN' && n['audience'] == 'SYSTEM')))
            rowCard(
                '${notice['text']}',
                '${notice['at']} • ${notice['audience']}',
                notice['read'] == true ? 'Read' : 'New', [
              action('تشغيل التنبيه', Icons.volume_up_outlined,
                  () => alertAudio.play('${notice['severity'] ?? 'alert'}')),
              if (notice['read'] != true)
                action('تأكيد القراءة', Icons.mark_email_read,
                    () => store.markRead('${notice['id']}'))
            ]),
      ];

  List<Widget> hardware() => [
        heading('تخصيص أجهزة GPS',
            trailing: action('تخصيص جهاز', Icons.add, provisionHardware,
                filled: true)),
        for (final device in store.rows('devices'))
          rowCard(
              '${device['name']}',
              '${device['imei']} • ${device['route']} • ${device['token']}',
              '${device['status']}', [
            action('نسخ رمز الربط', Icons.key,
                () => toast('رمز ربط ولي الأمر: ${device['token']}')),
            action(
                device['status'] == 'Online' ? 'إيقاف' : 'تشغيل',
                Icons.power_settings_new,
                () => store.edit(
                    'devices',
                    '${device['id']}',
                    {
                      'status':
                          device['status'] == 'Online' ? 'Sleep' : 'Online'
                    },
                    notice: 'تغيرت حالة جهاز ${device['name']}'))
          ]),
        panel(const Text(
            'الأجهزة الافتراضية تعتمد على الجيوفنس فقط. لا تُفعّل سجلات الصعود اليدوية أو المحادثة في وضع العتاد. اتصال TCP وفك البروتوكول غير مفعّلين في العرض التجريبي.')),
      ];

  List<Widget> campaignCards() => [
        for (final campaign in store.rows('campaigns'))
          rowCard(
              '${campaign['name']}',
              '${campaign['slot']} • ${campaign['district']} • ${campaign['start']} → ${campaign['end']}',
              '${campaign['status']} • ${campaign['advertiserCategory'] ?? 'General'} • سقف يومي ${campaign['dailyBudgetJod'] ?? campaign['dailyRate']} JOD',
              [
                action('تعديل', Icons.edit, () => editCampaign(campaign)),
                if (campaign['status'] == 'Live')
                  action(
                      'إيقاف',
                      Icons.pause_circle,
                      () => store.edit('campaigns', '${campaign['id']}',
                          {'status': 'Paused'},
                          notice: 'تم إيقاف حملة ${campaign['name']}'))
                else
                  action('إرسال للمراجعة', Icons.send, () => checkout(campaign))
              ])
      ];

  List<Widget> tripRequestCards({required bool forDriver}) => [
        for (final request in store
            .rows('tripRequests')
            .where((row) => !forDriver || row['driverId'] == 'DRV-101'))
          rowCard(
              '${request['passengerName']} • ${request['date']} ${request['time']}',
              '${request['startAddress']} ← ${request['endAddress']} • ${request['driverId']}${request['driverNote'] == null ? '' : '\nملاحظة السائق: ${request['driverNote']}'}',
              '${request['status']}',
              forDriver && request['status'] == 'Pending'
                  ? [
                      action('قبول الطلب', Icons.check_circle,
                          () => decideTripRequest(request, true),
                          filled: true),
                      action('رفض', Icons.cancel_outlined,
                          () => decideTripRequest(request, false))
                    ]
                  : forDriver &&
                          ['Confirmed', 'En route', 'Boarded']
                              .contains(request['status'])
                      ? [
                          action(
                              privateTripActionLabel('${request['status']}'),
                              privateTripActionIcon('${request['status']}'),
                              () => advancePrivateTrip(request),
                              filled: true)
                        ]
                      : guardianTripActions(request, forDriver)),
      ];

  String privateTripActionLabel(String status) => switch (status) {
        'Confirmed' => 'بدء الرحلة الخاصة',
        'En route' => 'تأكيد صعود الراكب',
        'Boarded' => 'تأكيد الوصول والإسقاط',
        _ => 'تحديث الرحلة',
      };
  IconData privateTripActionIcon(String status) => switch (status) {
        'Confirmed' => Icons.play_arrow_rounded,
        'En route' => Icons.qr_code_scanner_rounded,
        'Boarded' => Icons.flag_rounded,
        _ => Icons.route_rounded,
      };

  Future<void> advancePrivateTrip(Map<String, dynamic> request) async {
    final current = '${request['status']}';
    final next = switch (current) {
      'Confirmed' => 'En route',
      'En route' => 'Boarded',
      'Boarded' => 'Completed',
      _ => current
    };
    if (next == current) return;
    if (!AppConfig.mockMode) {
      final apiState = switch (next) {
        'En route' => 'EnRoute',
        'Boarded' => 'Boarded',
        'Completed' => 'Completed',
        _ => ''
      };
      if (apiState.isEmpty ||
          !await const PrivateTripClient().advanceExecution(
              requestId: '${request['id']}', executionStatus: apiState)) {
        toast('تعذر تحديث حالة الرحلة الخاصة. أعد المحاولة.');
        return;
      }
    }
    store.edit('tripRequests', '${request['id']}',
        {'status': next, 'updatedAt': DateTime.now().toIso8601String()},
        notice: 'تم تحديث الرحلة الخاصة ${request['id']} إلى $next');
    if (next == 'Boarded') {
      store.edit(
          'children', '${request['passengerId']}', {'attendance': 'Boarded'},
          notice: 'تم تسجيل صعود الراكب ${request['passengerName']}');
    }
    if (next == 'Completed') {
      store.edit('children', '${request['passengerId']}',
          {'attendance': 'Dropped off'},
          notice: 'تم تسجيل وصول الراكب ${request['passengerName']}');
    }
    store.announce('رحلة خاصة للراكب ${request['passengerName']}: $next',
        audience: 'GUARDIAN');
  }

  List<Widget> guardianTripActions(
      Map<String, dynamic> request, bool forDriver) {
    if (forDriver) return const [];
    return [
      if (request['status'] == 'Confirmed' && request['guardianRead'] != true)
        action('تأكيد القراءة للسائق', Icons.mark_email_read, () {
          store.edit(
              'tripRequests', request['id'] as String, {'guardianRead': true});
          store.announce('أكد ولي الأمر قراءة تفاصيل رحلة ${request['id']}',
              audience: 'DRIVER');
        }),
      if (request['status'] == 'Pending' || request['status'] == 'Confirmed')
        action('إلغاء الطلب', Icons.cancel_schedule_send_outlined,
            () => cancelTripRequest(request)),
      if (request['status'] == 'Completed')
        action('تقييم / بلاغ الرحلة', Icons.rate_review_outlined,
            () => submitJourneyFeedback(request)),
    ];
  }

  Future<void> submitJourneyFeedback(Map<String, dynamic> request) async {
    final values = await form(
        'تقييم أو بلاغ رحلة الراكب ${request['passengerName']}', const [
      _Field('category', 'نوع الملاحظة',
          options: ['Praise', 'Issue', 'Safety', 'Other']),
      _Field('rating', 'التقييم', options: ['1', '2', '3', '4', '5']),
      _Field('comment', 'التفاصيل')
    ]);
    if (values == null) return;
    if (!AppConfig.mockMode &&
        !await const JourneyCompletionClient().submitFeedback(
            passengerId: '${request['passengerId']}',
            category: values['category']!,
            rating: int.tryParse(values['rating']!),
            comment: values['comment'])) {
      toast('تعذر إرسال الملاحظة. حاول مجدداً.');
      return;
    }
    toast('تم تسجيل ملاحظتك بأمان');
  }

  Future<void> submitShiftReport() async {
    final today = DateTime.now();
    final values = await form('تقرير نهاية الوردية', [
      _Field('serviceDate', 'تاريخ الوردية', date: true),
      const _Field('segment', 'الفترة', options: ['MORNING', 'AFTERNOON']),
      const _Field('summary', 'ملخص الوردية'),
      const _Field('incidentCount', 'عدد الحوادث', number: true),
    ], initial: {
      'serviceDate': today.toIso8601String().substring(0, 10),
      'segment': 'MORNING',
      'incidentCount': '0'
    });
    if (values == null) return;
    if (!AppConfig.mockMode &&
        !await const JourneyCompletionClient().submitShiftReport(
            serviceDate: DateTime.parse(values['serviceDate']!),
            segment: values['segment']!,
            summary: values['summary']!,
            incidentCount: int.tryParse(values['incidentCount']!) ?? 0)) {
      toast('تعذر حفظ تقرير الوردية. حاول مجدداً.');
      return;
    }
    toast('تم حفظ تقرير الوردية');
  }

  Future<void> addChild() async {
    final values = await form('إضافة راكب', const [
      _Field('name', 'اسم الراكب'),
      _Field('school', 'المدرسة / جهة الوصول'),
      _Field('route', 'المسار', hint: 'Amman 04'),
      _Field('pickupAddress', 'عنوان نقطة الاستلام', location: true),
      _Field('dropoffAddress', 'عنوان نقطة الوصول', location: true),
      _Field('pickupFromDate', 'تاريخ بدء الاستلام', date: true),
      _Field('pickupToDate', 'تاريخ انتهاء الاستلام', date: true),
      _Field('pickupTime', 'وقت الاستلام اليومي', time: true),
      _Field('pickupDays', 'أيام الاستلام',
          options: ['Sunday-Thursday', 'All days', 'Custom'])
    ]);
    if (values == null) return;
    store.add(
        'children',
        {
          'id': newId('PAS'),
          ...values,
          'status': 'Active',
          'attendance': 'Waiting'
        },
        notice: 'تم إضافة الراكب ${values['name']} إلى ${values['route']}');
  }

  Future<void> editChild(Map<String, dynamic> child) async {
    final values = await form(
        'تعديل ملف الراكب',
        const [
          _Field('name', 'اسم الراكب'),
          _Field('school', 'المدرسة / جهة الوصول'),
          _Field('route', 'المسار'),
          _Field('pickupAddress', 'عنوان نقطة الاستلام', location: true),
          _Field('dropoffAddress', 'عنوان نقطة الوصول', location: true),
          _Field('pickupFromDate', 'تاريخ بدء الاستلام', date: true),
          _Field('pickupToDate', 'تاريخ انتهاء الاستلام', date: true),
          _Field('pickupTime', 'وقت الاستلام اليومي', time: true),
          _Field('pickupDays', 'أيام الاستلام',
              options: ['Sunday-Thursday', 'All days', 'Custom'])
        ],
        initial: child);
    if (values != null)
      store.edit('children', '${child['id']}', values,
          notice: 'تم تحديث الراكب ${values['name']}');
  }

  Future<void> reportAbsence(Map<String, dynamic> child) async {
    final tomorrow = DateTime.now().add(const Duration(days: 1));
    final date = tomorrow.toIso8601String().substring(0, 10);
    final values = await form('إبلاغ غياب الراكب', [
      _Field('serviceDate', 'تاريخ الخدمة', date: true),
      const _Field('tripSegment', 'الفترة',
          options: ['MORNING', 'AFTERNOON', 'BOTH']),
      const _Field('reason', 'ملاحظة اختيارية قصيرة')
    ], initial: {
      'serviceDate': date,
      'tripSegment': 'MORNING'
    });
    if (values == null) return;
    if (DateTime.tryParse(values['serviceDate']!) == null) {
      toast('راجع تاريخ الغياب');
      return;
    }
    store.add(
        'absenceReports',
        {
          'id': newId('ABS'),
          'childId': child['id'],
          'serviceDate': values['serviceDate'],
          'tripSegment': values['tripSegment'],
          'status': 'Submitted',
          'at': DateTime.now().toIso8601String().substring(0, 16)
        },
        notice: 'تم تسجيل غياب ${child['name']} وإعلام قائمة السائق');
    store.announce(
        "Don’t Come to pickup Passenger ID Number ${child['id']} Tommorow [${values['serviceDate']}]",
        audience: 'DRIVER');
  }

  Future<void> requestOneToOneTrip(Map<String, dynamic> passenger) async {
    final drivers = store
        .rows('drivers')
        .where((driver) => driver['status'] == 'Active')
        .map((driver) => '${driver['id']} • ${driver['name']}')
        .toList();
    final today = DateTime.now().toIso8601String().substring(0, 10);
    final values = await form('طلب رحلة خاصة 1:1', [
      _Field('driverId', 'اختر السائق بالمعرّف', options: drivers),
      _Field('startAddress', 'نقطة البداية',
          location: true, hint: 'افتراضياً: موقعك الحالي في عمّان'),
      _Field('endAddress', 'وجهة الوصول', location: true),
      _Field('date', 'تاريخ الرحلة', date: true),
      const _Field('time', 'وقت الاستلام', time: true),
    ], initial: {
      'startAddress': 'الموقع الحالي • عمّان، الأردن',
      'date': today,
      'time': '07:30'
    });
    if (values == null) return;
    if (DateTime.tryParse(values['date']!) == null ||
        !RegExp(r'^([01]\d|2[0-3]):[0-5]\d$').hasMatch(values['time']!)) {
      toast('راجع تاريخ ووقت الاستلام');
      return;
    }
    final driverId = values['driverId']!.split(' • ').first;
    store.add(
        'tripRequests',
        {
          'id': newId('TRIP'),
          'passengerId': passenger['id'],
          'passengerName': passenger['name'],
          'driverId': driverId,
          'startAddress': values['startAddress'],
          'endAddress': values['endAddress'],
          'date': values['date'],
          'time': values['time'],
          'status': 'Pending'
        },
        notice:
            'طلب رحلة خاصة للراكب ${passenger['name']} بانتظار موافقة السائق');
    store.announce(
        'طلب رحلة 1:1 جديد للراكب ${passenger['name']} • ${values['date']} ${values['time']}',
        audience: 'DRIVER');
  }

  Future<void> decideTripRequest(
      Map<String, dynamic> request, bool accepted) async {
    Map<String, String>? response;
    if (accepted) {
      response = await form('تأكيد الرحلة الخاصة', [
        _Field('time', 'وقت الاستلام المؤكد', time: true),
        const _Field('driverNote', 'ملاحظة للسائق/ولي الأمر')
      ], initial: {
        'time': '${request['time'] ?? ''}'
      });
      if (response == null) return;
    } else {
      response = await form('رفض الرحلة الخاصة',
          const [_Field('driverNote', 'سبب الرفض أو ملاحظة')]);
      if (response == null) return;
    }
    final status = accepted ? 'Confirmed' : 'Declined';
    store.edit(
        'tripRequests',
        '${request['id']}',
        {
          'status': status,
          if (accepted) 'time': response['time'],
          'driverNote': response['driverNote']
        },
        notice: 'قام السائق بتحديث طلب الرحلة ${request['id']} إلى $status');
    store.announce(
        accepted
            ? 'تم تأكيد الاستلام: ${request['passengerName']} عند ${request['time']} من ${request['startAddress']}'
            : 'اعتذر السائق عن طلب رحلة ${request['passengerName']}، يمكنك اختيار سائق آخر.',
        audience: 'GUARDIAN');
  }

  Future<void> cancelTripRequest(Map<String, dynamic> request) async {
    final values =
        await form('إلغاء طلب الرحلة', const [_Field('reason', 'سبب الإلغاء')]);
    if (values == null || values['reason']!.trim().length < 3) {
      toast('اكتب سبب إلغاء واضحاً');
      return;
    }
    store.edit('tripRequests', '${request['id']}',
        {'status': 'Cancelled', 'cancellationReason': values['reason']!.trim()},
        notice: 'تم إلغاء طلب الرحلة ${request['id']}');
    store.announce(
        'تم إلغاء طلب الرحلة ${request['id']}: ${values['reason']!.trim()}',
        audience: 'DRIVER');
  }

  Future<void> addSubscriptionPlan() async {
    final values = await form('إضافة خطة اشتراك', const [
      _Field('name', 'اسم الخطة'),
      _Field('monthly', 'السعر الشهري JOD', number: true),
      _Field('licenses', 'عدد الرخص', number: true)
    ]);
    if (values != null)
      store.add(
          'subscriptionPlans',
          {
            'id': newId('PLAN'),
            ...values,
            'monthly': double.parse(values['monthly']!),
            'licenses': int.parse(values['licenses']!),
            'status': 'Active'
          },
          notice: 'تمت إضافة خطة ${values['name']}');
  }

  Future<void> editSubscriptionPlan(Map<String, dynamic> plan) async {
    final values = await form(
        'تعديل خطة الاشتراك',
        const [
          _Field('name', 'اسم الخطة'),
          _Field('monthly', 'السعر الشهري JOD', number: true),
          _Field('licenses', 'عدد الرخص', number: true)
        ],
        initial: plan);
    if (values != null)
      store.edit(
          'subscriptionPlans',
          '${plan['id']}',
          {
            ...values,
            'monthly': double.parse(values['monthly']!),
            'licenses': int.parse(values['licenses']!)
          },
          notice: 'تم تعديل خطة ${values['name']}');
  }

  Future<void> addCorporateUser() async {
    final values = await form('إضافة مستخدم شركة', [
      _Field('name', 'الاسم الكامل'),
      _Field('tenant', 'المؤسسة',
          options: store
              .rows('tenants')
              .map((tenant) => '${tenant['id']} • ${tenant['name']}')
              .toList()),
      const _Field('role', 'الدور',
          options: ['CORPORATE_ADMIN', 'CORPORATE_VIEWER', 'BILLING_ADMIN'])
    ]);
    if (values != null)
      store.add(
          'corporateUsers', {'id': newId('USR'), ...values, 'status': 'Active'},
          notice: 'تمت إضافة مستخدم شركة ${values['name']}');
  }

  Future<void> addAdminAccount() async {
    final values = await form('دعوة مسؤول منصة', const [
      _Field('name', 'الاسم الكامل'),
      _Field('role', 'الدور الإداري', options: [
        'SUPER_ADMIN',
        'BILLING_REVIEWER',
        'COMPLIANCE_REVIEWER',
        'SUPPORT_ADMIN'
      ])
    ]);
    if (values != null)
      store.add(
          'adminAccounts',
          {
            'id': newId('ADM'),
            ...values,
            'mfa': 'Required',
            'status': 'Invited'
          },
          notice: 'تمت دعوة ${values['name']}، ويجب تفعيل MFA قبل الوصول');
  }

  Future<void> requestLicenseCapacity() async {
    final values = await form('طلب زيادة سعة الرخص', const [
      _Field('licenses', 'عدد الرخص المطلوبة', number: true),
      _Field('reason', 'السبب التشغيلي')
    ]);
    if (values == null) return;
    final licenses = int.tryParse(values['licenses']!);
    if (licenses == null || licenses < 1 || values['reason']!.length < 5) {
      toast('أدخل عدد الرخص وسبباً تشغيلياً واضحاً');
      return;
    }
    store.add(
        'licenseRequests',
        {
          'id': newId('LIC'),
          'tenant': 'TEN-01',
          'licenses': licenses,
          'reason': values['reason'],
          'status': 'Pending'
        },
        notice: 'تم إرسال طلب زيادة الرخص إلى الإدارة العليا');
    store.announce('طلب رخص جديد من TEN-01: $licenses رخصة',
        audience: 'SUPER_ADMIN');
  }

  Future<void> addIncident() async {
    final values = await form('تسجيل حادث منصة', const [
      _Field('title', 'عنوان الحادث'),
      _Field('severity', 'درجة الخطورة',
          options: ['Low', 'Medium', 'High', 'Critical']),
      _Field('owner', 'الفريق المالك',
          options: ['Operations', 'Finance', 'Support', 'Security'])
    ]);
    if (values == null) return;
    store.add('incidents', {'id': newId('INC'), ...values, 'status': 'Open'},
        notice: 'تم فتح الحادث ${values['title']} وتسجيله في التدقيق');
  }

  void startEmergencyDrill() {
    store.add(
        'incidents',
        {
          'id': newId('DRILL'),
          'title': 'Emergency drill — dispatch acknowledgement required',
          'severity': 'High',
          'owner': 'Safety Operations',
          'status': 'Investigating',
          'drill': true
        },
        notice: 'تم بدء تمرين طوارئ تجريبي؛ لا توجد حالة طارئة فعلية');
    toast('تم إنشاء تمرين معزول وتسجيله في سجل الحوادث');
  }

  void linkFleetAlertToIncident(Map<String, dynamic> alertItem) {
    store.add(
        'incidents',
        {
          'id': newId('INC'),
          'title': '${alertItem['title']} (${alertItem['vehicle']})',
          'severity':
              alertItem['type'] == 'CUSTODY_PENDING' ? 'High' : 'Medium',
          'owner': 'Dispatch',
          'status': 'Investigating',
          'sourceAlertId': alertItem['id']
        },
        notice: 'تم تحويل إنذار ${alertItem['id']} إلى حادث للمراجعة');
    store
        .edit('fleetAlerts', '${alertItem['id']}', {'status': 'Investigating'});
    toast('تم فتح حادث وربطه بإنذار الأسطول');
  }

  Future<void> addRetentionPolicy() async {
    final values = await form('إضافة سياسة احتفاظ', const [
      _Field('name', 'اسم نوع البيانات'),
      _Field('period', 'مدة الاحتفاظ', hint: '180 days')
    ]);
    if (values == null ||
        values['name']!.length < 3 ||
        values['period']!.length < 3) {
      toast('أدخل اسم البيانات ومدة احتفاظ واضحة');
      return;
    }
    store.add('retentionPolicies',
        {'id': newId('RET'), ...values, 'status': 'Pending legal review'},
        notice: 'سياسة احتفاظ جديدة بانتظار المراجعة القانونية');
  }

  Future<void> addAdSlot() async {
    final values = await form('إضافة موضع إعلاني', const [
      _Field('name', 'اسم الموضع الإعلاني'),
      _Field('dimensions', 'الأبعاد بالبكسل', hint: '1200 × 628 px'),
      _Field('location', 'موقع الظهور داخل التطبيق'),
      _Field('capacity', 'سعة الحجوزات المتزامنة', options: ['1', '2', '3']),
      _Field('categoryExclusive', 'حصرية فئة المعلن', options: ['No', 'Yes'])
    ]);
    if (values != null)
      store.update((data) {
        (data['adSlots'] as List).add(values['name']);
        (data['adSlotCatalog'] as List).add({'id': newId('SLOT'), ...values});
      });
  }

  Future<void> editAdSlot(Map<String, dynamic> slot) async {
    final values = await form(
        'تعديل موضع إعلاني',
        const [
          _Field('name', 'اسم الموضع الإعلاني'),
          _Field('dimensions', 'الأبعاد بالبكسل'),
          _Field('location', 'موقع الظهور داخل التطبيق'),
          _Field('capacity', 'سعة الحجوزات المتزامنة',
              options: ['1', '2', '3']),
          _Field('categoryExclusive', 'حصرية فئة المعلن',
              options: ['No', 'Yes'])
        ],
        initial: slot);
    if (values != null)
      store.edit('adSlotCatalog', '${slot['id']}', values,
          notice: 'تم تحديث موضع الإعلان ${values['name']}');
  }

  Future<void> addAdCity() async {
    final values = await form('إضافة مدينة أو منطقة إعلانية',
        const [_Field('city', 'اسم المدينة أو المنطقة')]);
    if (values != null)
      store.update((data) {
        (data['adCities'] as List).add(values['city']);
      });
  }

  Future<void> addIntegration() async {
    final values = await form('إضافة إعداد/إضافة نظام', const [
      _Field('name', 'اسم الإضافة أو الخدمة'),
      _Field('category', 'الفئة', options: [
        'Analytics',
        'Maps',
        'Messaging',
        'Authentication',
        'Payments',
        'Extension'
      ]),
      _Field('publicConfig', 'المعرّف العام أو رابط API'),
      _Field('secretRef', 'مرجع المفتاح/كلمة المرور في Vault',
          hint: 'VAULT:provider/credential')
    ]);
    if (values != null)
      store.add('systemIntegrations',
          {'id': newId('INT'), ...values, 'status': 'Pending'},
          notice: 'تمت إضافة إعداد ${values['name']} للمراجعة');
  }

  Future<void> editIntegration(Map<String, dynamic> integration) async {
    final values = await form(
        'تعديل إعداد النظام',
        const [
          _Field('name', 'اسم الإضافة أو الخدمة'),
          _Field('category', 'الفئة', options: [
            'Analytics',
            'Maps',
            'Messaging',
            'Authentication',
            'Payments',
            'Extension'
          ]),
          _Field('publicConfig', 'المعرّف العام أو رابط API'),
          _Field('secretRef', 'مرجع المفتاح/كلمة المرور في Vault')
        ],
        initial: integration);
    if (values != null)
      store.edit('systemIntegrations', '${integration['id']}', values,
          notice: 'تم تعديل إعداد ${values['name']}');
  }

  Future<void> addFeatureFlag() async {
    final values = await form('إضافة إطلاق ميزة', const [
      _Field('key', 'معرف الميزة', hint: 'new_reports'),
      _Field('name', 'اسم الميزة'),
      _Field('rollout', 'نسبة الإطلاق 0-100', number: true),
      _Field('tenants', 'المؤسسات التجريبية', hint: 'TEN-01, TEN-02 أو —'),
      _Field('reason', 'سبب التغيير')
    ]);
    if (values == null) return;
    final rollout = int.tryParse(values['rollout']!);
    if (!RegExp(r'^[a-z0-9_-]{2,80}$').hasMatch(values['key']!) ||
        rollout == null ||
        rollout < 0 ||
        rollout > 100 ||
        values['reason']!.length < 5) {
      toast('راجع معرف الميزة ونسبة الإطلاق وسبب التغيير');
      return;
    }
    store.add(
        'featureFlags',
        {
          'id': newId('FLAG'),
          ...values,
          'rollout': rollout,
          'enabled': rollout > 0
        },
        notice: 'تمت إضافة إطلاق تجريبي للميزة ${values['name']}');
  }

  Future<void> editFeatureFlag(Map<String, dynamic> flag) async {
    final values = await form(
        'تعديل إطلاق الميزة',
        const [
          _Field('key', 'معرف الميزة'),
          _Field('name', 'اسم الميزة'),
          _Field('rollout', 'نسبة الإطلاق 0-100', number: true),
          _Field('tenants', 'المؤسسات التجريبية'),
          _Field('reason', 'سبب التغيير')
        ],
        initial: flag);
    if (values == null) return;
    final rollout = int.tryParse(values['rollout']!);
    if (rollout == null ||
        rollout < 0 ||
        rollout > 100 ||
        values['reason']!.length < 5) {
      toast('راجع نسبة الإطلاق وسبب التغيير');
      return;
    }
    store.edit('featureFlags', '${flag['id']}',
        {...values, 'rollout': rollout, 'enabled': rollout > 0},
        notice: 'تم تحديث إطلاق الميزة ${values['name']}');
  }

  Future<void> addGateway() async {
    final values = await form('إضافة بوابة دفع', const [
      _Field('name', 'اسم بوابة الدفع'),
      _Field('logo', 'رمز أو شعار البوابة', hint: '💳'),
      _Field('apiUrl', 'رابط API'),
      _Field('secretRef', 'مرجع الاعتماد في Vault')
    ]);
    if (values != null)
      store.add('paymentGateways',
          {'id': newId('PAY'), ...values, 'status': 'Pending'},
          notice: 'تمت إضافة بوابة الدفع ${values['name']} للمراجعة');
  }

  Future<void> editGateway(Map<String, dynamic> gateway) async {
    final values = await form(
        'تعديل بوابة الدفع',
        const [
          _Field('name', 'اسم بوابة الدفع'),
          _Field('logo', 'رمز أو شعار البوابة'),
          _Field('apiUrl', 'رابط API'),
          _Field('secretRef', 'مرجع الاعتماد في Vault')
        ],
        initial: gateway);
    if (values != null)
      store.edit('paymentGateways', '${gateway['id']}', values,
          notice: 'تم تعديل بوابة الدفع ${values['name']}');
  }

  Future<void> addDriver() async {
    final values = await form('إضافة سائق', const [
      _Field('name', 'الاسم الكامل'),
      _Field('plate', 'رقم اللوحة'),
      _Field('route', 'المسار'),
      _Field('capacity', 'سعة الركاب', number: true),
      _Field('phone', 'الهاتف الدولي')
    ]);
    if (values == null) return;
    store.add(
        'drivers',
        {
          'id': newId('DRV'),
          ...values,
          'capacity': int.parse(values['capacity']!),
          'used': 0,
          'status': 'Pending'
        },
        notice: 'سائق جديد بانتظار الموافقة: ${values['name']}');
  }

  Future<void> editDriver(Map<String, dynamic> driver) async {
    final values = await form(
        'تعديل ملف السائق',
        const [
          _Field('name', 'الاسم الكامل'),
          _Field('plate', 'رقم اللوحة'),
          _Field('route', 'المسار'),
          _Field('capacity', 'سعة الركاب', number: true),
          _Field('phone', 'الهاتف الدولي')
        ],
        initial: driver);
    if (values != null)
      store.edit('drivers', '${driver['id']}',
          {...values, 'capacity': int.parse(values['capacity']!)},
          notice: 'تم تحديث السائق ${values['name']}');
  }

  Future<void> addTenant() async {
    final values = await form('إضافة مؤسسة', const [
      _Field('name', 'اسم المؤسسة'),
      _Field('tier', 'الخطة'),
      _Field('licenses', 'عدد الرخص', number: true),
      _Field('contactPerson', 'مسؤول الاتصال'),
      _Field('mobile', 'رقم الموبايل'),
      _Field('whatsapp', 'رقم واتساب'),
      _Field('registration', 'رقم تسجيل الشركة'),
      _Field('city', 'المدينة', options: ['Amman', 'Irbid', 'Zarqa', 'Aqaba']),
      _Field('country', 'الدولة', options: ['Jordan']),
      _Field('addressLine1', 'العنوان - السطر 1', location: true),
      _Field('description', 'وصف الشركة'),
      _Field('dateRegistered', 'تاريخ التسجيل YYYY-MM-DD')
    ]);
    if (values != null)
      store.add(
          'tenants',
          {
            'id': newId('TEN'),
            ...values,
            'licenses': int.parse(values['licenses']!),
            'status': 'Pending'
          },
          notice: 'مؤسسة جديدة بانتظار الاعتماد: ${values['name']}');
  }

  Future<void> editTenant(Map<String, dynamic> tenant) async {
    final values = await form(
        'تعديل المؤسسة',
        const [
          _Field('name', 'اسم المؤسسة'),
          _Field('tier', 'الخطة'),
          _Field('licenses', 'عدد الرخص', number: true),
          _Field('contactPerson', 'مسؤول الاتصال'),
          _Field('mobile', 'رقم الموبايل'),
          _Field('whatsapp', 'رقم واتساب'),
          _Field('registration', 'رقم تسجيل الشركة'),
          _Field('city', 'المدينة',
              options: ['Amman', 'Irbid', 'Zarqa', 'Aqaba']),
          _Field('country', 'الدولة', options: ['Jordan']),
          _Field('addressLine1', 'العنوان - السطر 1', location: true),
          _Field('description', 'وصف الشركة'),
          _Field('dateRegistered', 'تاريخ التسجيل YYYY-MM-DD')
        ],
        initial: tenant);
    if (values != null)
      store.edit('tenants', '${tenant['id']}',
          {...values, 'licenses': int.parse(values['licenses']!)},
          notice: 'تم تحديث المؤسسة ${values['name']}');
  }

  Future<void> addRule() async {
    final values = await form('إضافة قاعدة', const [
      _Field('name', 'الحدث'),
      _Field('amount', 'المبلغ JOD', number: true)
    ]);
    if (values != null)
      store.add(
          'rules',
          {
            'id': newId('GR'),
            'name': values['name'],
            'amount': double.parse(values['amount']!),
            'status': 'Active'
          },
          notice: 'تم إضافة قاعدة ${values['name']}');
  }

  Future<void> editRule(Map<String, dynamic> rule) async {
    final values = await form(
        'تعديل القاعدة',
        const [
          _Field('name', 'الحدث'),
          _Field('amount', 'المبلغ JOD', number: true)
        ],
        initial: rule);
    if (values != null)
      store.edit('rules', '${rule['id']}',
          {'name': values['name'], 'amount': double.parse(values['amount']!)},
          notice: 'تم تعديل قاعدة ${values['name']}');
  }

  Future<void> changeBrand() async {
    final values = await form('اللون الرئيسي',
        const [_Field('brandColor', 'Hex color', hint: '#005B60')],
        initial: {'brandColor': store.text('brandColor')});
    if (values == null) return;
    if (!RegExp(r'^#[0-9a-fA-F]{6}$').hasMatch(values['brandColor']!)) {
      toast('صيغة اللون غير صحيحة');
      return;
    }
    store.setValue('brandColor', values['brandColor'],
        notice: 'تم تحديث اللون الرئيسي');
  }

  Future<void> editCorporateBrand() async {
    final values = await form(
        'تعديل هوية الشركة',
        const [
          _Field('name', 'اسم الشركة الظاهر'),
          _Field('accentColor', 'اللون المميز Hex', hint: '#005B60'),
          _Field('invoiceFooter', 'تذييل الفاتورة')
        ],
        initial: corporateBrand);
    if (values == null) return;
    if (!RegExp(r'^#[0-9a-fA-F]{6}$').hasMatch(values['accentColor']!)) {
      toast('أدخل لوناً بصيغة Hex مثل #005B60');
      return;
    }
    store.setValue('corporateBrand', {...corporateBrand, ...values},
        notice: 'تم تحديث هوية الشركة بانتظار مراجعة النشر');
  }

  Future<void> uploadCorporateLogo() async {
    final selection = await FilePicker.platform
        .pickFiles(type: FileType.image, withData: true);
    final file = selection?.files.single;
    final extension = (file?.extension ?? '').toLowerCase();
    const allowed = {'png', 'jpg', 'jpeg', 'webp'};
    if (file == null || file.bytes == null) return;
    if (!allowed.contains(extension)) {
      toast('استخدم PNG أو JPG أو JPEG أو WebP للشعار');
      return;
    }
    if (file.bytes!.length > 512 * 1024) {
      toast('حجم الشعار يتجاوز 512 كيلوبايت');
      return;
    }
    final mime = extension == 'png'
        ? 'image/png'
        : extension == 'webp'
            ? 'image/webp'
            : 'image/jpeg';
    store.setValue(
        'corporateBrand',
        {
          ...corporateBrand,
          'logoData': 'data:$mime;base64,${base64Encode(file.bytes!)}',
          'logoFileName': file.name
        },
        notice: 'تم رفع شعار ${file.name} للمعاينة المحلية');
    toast('تم تحديث معاينة الشعار محلياً');
  }

  Future<void> changeDailyAdRate() async {
    final values = await form('سعر الإعلان اليومي',
        const [_Field('dailyAdRate', 'السعر اليومي JOD', number: true)],
        initial: {'dailyAdRate': store.number('dailyAdRate')});
    if (values == null) return;
    final rate = double.parse(values['dailyAdRate']!);
    if (rate <= 0) {
      toast('يجب أن يكون السعر أكبر من صفر');
      return;
    }
    store.setValue('dailyAdRate', rate,
        notice: 'تم تحديث سعر الإعلان اليومي إلى $rate JOD');
  }

  Future<void> provisionHardware() async {
    final values = await form('تخصيص جهاز GPS كسائق افتراضي', const [
      _Field('imei', 'IMEI / Serial'),
      _Field('name', 'اسم الجهاز'),
      _Field('route', 'المسار')
    ]);
    if (values == null) return;
    if (!RegExp(r'^\d{10,17}$').hasMatch(values['imei']!)) {
      toast('رقم IMEI يجب أن يكون من 10 إلى 17 رقماً');
      return;
    }
    final token = store.provisionToken();
    store.add(
        'devices',
        {
          'id': newId('GPS'),
          ...values,
          'status': 'Online',
          'token': token,
          'ignition': 'On'
        },
        notice: 'تم تخصيص جهاز ${values['name']} للمسار ${values['route']}');
    toast('رمز الربط: $token');
  }

  Future<void> linkHardware() async {
    final values = await form(
        'ربط جهاز تتبع', const [_Field('token', 'رمز TG-XXXX-XXXX')]);
    if (values == null) return;
    final token = values['token']!.toUpperCase();
    final matches = store.rows('devices').where(
        (device) => device['token'] == token && device['status'] == 'Online');
    if (matches.isEmpty) {
      toast('الرمز غير صحيح أو الجهاز غير نشط');
      return;
    }
    store.setValue('hardwareToken', token,
        notice: 'تم ربط ولي الأمر بجهاز تتبع مقيد');
  }

  Future<void> linkDriverByCode() async {
    final passengers = store.rows('children');
    final values = await form('ربط راكب بسائق فورياً', [
      _Field('passengerId', 'الراكب',
          options: passengers
              .map((item) => '${item['id']} • ${item['name']}')
              .toList()),
      const _Field('driverCode', 'رمز ربط السائق المؤقت',
          hint: 'WRL-EXAMPLECODE')
    ]);
    if (values == null) return;
    final passengerId = values['passengerId']!.split(' • ').first;
    final code = values['driverCode']!.trim().toUpperCase();
    Map<String, dynamic>? driver;
    for (final item in store.rows('drivers')) {
      final expiresAt =
          DateTime.tryParse('${item['shareCodeExpiresAt'] ?? ''}');
      final isTemporaryCode = code.startsWith('WRL-');
      final codeIsUsable = !isTemporaryCode ||
          (expiresAt != null && expiresAt.isAfter(DateTime.now()));
      if ('${item['shareCode']}'.toUpperCase() == code &&
          item['status'] == 'Active' &&
          codeIsUsable) {
        driver = item;
        break;
      }
    }
    if (driver == null) {
      toast('رمز الربط غير صحيح أو انتهت صلاحيته أو السائق غير نشط');
      return;
    }
    store.edit('children', passengerId, {'assignedDriver': driver['id']},
        notice: 'تم ربط الراكب بالسائق ${driver['name']} فورياً');
    store.announce('تم ربط راكب جديد برمز المشاركة؛ راجع القائمة قبل الانطلاق.',
        audience: 'DRIVER');
  }

  /// Guardian-side direct linking for a specific Passenger. The displayed
  /// Driver Unique ID is a stable reference; a temporary pairing code can be
  /// accepted as an assisted alternative during the pilot.
  Future<void> assignDriverByUniqueId(Map<String, dynamic> passenger) async {
    final values = await form('تعيين سائق للراكب ${passenger['name']}', const [
      _Field('driverUniqueId', 'معرّف السائق الفريد', hint: 'DRV-101'),
    ]);
    if (values == null) return;
    final entered = values['driverUniqueId']!.trim().toUpperCase();
    final matches = store.rows('drivers').where((driver) =>
        '${driver['id']}'.toUpperCase() == entered ||
        '${driver['shareCode'] ?? ''}'.toUpperCase() == entered);
    if (matches.isEmpty) {
      toast('معرّف السائق غير موجود. اطلب من السائق مشاركة Driver Unique ID.');
      return;
    }
    final driver = matches.first;
    if (driver['status'] != 'Active') {
      toast('هذا السائق غير نشط ولا يمكن تعيينه حالياً');
      return;
    }
    store.edit(
        'children', '${passenger['id']}', {'assignedDriver': driver['id']},
        notice:
            'تم إرسال طلب ربط ${passenger['name']} بالسائق ${driver['name']} (${driver['id']})');
    store.announce(
        'طلب ربط راكب جديد: ${passenger['name']} مع السائق ${driver['id']}. يلزم قبول السائق قبل تفعيل الخدمة.',
        audience: 'DRIVER');
    toast('تم إرسال طلب التعيين للسائق للتأكيد');
  }

  Future<void> requestServiceAssignment(Map<String, dynamic> passenger) async {
    final drivers = store
        .rows('drivers')
        .where((driver) => driver['status'] == 'Active')
        .map((driver) => '${driver['id']} • ${driver['name']}')
        .toList();
    if (drivers.isEmpty) {
      toast('لا يوجد سائق نشط متاح لطلب التعيين');
      return;
    }
    final values = await form('طلب تعيين خدمة للراكب ${passenger['name']}', [
      _Field('driver', 'السائق المطلوب', options: drivers),
      const _Field('segment', 'فترة الخدمة',
          options: ['MORNING', 'AFTERNOON', 'BOTH']),
      const _Field('role', 'نوع التعيين', options: ['PRIMARY', 'SUBSTITUTE']),
      const _Field('effectiveFrom', 'تاريخ بداية التعيين', date: true),
      const _Field('effectiveTo', 'تاريخ نهاية التعيين', date: true)
    ], initial: {
      'effectiveFrom': '${passenger['pickupFromDate'] ?? '2026-09-27'}',
      'effectiveTo': '${passenger['pickupToDate'] ?? '2027-06-30'}'
    });
    if (values == null) return;
    final starts = DateTime.tryParse(values['effectiveFrom'] ?? '');
    final ends = DateTime.tryParse(values['effectiveTo'] ?? '');
    if (starts == null || ends == null || ends.isBefore(starts)) {
      toast('أدخل فترة تعيين صحيحة');
      return;
    }
    final driverId = values['driver']!.split(' • ').first;
    store.add(
        'serviceAssignments',
        {
          'id': newId('SAS'),
          'passengerId': passenger['id'],
          'driverId': driverId,
          'segment': values['segment'],
          'role': values['role'],
          'effectiveFrom': values['effectiveFrom'],
          'effectiveTo': values['effectiveTo'],
          'status': 'Pending',
          'linkedVia': 'Guardian request'
        },
        notice:
            'تم إرسال طلب التعيين للسائق. لن يظهر في بيان الرحلة قبل القبول.');
    store.announce(
        'طلب تعيين خدمة جديد للراكب ${passenger['name']} بانتظار قرار السائق.',
        audience: 'DRIVER');
  }

  void decideServiceAssignment(Map<String, dynamic> assignment, bool accept) {
    if (accept && assignment['role'] == 'PRIMARY') {
      final starts = DateTime.parse('${assignment['effectiveFrom']}');
      final ends = DateTime.parse('${assignment['effectiveTo']}');
      final conflict = store.rows('serviceAssignments').any((item) =>
          item['id'] != assignment['id'] &&
          item['passengerId'] == assignment['passengerId'] &&
          item['status'] == 'Active' &&
          item['role'] == 'PRIMARY' &&
          (item['segment'] == assignment['segment'] ||
              item['segment'] == 'BOTH' ||
              assignment['segment'] == 'BOTH') &&
          !ends.isBefore(DateTime.parse('${item['effectiveFrom']}')) &&
          !starts.isAfter(DateTime.parse('${item['effectiveTo']}')));

      if (conflict) {
        toast(
            'يوجد تعيين أساسي متداخل. استخدم بديل أو اطلب إنهاء التعيين السابق.');
        return;
      }
    }
    store.edit(
        'serviceAssignments',
        '${assignment['id']}',
        {
          'status': accept ? 'Active' : 'Rejected',
          'decidedAt': DateTime.now().toIso8601String()
        },
        notice: accept
            ? 'تم قبول تعيين الخدمة وتفعيله.'
            : 'تم رفض طلب تعيين الخدمة.');
    final passenger = store.rows('children').firstWhere(
        (child) => child['id'] == assignment['passengerId'],
        orElse: () => {'name': 'الراكب'});
    store.announce(
        accept
            ? 'تم قبول تعيين خدمة ${passenger['name']} للسائق. راجع الفترة والبيان قبل الرحلة.'
            : 'تم رفض طلب تعيين خدمة ${passenger['name']}. يمكنك اختيار سائق آخر أو تعديل الفترة.',
        audience: 'GUARDIAN');
  }

  Future<void> activateSubstitute(Map<String, dynamic> assignment) async {
    final values = await form('تفعيل سائق بديل', [
      const _Field('serviceDate', 'تاريخ الخدمة', hint: 'YYYY-MM-DD'),
      const _Field('reason', 'سبب التفعيل التشغيلي',
          hint: 'مثال: تعذر السائق الأساسي')
    ], initial: {
      'serviceDate': DateTime.now().toIso8601String().substring(0, 10)
    });
    if (values == null) return;
    final date = DateTime.tryParse(values['serviceDate'] ?? '');
    if (date == null || (values['reason']?.trim().length ?? 0) < 3) {
      toast('أدخل تاريخاً صحيحاً وسبباً واضحاً للتفعيل');
      return;
    }
    final exists = store.rows('substituteActivations').any((item) =>
        item['passengerId'] == assignment['passengerId'] &&
        item['serviceDate'] == values['serviceDate'] &&
        item['segment'] == assignment['segment'] &&
        item['status'] == 'Active');
    if (exists) {
      toast('يوجد بديل مفعل بالفعل لهذا الراكب والفترة والتاريخ');
      return;
    }
    store.add(
        'substituteActivations',
        {
          'id': newId('SUB'),
          'assignmentId': assignment['id'],
          'passengerId': assignment['passengerId'],
          'driverId': assignment['driverId'],
          'serviceDate': values['serviceDate'],
          'segment': assignment['segment'],
          'reason': values['reason']!.trim(),
          'status': 'Active'
        },
        notice: 'تم تفعيل السائق البديل لهذه الفترة فقط.');
    final passenger = store.rows('children').firstWhere(
        (child) => child['id'] == assignment['passengerId'],
        orElse: () => {'name': 'الراكب'});
    store.announce(
        'تم تفعيل بديل للراكب ${passenger['name']} في ${assignment['segment']} بتاريخ ${values['serviceDate']}.',
        audience: 'DRIVER');
    store.announce(
        'تم اعتماد سائق بديل لرحلة ${passenger['name']} ضمن الفترة المحددة فقط.',
        audience: 'GUARDIAN');
  }

  Future<void> endSubstitute(Map<String, dynamic> activation) async {
    final values = await form('إنهاء تفعيل البديل', const [
      _Field('reason', 'سبب الإنهاء التشغيلي',
          hint: 'مثال: عاد السائق الأساسي للخدمة')
    ]);
    if (values == null || (values['reason']?.trim().length ?? 0) < 3) {
      if (values != null) toast('أدخل سبباً واضحاً لإنهاء التفعيل');
      return;
    }
    store.edit(
        'substituteActivations',
        '${activation['id']}',
        {
          'status': 'Ended',
          'endReason': values['reason']!.trim(),
          'endedAt': DateTime.now().toIso8601String()
        },
        notice: 'تم إنهاء تفعيل البديل. عاد التعيين الأساسي إلى وضعه الطبيعي.');
    store.announce(
        'تم إنهاء تفعيل السائق البديل للراكب ${activation['passengerId']}.',
        audience: 'DRIVER');
    store.announce(
        'تم إنهاء ترتيب السائق البديل وعادت الرحلة إلى التعيين الأساسي.',
        audience: 'GUARDIAN');
  }

  void generateRosterShareCode() {
    const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final seed = DateTime.now().microsecondsSinceEpoch;
    final suffix = List.generate(
            12,
            (index) =>
                alphabet[(seed ~/ (index + 3) + index * 11) % alphabet.length])
        .join();
    final code = 'WRL-$suffix';
    final expiresAt = DateTime.now().add(const Duration(minutes: 30));
    store.edit('drivers', 'DRV-101',
        {'shareCode': code, 'shareCodeExpiresAt': expiresAt.toIso8601String()},
        notice: 'تم إنشاء رمز ربط مؤقت صالح لمدة 30 دقيقة');
    toast(
        'رمز الربط المؤقت: $code\nتنتهي صلاحيته 30 دقيقة. شاركه بعد التحقق فقط.');
  }

  Future<void> reportAdCompliance() async {
    final values = await form('إبلاغ التزام إعلان', [
      _Field('campaign', 'الحملة',
          options: store
              .rows('campaigns')
              .map((item) => '${item['name']}')
              .toList()),
      const _Field('reason', 'سبب البلاغ', options: [
        'UNSUITABLE_CONTENT',
        'WRONG_PLACEMENT',
        'SAFETY_CONTEXT',
        'COPYRIGHT',
        'PRIVACY',
        'OTHER'
      ]),
      const _Field(
          'details', 'تفاصيل مختصرة لا تتضمن بيانات ركاب أو موقعاً دقيقاً')
    ]);
    if (values == null) return;
    store.add(
        'adComplianceReports',
        {
          'id': newId('ACR'),
          ...values,
          'campaignId': 'Demo',
          'status': 'Open',
          'at': DateTime.now().toIso8601String().substring(0, 16)
        },
        notice: 'تم إرسال البلاغ للمراجعة لدى مسؤول النظام');
  }

  Future<void> addAdRateCard() async {
    final values = await form('إضافة بطاقة سعر إعلانية', const [
      _Field('surface', 'سطح العرض', options: [
        'SPLASH',
        'HOME_CONTEXTUAL',
        'POST_TRIP_SUMMARY',
        'PRE_ROUTE',
        'POST_ROUTE',
        'WAITING'
      ]),
      _Field('model', 'نموذج التسعير', options: ['CPD', 'CPM', 'CPC']),
      _Field('city', 'المدينة',
          options: ['All cities', 'Amman', 'Irbid', 'Zarqa']),
      _Field('rate', 'السعر JOD', hint: '12.50')
    ]);
    if (values == null || (double.tryParse(values['rate'] ?? '') ?? 0) <= 0) {
      if (values != null) toast('أدخل سعراً صحيحاً أكبر من صفر');
      return;
    }
    store.add(
        'adRateCards',
        {
          'id': newId('RATE'),
          ...values,
          'rate':
              '${values['rate']} JOD/${values['model'] == 'CPD' ? 'day' : values['model']}',
          'status': 'Active'
        },
        notice:
            'تمت إضافة بطاقة السعر؛ يجب تطبيقها على الخادم قبل تسعير الحملات الفعلية');
  }

  Future<void> addCampaign() async {
    final values = await form('إعداد حملة جديدة', [
      _Field('name', 'اسم الحملة'),
      _Field('slot', 'موضع الإعلان',
          options: (store.data['adSlots'] as List).cast<String>()),
      _Field('district', 'المدينة المستهدفة',
          options: (store.data['adCities'] as List).cast<String>()),
      const _Field('targetApp', 'تطبيق العرض',
          options: ['Guardian App', 'Driver App (stationary only)']),
      const _Field('daypart', 'فترة العرض', options: [
        'All approved hours',
        'Morning 06:00–09:00',
        'Afternoon 13:00–16:00'
      ]),
      const _Field('pricingModel', 'نموذج التسعير',
          options: ['CPD', 'CPM', 'CPC']),
      const _Field('advertiserCategory', 'فئة المعلن',
          options: ['Education', 'Retail', 'Food & beverage', 'General']),
      const _Field('dailyBudgetJod', 'حد الإنفاق اليومي (JOD)'),
      const _Field('destinationUrl', 'رابط الوجهة HTTPS اختياري'),
      const _Field('asset', 'اسم الأصل الإعلاني'),
      const _Field('imageUrl', 'رابط الصورة أو اضغط لرفعها من الجهاز',
          image: true),
      const _Field('start', 'تاريخ البدء YYYY-MM-DD'),
      const _Field('end', 'تاريخ الانتهاء YYYY-MM-DD')
    ]);
    if (values == null) return;
    if (DateTime.tryParse(values['start']!) == null ||
        DateTime.tryParse(values['end']!) == null ||
        values['end']!.compareTo(values['start']!) < 0 ||
        (double.tryParse(values['dailyBudgetJod'] ?? '') ?? 0) <= 0) {
      toast('راجع تاريخ الحملة وحد الإنفاق اليومي');
      return;
    }
    final days = DateTime.parse(values['end']!)
            .difference(DateTime.parse(values['start']!))
            .inDays +
        1;
    final rate = store.number('dailyAdRate');
    store.add(
        'campaigns',
        {
          'id': newId('AD'),
          ...values,
          'dailyRate': rate,
          'days': days,
          'budget': (double.tryParse(values['dailyBudgetJod']!) ?? rate) * days,
          'deliverySpend': 0,
          'status': 'Draft'
        },
        notice: 'حملة جديدة: ${values['name']} • $days يوم × $rate JOD');
  }

  Future<void> editCampaign(Map<String, dynamic> campaign) async {
    final values = await form(
        'تعديل الحملة ومعاينة الأصل',
        [
          _Field('name', 'اسم الحملة'),
          _Field('slot', 'موضع الإعلان',
              options: (store.data['adSlots'] as List).cast<String>()),
          _Field('district', 'المدينة المستهدفة',
              options: (store.data['adCities'] as List).cast<String>()),
          const _Field('targetApp', 'تطبيق العرض',
              options: ['Guardian App', 'Driver App (stationary only)']),
          const _Field('daypart', 'فترة العرض', options: [
            'All approved hours',
            'Morning 06:00–09:00',
            'Afternoon 13:00–16:00'
          ]),
          const _Field('pricingModel', 'نموذج التسعير',
              options: ['CPD', 'CPM', 'CPC']),
          const _Field('advertiserCategory', 'فئة المعلن',
              options: ['Education', 'Retail', 'Food & beverage', 'General']),
          const _Field('dailyBudgetJod', 'حد الإنفاق اليومي (JOD)'),
          const _Field('destinationUrl', 'رابط الوجهة HTTPS اختياري'),
          const _Field('asset', 'اسم الأصل الإعلاني'),
          const _Field('imageUrl', 'رابط الصورة أو اضغط لرفعها من الجهاز',
              image: true),
          const _Field('start', 'تاريخ البدء YYYY-MM-DD'),
          const _Field('end', 'تاريخ الانتهاء YYYY-MM-DD')
        ],
        initial: campaign);
    if (values == null) return;
    if (DateTime.tryParse(values['start']!) == null ||
        DateTime.tryParse(values['end']!) == null ||
        values['end']!.compareTo(values['start']!) < 0 ||
        (double.tryParse(values['dailyBudgetJod'] ?? '') ?? 0) <= 0) {
      toast('راجع تاريخ الحملة وحد الإنفاق اليومي');
      return;
    }
    final days = DateTime.parse(values['end']!)
            .difference(DateTime.parse(values['start']!))
            .inDays +
        1;
    final rate = store.number('dailyAdRate');
    store.edit(
        'campaigns',
        '${campaign['id']}',
        {
          ...values,
          'dailyRate': rate,
          'days': days,
          'budget': (double.tryParse(values['dailyBudgetJod']!) ?? rate) * days
        },
        notice:
            'تم تحديث حملة ${values['name']} • الإجمالي ${rate * days} JOD');
  }

  void checkout(Map<String, dynamic> campaign) {
    if (campaign['status'] == 'Live') {
      toast('الحملة مباشرة بالفعل');
      return;
    }
    store.edit('campaigns', '${campaign['id']}', {'status': 'Pending review'},
        notice: 'فاتورة تجريبية وحملة بانتظار المراجعة: ${campaign['name']}');
    toast('محاكاة فقط: لم يتم خصم أي مبلغ');
  }

  Future<void> topUp() async {
    final values = await form('إضافة رصيد تجريبي',
        const [_Field('amount', 'المبلغ JOD', number: true)]);
    if (values == null) return;
    final amount = double.parse(values['amount']!);
    if (amount <= 0) {
      toast('أدخل مبلغاً أكبر من صفر');
      return;
    }
    store.update((data) {
      data['walletJod'] = (data['walletJod'] as num).toDouble() + amount;
      (data['ledger'] as List).insert(0, {
        'id': newId('L'),
        'text': 'Top-up demo',
        'amount': amount,
        'currency': 'JOD',
        'at': DateTime.now().toIso8601String().substring(0, 10)
      });
    });
  }

  void debit() {
    if (store.number('walletJod') < 2.5) {
      toast('الرصيد غير كافٍ؛ تم رفض العملية التجريبية');
      return;
    }
    store.update((data) {
      data['walletJod'] = (data['walletJod'] as num).toDouble() - 2.5;
      (data['ledger'] as List).insert(0, {
        'id': newId('L'),
        'text': 'Journey debit demo',
        'amount': -2.5,
        'currency': 'JOD',
        'at': DateTime.now().toIso8601String().substring(0, 10)
      });
    });
  }

  void trip(String status) {
    store.setValue('tripState', status, notice: 'تحديث رحلة Amman 04: $status');
    if (status == 'Arrived') {
      store.announce('وصلت المركبة إلى نقطة الوصول', severity: 'arrived');
      alertAudio.play('arrived');
    }
  }

  Future<void> attendance(Map<String, dynamic> child) async {
    final droppedOff = child['attendance'] == 'Boarded';
    final values = await form('تسجيل حضور الراكب', [
      _Field('verificationMethod', 'طريقة التحقق',
          options: const ['MANUAL', 'QR'])
    ], initial: const {
      'verificationMethod': 'MANUAL'
    });
    if (values == null) return;
    final eventType = droppedOff ? 'DROPPED_OFF' : 'BOARDED';
    store.edit('children', '${child['id']}',
        {'attendance': droppedOff ? 'Dropped off' : 'Boarded'},
        notice: 'تم تحديث حضور ${child['name']}');
    store.add('attendanceEvents', {
      'id': newId('ATT'),
      'childId': child['id'],
      'eventType': eventType,
      'verificationMethod': values['verificationMethod'],
      'at': DateTime.now()
          .toIso8601String()
          .substring(0, 16)
          .replaceFirst('T', ' ')
    });
    if (droppedOff) alertAudio.play('arrived');
  }

  Future<void> alert(String text, {String severity = 'alert'}) async {
    if (!AppConfig.mockMode && widget.role == 'DRIVER') {
      final key = switch (text) {
        'Heavy Traffic delay' => 'traffic',
        'CAR/Bus is out of service' => 'service',
        _ => 'unavailable'
      };
      if (!await const EmergencyAlertClient().dispatch(
          templateKey: key,
          customText: text == 'Emergency SOS' ? text : null)) {
        toast(
            'تعذر إرسال تنبيه الطوارئ. اتصل بخدمة الطوارئ عند وجود خطر مباشر.');
        return;
      }
    }
    store.announce(text, severity: severity);
    alertAudio.play(severity);
  }

  Future<void> compose(String audience) async {
    if (widget.role == 'DRIVER' && store.text('tripState') == 'Moving') {
      toast('قفل الحركة: توقف أولاً قبل إرسال رسالة');
      return;
    }
    final values =
        await form('رسالة جديدة', const [_Field('text', 'نص الرسالة')]);
    if (values == null) return;
    if (!AppConfig.mockMode) {
      final recipientId = switch (audience) {
        'DRIVER' =>
          '${store.rows('children').firstWhere((child) => '${child['assignedDriver'] ?? ''}'.isNotEmpty, orElse: () => <String, dynamic>{
                'assignedDriver': ''
              })['assignedDriver']}',
        'GUARDIAN' => 'DEMO_PARENT',
        'SUPER_ADMIN' => 'DEMO_SUPER',
        _ => '',
      };
      if (recipientId.isEmpty ||
          !await const OperationalMessageClient().send(
              recipientId: recipientId,
              recipientRole: audience,
              body: values['text']!)) {
        toast('تعذر إرسال الرسالة. تحقق من المستلم وصلاحية الارتباط.');
        return;
      }
      toast('تم إرسال الرسالة الخاصة وتسجيلها بأمان');
      return;
    }
    store.announce(values['text']!, audience: audience);
  }
}

class _Page {
  const _Page(this.label, this.icon);
  final String label;
  final IconData icon;
}

class _Field {
  const _Field(this.key, this.label,
      {this.number = false,
      this.hint,
      this.location = false,
      this.image = false,
      this.date = false,
      this.time = false,
      this.options});
  final String key, label;
  final bool number, location, image, date, time;
  final String? hint;
  final List<String>? options;
  bool get required => true;
}
