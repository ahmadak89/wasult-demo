﻿// C:\src\wasalt_app\lib\screens\guardian_wallet_ledger_screen.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../core/config/app_config.dart';
import '../services/session_store.dart';

class GuardianWalletLedgerScreen extends StatefulWidget {
  final String userId;
  const GuardianWalletLedgerScreen({super.key, this.userId = 'PAS_SAMER'});

  @override
  State<GuardianWalletLedgerScreen> createState() => _GuardianWalletLedgerScreenState();
}

class _GuardianWalletLedgerScreenState extends State<GuardianWalletLedgerScreen> {
  double _balanceJod = 120.00;
  double _balanceEgp = 0.00;
  bool _isProcessing = false;
  List<dynamic> _transactionHistoryLogs = [];

  @override
  void initState() {
    super.initState();
    _fetchTransactionLedgerLogs();
  }

  Future<void> _fetchTransactionLedgerLogs() async {
    try {
      final token = await SessionStore.token();
      final userId = await SessionStore.userId() ?? widget.userId;
      if (token == null) return;
      final res = await http.get(AppConfig.api('/api/v1/wallet/transactions/$userId'), headers: {'Authorization': 'Bearer $token'});
      if (res.statusCode == 200 && (res.headers['content-type'] ?? '').toLowerCase().contains('application/json')) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        setState(() => _transactionHistoryLogs = data['logs'] ?? []);
      }
    } catch (_) {}
  }

  Future<void> _executeFareDebitSimulation(String currency, double amount) async {
    setState(() => _isProcessing = true);
    try {
      final token = await SessionStore.token();
      final userId = await SessionStore.userId() ?? widget.userId;
      if (token == null) throw StateError('GUARDIAN_SESSION_REQUIRED');
      final res = await http.post(AppConfig.api('/api/v1/wallet/deduct-fare'), headers: {"Content-Type": "application/json", 'Authorization': 'Bearer $token'}, body: jsonEncode({"userId": userId, "amount": amount, "currency": currency}));
      if (!(res.headers['content-type'] ?? '').toLowerCase().contains('application/json')) throw const FormatException('NON_JSON_API_RESPONSE');
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (res.statusCode == 200) {
        setState(() {
          _balanceJod = data['balances']['jod'].toDouble();
          _balanceEgp = data['balances']['egp'].toDouble();
        });
        _showStatusMessage("تم خصم قيمة التذكرة بنجاح واحتساب نقاط مكافأة الولاء!");
      } else {
        _showStatusMessage("تم رفض الدفع: رصيد الحساب دون الحد المسموح وتم تجميد المحفظة!");
      }
      _fetchTransactionLedgerLogs();
    } catch (e) {
      _showStatusMessage("خطأ في الاتصال بمخدم المحفظة الإلكترونية لشبكة وصلت.");
    } finally {
      setState(() => _isProcessing = false);
    }
  }

  void _showStatusMessage(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg, style: const TextStyle(fontFamily: 'Al Messri'))));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: const Color(0xFF005B60), foregroundColor: Colors.white, title: const Text("محفظة رصيد وصلت الموحدة")),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Card(
                color: const Color(0xFF005B60),
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    children: [
                      const Text("إجمالي الأرصدة المتوفرة بالمحفظة الحالية", style: TextStyle(color: Colors.white70, fontSize: 13)),
                      const SizedBox(height: 8),
                      Text("$_balanceJod JOD", style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold)),
                      Text("$_balanceEgp EGP", style: TextStyle(color: Colors.white.withOpacity(0.65), fontSize: 18)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                icon: const Icon(Icons.shopping_bag_outlined),
                label: const Text("محاكاة دفع ثمن رحلة مسار مباشر (15.00 JOD)"),
                onPressed: _isProcessing ? null : () => _executeFareDebitSimulation("JOD", 15.00),
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFFA500), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14)),
              ),
              const SizedBox(height: 24),
              const Text("سجل المعاملات والعمليات المالية والخصومات:", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Color(0xFF005B60))),
              const SizedBox(height: 10),
              Expanded(
                child: _transactionHistoryLogs.isEmpty
                    ? const Center(child: Text("لا توجد عمليات مقيدة في السجل المالي حالياً", style: TextStyle(color: Colors.grey)))
                    : ListView.builder(
                        itemCount: _transactionHistoryLogs.length,
                        itemBuilder: (context, i) {
                          final tx = _transactionHistoryLogs[i];
                          final bool isSuccess = tx['status'] == 'COMPLETED';
                          return ListTile(
                            leading: Icon(isSuccess ? Icons.check_circle : Icons.error, color: isSuccess ? Colors.green : Colors.red),
                            title: Text("خصم قيمة تذكرة: ${tx['amount']} ${tx['currency']}"),
                            subtitle: Text("رقم القيد الآلي: ${tx['tx_id']}"),
                            trailing: Text(isSuccess ? "مقبولة" : "مرفوضة", style: TextStyle(color: isSuccess ? Colors.green : Colors.red, fontWeight: FontWeight.bold)),
                          );
                        },
                      ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
