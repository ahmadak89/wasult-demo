﻿// driver_portal_screen.dart
import 'package:flutter/material.dart';

class StudentManifestItem {
  final String id;
  final String name;
  String status; // 'pending', 'boarded', 'no-show'

  StudentManifestItem({required this.id, required this.name, this.status = 'pending'});
}

class DriverPortalScreen extends StatefulWidget {
  const DriverPortalScreen({super.key});

  @override
  State<DriverPortalScreen> createState() => _DriverPortalScreenState();
}

class _DriverPortalScreenState extends State<DriverPortalScreen> {
  final List<StudentManifestItem> _students = [
    StudentManifestItem(id: "S1", name: "Zaid Al-Mansour"),
    StudentManifestItem(id: "S2", name: "Layla Tarawneh"),
    StudentManifestItem(id: "S3", name: "Youssef Fahmy"),
  ];

  void _updateStatus(int index, String choice) {
    setState(() {
      _students[index].status = choice;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("${_students[index].name}: $choice", style: const TextStyle(fontSize: 18)),
        duration: const Duration(milliseconds: 800),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Wasult Driver Portal", style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.amber,
      ),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.grey[200],
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Text("👆 Swipe UP = Boarded", style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 16)),
                Text("👇 Swipe DOWN = No-Show", style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold, fontSize: 16)),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _students.length,
              itemBuilder: (context, index) {
                final student = _students[index];
                Color cardColor = Colors.white;
                if (student.status == 'boarded') cardColor = Colors.green.shade100;
                if (student.status == 'no-show') cardColor = Colors.red.shade100;

                return Dismissible(
                  key: Key(student.id),
                  direction: DismissDirection.vertical,
                  confirmDismiss: (direction) async {
                    if (direction == DismissDirection.up) {
                      _updateStatus(index, "boarded");
                    } else if (direction == DismissDirection.down) {
                      _updateStatus(index, "no-show");
                    }
                    return false; // Prevent removing item from layout index tree
                  },
                  child: Container(
                    height: 140, // Oversized "Blind-Tap" UX layout height
                    margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: cardColor,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.grey.shade400, width: 2),
                    ),
                    alignment: Alignment.center,
                    child: ListTile(
                      title: Text(
                        student.name,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, letterSpacing: 0.5),
                      ),
                      subtitle: Text(
                        "Status: ${student.status.toUpperCase()}",
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.grey.shade700, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
