import 'package:flutter/material.dart';
import '../design/wasult_theme.dart';
import '../design/wasult_widgets.dart';
import '../widgets/wasult_osm_map.dart';

class DriverTripDashboardScreen extends StatefulWidget {
  const DriverTripDashboardScreen({super.key});
  @override State<DriverTripDashboardScreen> createState() => _DriverTripDashboardScreenState();
}

class _DriverTripDashboardScreenState extends State<DriverTripDashboardScreen> {
  String _state = 'Offline';
  double _speed = 0;
  int _tab = 0;
  bool get _moving => _speed > 5 || _state == 'Moving';

  void _setState(String value) => setState(() { _state = value; _speed = value == 'Moving' ? 24 : 0; });
  void _sos(String template) => showModalBottomSheet(context: context, showDragHandle: true, builder: (_) => Directionality(textDirection: TextDirection.rtl, child: Padding(padding: const EdgeInsets.fromLTRB(20, 4, 20, 28), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [const Icon(Icons.warning_amber_rounded, color: WasultColors.danger, size: 48), const Text('تأكيد إرسال التنبيه', textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)), const SizedBox(height: 8), Text(template, textAlign: TextAlign.center), const SizedBox(height: 22), WasultPressButton(label: 'إرسال إلى أولياء الأمور والإدارة', icon: Icons.campaign_rounded, color: WasultColors.danger, onPressed: () { Navigator.pop(context); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إرسال التنبيه وتسجيل العملية'))); })]))));

  @override
  Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: Scaffold(
    appBar: AppBar(title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('صباح الخير، أحمد', style: TextStyle(fontWeight: FontWeight.w900)), Text('المسار 04 • حافلة QA 55421', style: TextStyle(fontSize: 12, color: WasultColors.muted))]), actions: [IconButton(onPressed: () => Navigator.pushNamed(context, '/driver-scan'), icon: const Icon(Icons.qr_code_scanner_rounded)), IconButton(onPressed: () => Navigator.pushNamed(context, '/driver-profile'), icon: const Icon(Icons.account_circle_outlined))]),
    body: Stack(children: [
      ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 112), children: [
        Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(gradient: LinearGradient(colors: _moving ? const [Color(0xFF147A55), Color(0xFF20A66F)] : const [WasultColors.tealDark, WasultColors.teal]), borderRadius: BorderRadius.circular(28), boxShadow: const [BoxShadow(color: Color(0x2A005B60), blurRadius: 25, offset: Offset(0, 14))]), child: Column(children: [
          Row(children: [Container(width:58,height:58,decoration:BoxDecoration(color:Colors.white.withValues(alpha:.15),borderRadius:BorderRadius.circular(19)),child:Icon(_moving?Icons.directions_bus_filled_rounded:Icons.directions_bus_outlined,color:Colors.white,size:32)),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('حالة الرحلة',style:TextStyle(color:Colors.white70)),Text(_state,style:const TextStyle(color:Colors.white,fontSize:28,fontWeight:FontWeight.w900))])),WasultStatusPill(label:'${_speed.toInt()} km/h',color:Colors.white,icon:Icons.speed_rounded)]),
          const SizedBox(height:18), if(_moving) const LinearProgressIndicator(minHeight:6,color:WasultColors.amber,backgroundColor:Color(0x33FFFFFF),borderRadius:BorderRadius.all(Radius.circular(20))),
        ])),
        const SizedBox(height:18),
        const WasultOsmMap(height: 240),
        const SizedBox(height:18),
        Row(children:[Expanded(child:_StateButton(label:'متصل',icon:Icons.wifi_rounded,selected:_state=='Online',color:WasultColors.teal,onTap:()=>_setState('Online'))),const SizedBox(width:10),Expanded(child:_StateButton(label:'بدء المسار',icon:Icons.play_arrow_rounded,selected:_state=='Moving',color:WasultColors.success,onTap:()=>_setState('Moving'))),const SizedBox(width:10),Expanded(child:_StateButton(label:'إنهاء',icon:Icons.stop_rounded,selected:_state=='Offline',color:WasultColors.danger,onTap:()=>_setState('Offline')))]),
        const SizedBox(height:22),
        Row(children:[const Expanded(child:Text('المحطات القادمة',style:TextStyle(fontSize:21,fontWeight:FontWeight.w900))),WasultStatusPill(label:'3 ركاب',color:WasultColors.teal,icon:Icons.groups_rounded)]),const SizedBox(height:12),
        WasultPanel(child:Column(children: const [
          _StopRow(time:'07:42',name:'سامي الكواري',address:'المرخية • بوابة المنزل',first:true),_StopRow(time:'07:51',name:'يارا محمود',address:'الدحيل • المبنى 12'),_StopRow(time:'08:10',name:'مدرسة الدوحة',address:'بوابة الوصول',last:true),
        ])),
        const SizedBox(height:22),
        const Text('تنبيه سريع',style:TextStyle(fontSize:21,fontWeight:FontWeight.w900)),const SizedBox(height:12),
        GridView.count(crossAxisCount:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisSpacing:12,mainAxisSpacing:12,childAspectRatio:1.75,children:[
          _AlertButton(label:'ازدحام وتأخير',icon:Icons.traffic_rounded,onTap:()=>_sos('Heavy Traffic delay')),
          _AlertButton(label:'عطل في المركبة',icon:Icons.car_repair_rounded,onTap:()=>_sos('CAR/Bus is out of service')),
          _AlertButton(label:'غير متاح اليوم',icon:Icons.event_busy_rounded,onTap:()=>_sos('I am not available today, sorry for the inconvenience')),
          _AlertButton(label:'طوارئ SOS',icon:Icons.sos_rounded,danger:true,onTap:()=>_sos('Emergency SOS')),
        ]),
      ]),
      if (_moving) Positioned.fill(child:IgnorePointer(ignoring:false,child:Align(alignment:Alignment.bottomCenter,child:Container(margin:const EdgeInsets.fromLTRB(18,0,18,92),padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:WasultColors.ink,borderRadius:BorderRadius.circular(18),boxShadow:const [BoxShadow(color:Color(0x44000000),blurRadius:20)]),child:const Row(children:[Icon(Icons.do_not_disturb_on_total_silence_rounded,color:WasultColors.amber),SizedBox(width:10),Expanded(child:Text('وضع القيادة الآمن: الكتابة معطلة أثناء الحركة',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w800))) ]))))),
    ]),
    bottomNavigationBar:NavigationBar(selectedIndex:_tab,onDestinationSelected:(v)=>setState(()=>_tab=v),destinations:const [NavigationDestination(icon:Icon(Icons.route_outlined),selectedIcon:Icon(Icons.route_rounded),label:'الرحلة'),NavigationDestination(icon:Icon(Icons.groups_outlined),label:'الركاب'),NavigationDestination(icon:Icon(Icons.chat_bubble_outline_rounded),label:'الرسائل'),NavigationDestination(icon:Icon(Icons.assignment_outlined),label:'التقرير')]),
  ));
}

class _StateButton extends StatelessWidget { const _StateButton({required this.label,required this.icon,required this.selected,required this.color,required this.onTap}); final String label;final IconData icon;final bool selected;final Color color;final VoidCallback onTap; @override Widget build(BuildContext context)=>InkWell(onTap:onTap,borderRadius:BorderRadius.circular(18),child:AnimatedContainer(duration:const Duration(milliseconds:180),padding:const EdgeInsets.symmetric(vertical:15,horizontal:8),decoration:BoxDecoration(color:selected?color:Colors.white,borderRadius:BorderRadius.circular(18),border:Border.all(color:selected?color:const Color(0xFFDCE7E6)),boxShadow:selected?[BoxShadow(color:color.withValues(alpha:.25),blurRadius:14,offset:const Offset(0,7))]:null),child:Column(children:[Icon(icon,color:selected?Colors.white:color),const SizedBox(height:6),Text(label,style:TextStyle(color:selected?Colors.white:WasultColors.ink,fontWeight:FontWeight.w800,fontSize:12))]))); }
class _StopRow extends StatelessWidget { const _StopRow({required this.time,required this.name,required this.address,this.first=false,this.last=false}); final String time,name,address;final bool first,last; @override Widget build(BuildContext context)=>Row(crossAxisAlignment:CrossAxisAlignment.start,children:[SizedBox(width:48,child:Text(time,style:const TextStyle(fontWeight:FontWeight.w900,color:WasultColors.teal))),Column(children:[Container(width:14,height:14,decoration:BoxDecoration(color:last?WasultColors.orange:WasultColors.success,shape:BoxShape.circle,border:Border.all(color:Colors.white,width:3),boxShadow:const [BoxShadow(color:Color(0x22000000),blurRadius:4)])),if(!last)Container(width:2,height:50,color:WasultColors.tealSoft)]),const SizedBox(width:12),Expanded(child:Padding(padding:const EdgeInsets.only(bottom:14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(name,style:const TextStyle(fontWeight:FontWeight.w900)),Text(address,style:const TextStyle(color:WasultColors.muted,fontSize:12))])))]); }
class _AlertButton extends StatelessWidget { const _AlertButton({required this.label,required this.icon,required this.onTap,this.danger=false});final String label;final IconData icon;final VoidCallback onTap;final bool danger; @override Widget build(BuildContext context)=>Material(color:danger?const Color(0xFFFFE7E7):Colors.white,borderRadius:BorderRadius.circular(18),child:InkWell(onTap:onTap,borderRadius:BorderRadius.circular(18),child:Padding(padding:const EdgeInsets.all(14),child:Row(children:[Icon(icon,color:danger?WasultColors.danger:WasultColors.orange),const SizedBox(width:10),Expanded(child:Text(label,style:TextStyle(fontWeight:FontWeight.w800,color:danger?WasultColors.danger:WasultColors.ink)))])))); }
