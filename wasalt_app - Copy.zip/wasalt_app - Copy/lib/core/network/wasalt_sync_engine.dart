import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

class WasaltSyncEngine extends ChangeNotifier {
  WebSocketChannel? _channel;
  bool isConnected = false;
  
  // Real-time tracking coordinates mapped natively by Driver ID
  Map<String, Map<String, double>> activeBusCoordinates = {};

  /// Connects to the local Wasalt Node.js Server over high-frequency WebSockets
  void initializeSyncFeed(String parentId) {
    try {
      // Direct data hook straight to your local backend server port line
      _channel = WebSocketChannel.connect(
        Uri.parse('ws://127.0.0.1:3000'),
      );

      isConnected = true;
      notifyListeners();

      // 1. Authenticate Parent session profile token on the WebSocket layer
      final authPacket = {
        "event_type": "AUTHENTICATE_PARENT",
        "token_id": parentId
      };
      _channel!.sink.add(jsonEncode(authPacket));

      // 2. Persistent event listener loop for incoming live vehicle telemetry
      _channel!.stream.listen(
        (message) {
          _processIncomingTelemetry(message);
        },
        onDone: () => _handleDisconnect(),
        onError: (err) => _handleDisconnect(),
      );
    } catch (e) {
      _handleDisconnect();
    }
  }

  void _processIncomingTelemetry(dynamic message) {
    try {
      final Map<String, dynamic> data = jsonDecode(message);
      
      if (data['event_type'] == 'BUS_COORDINATE_UPDATE') {
        final String driverId = data['driver_id'];
        final double lat = data['latitude'];
        final double lng = data['longitude'];

        // Core data mapping step: snap the specific vehicle ID to its fresh map position
        activeBusCoordinates[driverId] = {
          "latitude": lat,
          "longitude": lng,
        };

        // Instantly triggers a UI canvas re-render on active parent tracking views
        notifyListeners();
      }
    } catch (e) {
      debugPrint("Telemetry packet dropped or corrupted: $e");
    }
  }

  /// Sends live vehicle coordinates from the Driver UI state matrix
  void broadcastDriverCoordinates(String driverId, double lat, double lng) {
    if (_channel != null && isConnected) {
      final coordinatePacket = {
        "event_type": "VEHICLE_COORDINATE_PING",
        "coordinates": {
          "driver_id": driverId,
          "latitude": lat,
          "longitude": lng
        }
      };
      _channel!.sink.add(jsonEncode(coordinatePacket));
    }
  }

  void _handleDisconnect() {
    isConnected = false;
    _channel = null;
    notifyListeners();
    debugPrint("?? Wasalt sync pipeline detached from server. Attempting reconnection...");
  }

  @override
  void dispose() {
    _channel?.sink.close();
    super.dispose();
  }
}
