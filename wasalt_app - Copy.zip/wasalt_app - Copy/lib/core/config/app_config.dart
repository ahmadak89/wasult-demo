abstract final class AppConfig {
  static const apiBaseUrl = String.fromEnvironment('WASULT_API_URL', defaultValue: 'http://127.0.0.1:5000');
  static const mockMode = bool.fromEnvironment('WASULT_MOCK_MODE', defaultValue: false);
  static Uri api(String path) => Uri.parse('$apiBaseUrl$path');
}
