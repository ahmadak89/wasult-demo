﻿// lib/driver_view.dart
import 'package:flutter/material.dart';
import 'services/alert_audio_service.dart';

class DriverWorkspaceView extends StatefulWidget {
  final VoidCallback onBack;
  final Function(String) onEmitAction;
  final bool isSocketConnected;

  const DriverWorkspaceView({
    super.key, 
    required this.onBack, 
    required this.onEmitAction,
    required this.isSocketConnected,
  });

  @override
  State<DriverWorkspaceView> createState() => _DriverWorkspaceViewState();
}

class _DriverWorkspaceViewState extends State<DriverWorkspaceView> {
  final _alertAudio = AlertAudioService();
  // Scenario A: Mock Incoming Ad-Hoc Request Card
  bool _hasPendingRequest = true;
  String _requestStatusText = "Awaiting Review";

  final List<Map<String, dynamic>> _studentsManifest = [
    {"id": "S1", "name": "زيد المنصور", "status": "pending"},
    {"id": "S2", "name": "ليلى الطراونة", "status": "pending"},
    {"id": "S3", "name": "يوسف فهمي", "status": "pending"},
  ];

  void _triggerEmergencyBroadcast(String reason) {
    _alertAudio.play(reason.contains('أزمة') ? 'emergency' : 'critical');
    widget.onEmitAction("EMERGENCY_ALERT: $reason");
    Navigator.pop(context); // Close dialog
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("🚨 تم إرسال تنبيه طوارئ فوري: $reason", style: const TextStyle(fontFamily: 'Al Messri', fontSize: 16)),
        backgroundColor: Colors.red.shade900,
      ),
    );
  }

  @override
  void dispose() {
    _alertAudio.dispose();
    super.dispose();
  }

  void _showEmergencyDialog() {
    showDialog(
      context: context,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text("🚨 إرسال تنبيه طوارئ عاجل", style: TextStyle(fontFamily: 'Al Messri', fontWeight: FontWeight.bold)),
          content: const Text("سيتم إرسال هذا التنبيه فوراً لجميع أولياء الأمور والركاب المنتظرين على الخط."),
          actions: [
            ListTile(
              leading: const Icon(Icons.car_crash, color: Colors.red),
              title: const Text("حادث / عطل في الحافلة"),
              onTap: () => _triggerEmergencyBroadcast("عطل فني مفاجئ في الحافلة"),
            ),
            ListTile(
              leading: const Icon(Icons.traffic, color: Colors.orange),
              title: const Text("أزمة مرورية خانقة / تأخير حاد"),
              onTap: () => _triggerEmergencyBroadcast("تأخير بسبب أزمة مرورية حادة"),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("إلغاء", style: TextStyle(color: Colors.grey)),
            )
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("بوابة السائق | ${widget.isSocketConnected ? '🟢 متصل' : '🔴 منفصل'}"),
        backgroundColor: Colors.amber.shade700,
        actions: [
          IconButton(
            icon: const Icon(Icons.warning_amber_rounded, color: Colors.white, size: 28),
            onPressed: _showEmergencyDialog,
            tooltip: "تنبيه طوارئ عاجل",
          )
        ],
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: widget.onBack),
      ),
      body: Column(
        children: [
          // ⚠️ AD-HOC INTERACTIVE BOOKING CARD (Scenario A / B Handshake)
          if (_hasPendingRequest)
            Container(
              margin: const EdgeInsets.all(12),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.blueGrey.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.teal, width: 2),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text("📌 طلب تغيير موقع لحظي (Ad-Hoc Request)", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.teal)),
                      Chip(label: Text(_requestStatusText), backgroundColor: Colors.teal.shade100),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Text("الراكب: سارة أحمد (Sarah)", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  const Text("وقت الطلب: غداً الساعة 04:30 مساءً"),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      const Icon(Icons.location_on, color: Colors.grey, size: 16),
                      Text("الموقع الافتراضي: منزل العائلة (طريق المطار)", style: TextStyle(color: Colors.grey.shade700)),
                    ],
                  ),
                  Row(
                    children: const [
                      Icon(Icons.stars, color: Colors.orange, size: 16),
                      Text("الموقع البديل المؤقت: شركة أركان (ضمن النطاق المسموح < 3 كم)", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.orange)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  if (_requestStatusText == "Awaiting Review")
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
                            onPressed: () {
                              setState(() => _requestStatusText = "Approved");
                              widget.onEmitAction("AD_HOC_APPROVE: Sarah");
                            },
                            child: const Text("✔ قبول وتعديل المسار"),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
                            onPressed: () {
                              setState(() => _hasPendingRequest = false);
                              widget.onEmitAction("AD_HOC_DECLINE: Sarah");
                            },
                            child: const Text("❌ رفض الطلب"),
                          ),
                        ),
                      ],
                    )
                ],
              ),
            ),

          // TRIP LIFECYCLE DIRECT CONTROLLER ROW
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton.icon(
                  onPressed: () => widget.onEmitAction("Start Trip"),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.green.shade600, foregroundColor: Colors.white),
                  icon: const Icon(Icons.play_arrow),
                  label: const Text("بدء الرحلة"),
                ),
                ElevatedButton.icon(
                  onPressed: () => widget.onEmitAction("Signal Approach"),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.orange.shade600, foregroundColor: Colors.white),
                  icon: const Icon(Icons.notifications_active),
                  label: const Text("إرسال تنبيه 500م"),
                ),
                ElevatedButton.icon(
                  onPressed: () => widget.onEmitAction("Arrived"),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.blue.shade600, foregroundColor: Colors.white),
                  icon: const Icon(Icons.pin_drop),
                  label: const Text("وصلت الموقف"),
                ),
              ],
            ),
          ),

          // BLIND-TAP MANIFEST LIST
          Expanded(
            child: ListView.builder(
              itemCount: _studentsManifest.length,
              itemBuilder: (context, index) {
                final item = _studentsManifest[index];
                Color bg = Colors.white;
                if (item["status"] == "boarded") bg = Colors.green.shade100;
                if (item["status"] == "no-show") bg = Colors.red.shade100;

                return Dismissible(
                  key: Key(item["id"]),
                  direction: DismissDirection.vertical,
                  confirmDismiss: (direction) async {
                    setState(() {
                      _studentsManifest[index]["status"] = (direction == DismissDirection.up) ? "boarded" : "no-show";
                    });
                    widget.onEmitAction("Manifest Update - ${item['name']}: ${_studentsManifest[index]['status']}");
                    return false;
                  },
                  child: Container(
                    height: 100,
                    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.grey.shade300)),
                    alignment: Alignment.center,
                    child: ListTile(
                      title: Text(item["name"], style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                      subtitle: Text("الحالة الحالية: ${item["status"].toString().toUpperCase()}", textAlign: TextAlign.center),
                    ),
                  ),
                );
              },
            ),
          )
        ],
      ),
    );
  }
}
