// Deployment-owned, non-secret web configuration. Replace these values in the
// deployment pipeline; never put gateway tokens, Firebase private keys, or
// provider passwords in this file.
window.WASULT_DEPLOYMENT_CONFIG = {
  canonicalUrl: 'https://wasult.example/',
  analytics: { enabled: false, consentRequired: true, measurementId: '' }
};
