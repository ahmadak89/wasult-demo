# Five-role Amman demo: implementation and remaining production work

## Local demo

Build with `--dart-define=WASULT_MOCK_MODE=true`. The static web build is served at `http://127.0.0.1:7359`; the OpenStreetMap development tile relay is on `http://127.0.0.1:7360`. Both processes must remain active. All sample maps use Amman, Jordan.

| Role | ID | Password | Local route |
| --- | --- | --- | --- |
| Guardian | DEMO_PARENT | P26a1 | `/#/map-multiplex` |
| Driver | DEMO_DRIVER | DriverDemo2026! | `/#/driver-trip` |
| Corporate Admin | DEMO_CORP | CorpDemo2026! | `/#/corporate-admin` |
| Super Admin | DEMO_SUPER | SuperDemo2026! | `/#/super-admin` |
| Advertiser | DEMO_ADVERT | AdvertDemo2026! | `/#/advertiser` |

The direct routes are reviewer shortcuts. In mock mode the login forms validate these five credentials locally. They must not be used in production.

## Implemented in the mock workspace

- Shared local records (browser storage with periodic cross-tab refresh) for children, drivers, tenants, GPS devices, campaigns, billing rules, notices, ledger, trip status and route locations.
- Guardian: family map and trip phase, child add/edit/enable/disable, tomorrow absence broadcast, wallet top-up/debit simulation, alerts/read receipts, hardware pairing with a restricted-mode message, From/To location confirmation.
- Driver: trip start/arrival/completion, roster attendance, share-code preview, SOS/traffic/service alerts, profile editing, read receipts, and a simulated full-screen motion lock while the demo trip is moving.
- Corporate Admin: fleet add/edit/activate/suspend, reset request, IoT GPS provisioning with generated pairing token and status, subscription-capacity request, alerts.
- Super Admin: tenant add/edit/activate/suspend, billing rule edit/status, campaign review approval/rejection, brand color field, IoT inventory and alerts.
- Advertiser: campaign add/edit and district/slot/budget/dates, asset-name library, draft/pause/review lifecycle, invoice/checkout simulation, and notifications.
- UI: Arabic Cairo font, responsive desktop/mobile navigation, 3D-style pressed buttons inherited from the design system, status badges, and OpenStreetMap base maps with Amman sample routes.

## Production readiness gaps — do not represent this build as live production

1. Replace local mock persistence and hard-coded credentials with authenticated API contracts, RBAC/tenant isolation, token rotation, server-side validation, and an audit ledger.
2. Persist each domain entity in PostgreSQL using migrations, unique constraints, foreign keys, state-transition rules and transactional changes. Cross-tab polling is not a substitute for server events or multi-user synchronization.
3. Connect real fleet telemetry and validate latency, GPS accuracy, permission handling, geofence events and stale-device states. The IoT TCP decoder, IMEI ownership proof and token expiry/rate limits are not implemented here.
4. Add secure asset uploads (file-size/type checks, antivirus processing, storage/CDN, previews and administrator approval). The Advertiser demo currently records an asset name/link only.
5. Integrate a real payment provider through server-created checkout sessions and signed webhooks. Demo wallet and invoices perform no real charge. Apple IAP and regional wallet integrations remain separate compliance work.
6. Implement real push/WhatsApp/SMS dispatch, delivery/read acknowledgments, retries and opt-in preferences. Mock notices remain local to this browser origin.
7. Add comprehensive automated tests, accessibility and localization audits, browser/device matrix, performance/load tests, secrets management, observability, backups, disaster recovery and staged rollout controls.
8. Provision a policy-compliant production map tile service. The localhost relay exists only to work around network restrictions for this demo, not as a scalable production service.

## Business rules for backend implementation

- Only Super Admin may approve a Pending advertiser campaign for Live display; Draft/Paused campaigns render a generic asset. Schedule windows and tenant ownership must be checked server-side.
- Hardware pairing must be read-only, scoped to the authorized guardian and route, time-limited, revocable and rate-limited. A paired hardware route hides driver chat/call and manual boarding controls.
- Driver motion lock must derive from trusted device speed and block distracting actions above 5 km/h; the mock app uses a simulated 24 km/h status only.
- Wallet debits require a server-side serializable transaction, idempotency key, currency-specific balance and immutable ledger entries. The demo does not enforce those guarantees.
