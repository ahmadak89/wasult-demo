# Wasult local demo (superseded by FIVE_ROLE_MOCK_WORKFLOWS.md)

This build is a local, mock-data demonstration. It does not authenticate against the production API or write to PostgreSQL.

## Open in Chrome

Base URL: `http://127.0.0.1:7359`

| Role | Demo ID | Demo password | Direct screen |
| --- | --- | --- | --- |
| Guardian | `DEMO_PARENT` | `P26a1` | `http://127.0.0.1:7359/#/map-multiplex` |
| Driver | `DEMO_DRIVER` | `DriverDemo2026!` | `http://127.0.0.1:7359/#/driver-trip` |
| Corporate Admin | `DEMO_CORP` | `CorpDemo2026!` | `http://127.0.0.1:7359/#/corporate-admin` |
| Super Admin | `DEMO_SUPER` | `SuperDemo2026!` | `http://127.0.0.1:7359/#/super-admin` |
| Advertiser | `DEMO_ADVERT` | `AdvertDemo2026!` | `http://127.0.0.1:7359/#/advertiser` |

Use the landing page to test the login screens. The direct links are review shortcuts available in the mock build only. Never use these client-side demo credentials for real accounts.

## Maps and locations

Each role dashboard displays an Amman fleet route on OpenStreetMap tiles. The local demo uses a localhost tile relay on port `7360` because this environment restricts direct browser requests. Outside mock mode, the app requests OpenStreetMap tiles directly. Production should use a policy-compliant map provider or managed tile service with capacity planning rather than relying on the public tile service for a fleet-wide workload.

The guardian route-location screen (`/#/route-location`) offers independent From and To selection. The picker supports current device coordinates, place search, tapping a pin on the map, reverse-geocoded human-readable addresses, and explicit confirmation. Browser geolocation permissions and live search require network availability; the mock route confirmation does not dispatch a real driver request.

## Rebuild and serve

From `work/wasult/wasalt_app` with Flutter installed at `C:\src\flutter`, build with `--dart-define=MOCK_MODE=true`. Serve `build/web` at localhost port `7359`, and run `work/osm_tile_relay.js` at localhost port `7360`. Both must remain running for this demo's maps.
